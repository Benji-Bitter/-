# ÆOS - Advanced Ethical Hacking Operating System

![ÆOS Logo](../boot/splash.png)

## Overview

ÆOS is a powerful, security-focused Linux distribution designed for penetration testers, security researchers, and cybersecurity professionals. It combines advanced hacking tools, robust security features, and a sleek dark-themed interface to provide the ultimate platform for ethical hacking and cybersecurity operations.

## DISCLAIMER

**ÆOS is designed for ETHICAL and LEGAL use only.**

This operating system contains powerful security testing tools that should only be used:
- With explicit permission from system owners
- On your own systems for educational purposes
- In authorized security assessments and penetration tests

The developers of ÆOS take NO RESPONSIBILITY for any misuse of these tools. If you use this operating system to commit illegal activities, you are solely responsible for the consequences. Unauthorized access to computer systems is a criminal offense in most jurisdictions.

## Repository Contents

This repository contains the source code and build scripts for ÆOS. You can use it to:

1. Build a custom ÆOS ISO image
2. Contribute to the development of ÆOS
3. Learn about security tool integration and Linux distribution customization

## Getting Started with Development

1. Clone this repository:
   ```
   git clone https://github.com/yourusername/aeos.git
   cd aeos
   ```

2. Install development dependencies:
   ```
   sudo ./scripts/install_dev_dependencies.sh
   ```

3. Build the ISO:
   ```
   sudo ./scripts/create_iso.sh
   ```

4. Test the ISO in a virtual machine:
   ```
   # Example for QEMU
   qemu-system-x86_64 -boot d -cdrom output/aeos-*.iso -m 4096
   ```

## Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for details on how to contribute to ÆOS.

## Directory Structure

- `/boot`: Boot configuration and splash screen
- `/scripts`: Build and installation scripts
- `/pentest`: Penetration testing frameworks and tools
- `/forensics`: Digital forensics tools
- `/crypto`: Cryptography utilities
- `/ui`: User interface components and dashboard
- `/docs`: Documentation and guides

## Build Requirements

- Debian or Ubuntu-based host system
- At least 20GB of free disk space
- Internet connection for package downloads
- Root privileges for ISO creation

## License

This project is open source and available under the MIT License with additional usage restrictions. See LICENSE file for details.

## Contact

For questions, issues, or contributions, please open an issue on GitHub or contact the maintainers at [your-email@example.com].