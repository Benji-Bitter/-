# Contributing to ÆOS

Thank you for your interest in contributing to ÆOS (Advanced Ethical Hacking Operating System)! This document provides guidelines and instructions for contributing to the project.

## Table of Contents

1. [Code of Conduct](#code-of-conduct)
2. [How Can I Contribute?](#how-can-i-contribute)
3. [Development Setup](#development-setup)
4. [Pull Request Process](#pull-request-process)
5. [Coding Standards](#coding-standards)
6. [Documentation Guidelines](#documentation-guidelines)
7. [Community](#community)

## Code of Conduct

This project and everyone participating in it is governed by the ÆOS Code of Conduct. By participating, you agree to uphold this code. Please report unacceptable behavior to [your-email@example.com].

## How Can I Contribute?

### Reporting Bugs

- Ensure the bug has not already been reported by searching GitHub Issues
- If you're unable to find an open issue addressing the problem, open a new one
- Include a clear title and description
- Add as much relevant information as possible (steps to reproduce, expected behavior, etc.)
- Include screenshots if applicable

### Suggesting Enhancements

- First, read the documentation to ensure the feature doesn't already exist
- Search GitHub Issues to see if the enhancement has already been suggested
- Include a clear title and description
- Provide specific examples of how the enhancement would work
- Explain why this enhancement would be useful to ÆOS users

### Contributing Code

- Find an open issue to tackle or suggest a new feature
- Fork the repository
- Create a new branch for your changes
- Make your changes following the coding standards
- Write or update tests as necessary
- Ensure your code passes all tests
- Submit a pull request

### Improving Documentation

- Fix typos, clarify language, or improve organization
- Add missing documentation for existing features
- Create tutorials or guides for using ÆOS
- Update documentation to reflect new features or changes

## Development Setup

To set up ÆOS for development:

1. Fork the repository on GitHub
2. Clone your fork:
   ```bash
   git clone https://github.com/yourusername/aeos.git
   cd aeos
   ```
3. Set up the development environment:
   ```bash
   sudo ./scripts/install_dev_dependencies.sh
   ```

## Pull Request Process

1. Ensure your code follows the project's coding standards
2. Update the documentation to reflect any changes
3. Add or update tests for your changes
4. Ensure all tests pass
5. Submit a pull request with a clear description of the changes
6. The project maintainers will review your pull request
7. Address any feedback or requested changes
8. Once approved, your pull request will be merged

## Coding Standards

### Python

- Follow PEP 8 style guide
- Use meaningful variable and function names
- Add docstrings to all functions and classes
- Keep functions small and focused
- Use type hints where appropriate
- Use f-strings for string formatting

Example:
```python
def calculate_hash(file_path: str) -> str:
    """
    Calculate the SHA-256 hash of a file.
    
    Args:
        file_path: Path to the file to hash
        
    Returns:
        The SHA-256 hash as a hexadecimal string
    """
    import hashlib
    
    sha256 = hashlib.sha256()
    with open(file_path, 'rb') as f:
        for block in iter(lambda: f.read(4096), b''):
            sha256.update(block)
    return sha256.hexdigest()
```

### Shell Scripts

- Use meaningful variable and function names
- Add comments to explain complex operations
- Use double brackets for conditionals
- Quote all variables
- Use shellcheck to validate scripts

Example:
```bash
#!/bin/bash

# Exit on any error
set -e

# Check if running as root
if [[ "$EUID" -ne 0 ]]; then
  echo "Please run as root (sudo bash script.sh)"
  exit 1
fi

# Function to check dependencies
check_dependencies() {
  local deps=("git" "python3" "make")
  for dep in "${deps[@]}"; do
    if ! command -v "$dep" &> /dev/null; then
      echo "Error: $dep is not installed."
      exit 1
    fi
  done
}

# Call the function
check_dependencies
```

## Documentation Guidelines

- Write clear, concise, and accurate documentation
- Use Markdown for all documentation files
- Include examples where appropriate
- Keep the language simple and accessible
- Organize documentation logically
- Update documentation to reflect code changes

## Community

### Communication Channels

- GitHub Issues: Bug reports, feature requests, and discussions
- GitHub Discussions: General questions and community discussions
- Email: For private inquiries and sensitive information

### Recognition

Contributors will be recognized in:
- The AUTHORS.md file
- Release notes
- Project website

Thank you for contributing to ÆOS! Your efforts help make this project better for everyone.