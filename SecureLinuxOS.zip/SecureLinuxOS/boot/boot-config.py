#!/usr/bin/env python3

"""
ÆOS Boot Configuration Script
Handles boot process, splash screen, and initial system setup
"""

import os
import sys
import time
import subprocess
import logging
import argparse
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename="/var/log/aeos-boot.log"
)
logger = logging.getLogger("aeos-boot")

class BootManager:
    """Manages the ÆOS boot process"""
    
    def __init__(self):
        """Initialize boot manager"""
        self.boot_dir = Path("/boot/aeos")
        self.splash_image = self.boot_dir / "splash.png"
        self.boot_config = self.boot_dir / "boot.conf"
        self.progress = 0
        
    def show_splash_screen(self):
        """Display boot splash screen"""
        logger.info("Displaying boot splash screen")
        try:
            if os.path.exists("/usr/bin/plymouth"):
                # Use Plymouth if available
                subprocess.run(["plymouth", "show-splash"], check=True)
                subprocess.run(["plymouth", "change-splash", str(self.splash_image)], check=True)
            else:
                # Fallback to a simple framebuffer display
                subprocess.run(["fbv", "-c", str(self.splash_image)], check=True)
        except Exception as e:
            logger.error(f"Error displaying splash screen: {e}")
    
    def update_boot_progress(self, progress, message):
        """Update boot progress display"""
        self.progress = progress
        logger.info(f"Boot progress: {progress}% - {message}")
        try:
            if os.path.exists("/usr/bin/plymouth"):
                subprocess.run(["plymouth", "update", "--progress", str(progress)], check=True)
                subprocess.run(["plymouth", "display-message", "--text", message], check=True)
        except Exception as e:
            logger.error(f"Error updating boot progress: {e}")
    
    def load_security_modules(self):
        """Load essential security kernel modules"""
        logger.info("Loading security modules")
        
        security_modules = [
            "apparmor",
            "selinux",
            "tomoyo",
            "integrity",
            "securityfs",
            "lockdown",
            "yama"
        ]
        
        for module in security_modules:
            try:
                self.update_boot_progress(self.progress + 5, f"Loading security module: {module}")
                subprocess.run(["modprobe", module], check=False)
            except Exception as e:
                logger.warning(f"Could not load module {module}: {e}")
    
    def configure_networking(self):
        """Configure secure networking defaults"""
        logger.info("Configuring secure networking")
        
        # Configure basic IP forwarding
        with open("/proc/sys/net/ipv4/ip_forward", "w") as f:
            f.write("0\n")  # Disable IP forwarding by default for security
            
        # Protect against SYN flood attacks
        with open("/proc/sys/net/ipv4/tcp_syncookies", "w") as f:
            f.write("1\n")
            
        # Disable IP source routing
        with open("/proc/sys/net/ipv4/conf/all/accept_source_route", "w") as f:
            f.write("0\n")
            
        # Enable TCP SYN cookies
        with open("/proc/sys/net/ipv4/tcp_syncookies", "w") as f:
            f.write("1\n")
            
        # Increase connection queue size
        with open("/proc/sys/net/core/somaxconn", "w") as f:
            f.write("1024\n")
            
        self.update_boot_progress(self.progress + 10, "Network security configured")
    
    def initialize_security_services(self):
        """Initialize core security services"""
        logger.info("Initializing security services")
        
        services = [
            "apparmor",
            "auditd",
            "aide",
            "clamav-freshclam",
            "fail2ban",
            "firewalld",
            "rkhunter",
            "suricata"
        ]
        
        for service in services:
            try:
                self.update_boot_progress(self.progress + 5, f"Starting service: {service}")
                subprocess.run(["systemctl", "start", service], check=False)
            except Exception as e:
                logger.warning(f"Could not start service {service}: {e}")
    
    def initialize_cryptographic_subsystem(self):
        """Initialize cryptographic subsystems"""
        logger.info("Initializing cryptographic subsystems")
        
        # Load hardware crypto acceleration if available
        try:
            subprocess.run(["modprobe", "aesni_intel"], check=False)
            subprocess.run(["modprobe", "cryptd"], check=False)
        except Exception as e:
            logger.warning(f"Could not load crypto modules: {e}")
            
        self.update_boot_progress(self.progress + 5, "Cryptographic subsystem initialized")
    
    def run_boot_process(self):
        """Execute the main boot process"""
        try:
            # Show splash screen
            self.show_splash_screen()
            self.update_boot_progress(10, "Starting ÆOS...")
            
            # Load security modules
            self.load_security_modules()
            
            # Configure networking
            self.configure_networking()
            
            # Initialize cryptographic subsystems
            self.initialize_cryptographic_subsystem()
            
            # Initialize security services
            self.initialize_security_services()
            
            # Complete boot process
            self.update_boot_progress(100, "ÆOS boot complete")
            logger.info("Boot process completed successfully")
            
            # Hide splash and show login
            time.sleep(1)
            try:
                subprocess.run(["plymouth", "quit"], check=False)
            except:
                pass
                
        except Exception as e:
            logger.error(f"Error during boot process: {e}")
            self.update_boot_progress(100, "Boot error encountered")
            return False
            
        return True

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description="ÆOS Boot Configuration")
    parser.add_argument("--test", action="store_true", help="Run in test mode without modifying system")
    args = parser.parse_args()
    
    if args.test:
        logger.info("Running in test mode")
        
    if os.geteuid() != 0:
        logger.error("This script must be run as root")
        print("Error: This script must be run as root")
        sys.exit(1)
    
    boot_manager = BootManager()
    success = boot_manager.run_boot_process()
    
    if not success:
        logger.error("Boot process failed")
        sys.exit(1)
    
    logger.info("Boot configuration completed successfully")
    sys.exit(0)

if __name__ == "__main__":
    main()