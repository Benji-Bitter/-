# ÆOS Command Reference

This is a quick reference guide for common commands and operations in ÆOS.

## System Commands

### ISO Creation and Setup

```bash
# Install development dependencies
sudo ./scripts/install_dev_dependencies.sh

# Create bootable ISO
sudo ./scripts/fixed_create_iso.sh

# Apply final update package (after installation)
sudo ./scripts/final_update.sh

# Update ÆOS system
sudo ./scripts/update.sh
```

### Dashboard and Monitoring

```bash
# Start the ÆOS dashboard
sudo python3 /opt/aeos/ui/dashboard/dashboard_console.py

# Network monitoring
sudo /opt/aeos/network/monitor.sh

# Run security scan
sudo /opt/aeos/security/security_scan.sh
```

### GitHub Repository Setup

```bash
# Initialize git repository
git init

# Add all files
git add .

# Commit changes
git commit -m "Initial commit of ÆOS"

# Add remote repository
git remote add origin https://github.com/yourusername/aeos.git

# Push to GitHub
git push -u origin main
```

### VM Management

```bash
# Create VirtualBox VM (quick command)
VBoxManage createvm --name "ÆOS" --ostype "Debian_64" --register
VBoxManage modifyvm "ÆOS" --memory 4096 --cpus 2 --vram 128
VBoxManage createhd --filename "ÆOS.vdi" --size 30000
VBoxManage storagectl "ÆOS" --name "SATA" --add sata
VBoxManage storageattach "ÆOS" --storagectl "SATA" --port 0 --device 0 --type hdd --medium "ÆOS.vdi"
VBoxManage storageattach "ÆOS" --storagectl "SATA" --port 1 --device 0 --type dvddrive --medium output/aeos-YYYYMMDD.iso
VBoxManage startvm "ÆOS"
```

## Security Tools

### Penetration Testing

```bash
# Start a new penetration testing project
/opt/aeos/pentesting/start_assessment.sh

# Run common security scans
nmap -sV -sC <target>
dirb http://<target> /opt/aeos/pentesting/wordlists/common.txt
nikto -h <target>
gobuster dir -u http://<target> -w /opt/aeos/pentesting/wordlists/common.txt
sqlmap -u "http://<target>/page.php?id=1" --dbs
```

### Forensics

```bash
# Start a new forensics case
/opt/aeos/forensics/create_case.sh

# Create a forensic image of a disk
sudo dd if=/dev/sdX of=/path/to/image.dd bs=4M status=progress
sudo dc3dd if=/dev/sdX of=/path/to/image.dd hash=sha256 log=forensic_acquisition.log

# Mount a forensic image (read-only)
sudo mount -o ro,loop,noexec /path/to/image.dd /mnt/evidence

# Run file carving
foremost -i /path/to/image.dd -o /path/to/output
```

### Network Analysis

```bash
# Capture network traffic
sudo tcpdump -i eth0 -w capture.pcap

# Analyze wireless networks
sudo airmon-ng start wlan0
sudo airodump-ng wlan0mon

# Start Wireshark
sudo wireshark
```

### Password Cracking

```bash
# Hash cracking with John the Ripper
john --wordlist=/opt/aeos/pentesting/wordlists/passwords.txt hashfile.txt

# Hash cracking with Hashcat
hashcat -m 0 -a 0 hashfile.txt /opt/aeos/pentesting/wordlists/passwords.txt

# Brute force with Hydra
hydra -l admin -P /opt/aeos/pentesting/wordlists/passwords.txt <target> http-post-form "/login:username=^USER^&password=^PASS^:F=Login failed"
```

## System Hardening

```bash
# Check system security
sudo lynis audit system

# Check for rootkits
sudo rkhunter --check

# Scan for malware
sudo clamscan -r /

# Enable firewall
sudo ufw enable
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw status
```

## Useful Shortcuts

- **Ctrl+Alt+T**: Open terminal
- **Alt+F2**: Run command dialog
- **Ctrl+Alt+Arrow**: Switch workspace
- **Ctrl+Shift+Esc**: Open task manager
- **PrtScn**: Take screenshot

## Default Paths

- Security tools: `/opt/aeos/tools/`
- Penetration testing workspace: `/opt/aeos/pentesting/`
- Forensics workspace: `/opt/aeos/forensics/`
- Wordlists: `/opt/aeos/pentesting/wordlists/`
- Security scan logs: `/var/log/aeos/security_scans/`
- Update logs: `/var/log/aeos/updates.log`

## Default Credentials

- Username: `aeos`
- Password: `changeme` (Remember to change this immediately after first login!)