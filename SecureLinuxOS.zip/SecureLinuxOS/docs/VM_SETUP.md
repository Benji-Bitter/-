# Running ÆOS in a Virtual Machine

This guide provides detailed instructions for running ÆOS in different virtual machine environments.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [VirtualBox Setup](#virtualbox-setup)
3. [VMware Setup](#vmware-setup)
4. [QEMU/KVM Setup](#qemukvm-setup)
5. [Troubleshooting](#troubleshooting)
6. [Performance Optimization](#performance-optimization)

## Prerequisites

Before setting up a virtual machine for ÆOS, ensure you have:

- The ÆOS ISO file (created using the `fixed_create_iso.sh` script)
- A host system with sufficient resources:
  - 4+ CPU cores
  - 8+ GB RAM (16GB recommended)
  - 50+ GB available disk space
- Virtualization enabled in BIOS/UEFI
- One of the following virtualization platforms installed:
  - VirtualBox 6.0+
  - VMware Workstation 15+ / VMware Fusion 11+
  - QEMU/KVM (for Linux hosts)

## VirtualBox Setup

### Step 1: Create a New Virtual Machine

1. Open VirtualBox and click "New"
2. Enter the following settings:
   - Name: ÆOS
   - Machine Folder: (Your preferred location)
   - Type: Linux
   - Version: Debian (64-bit)
3. Click "Next"

### Step 2: Allocate RAM

1. Allocate at least 4 GB (4096 MB) of RAM
2. 8 GB (8192 MB) is recommended for optimal performance
3. Click "Next"

### Step 3: Create a Virtual Hard Disk

1. Select "Create a virtual hard disk now"
2. Click "Create"
3. Choose "VDI (VirtualBox Disk Image)"
4. Click "Next"
5. Select "Dynamically allocated"
6. Click "Next"
7. Set the disk size to at least 30 GB (50 GB recommended)
8. Click "Create"

### Step 4: Configure VM Settings

1. Select your new VM and click "Settings"
2. Under "System":
   - Go to the "Processor" tab
   - Allocate at least 2 CPU cores (4 recommended)
   - Enable PAE/NX
3. Under "Display":
   - Allocate 128 MB of video memory
   - Enable 3D Acceleration
4. Under "Storage":
   - Select the empty optical drive
   - Click the disk icon on the right
   - Choose "Choose a disk file"
   - Browse and select your ÆOS ISO file
5. Under "Network":
   - Ensure "NAT" is selected for Adapter 1
6. Click "OK" to save settings

### Step 5: Start the VM

1. Select your ÆOS VM
2. Click "Start"
3. The VM should boot from the ÆOS ISO
4. Select "ÆOS - Advanced Ethical Hacking OS" from the boot menu

### Step 6: Installation

1. Once booted to the ÆOS live environment, double-click the "Install ÆOS" icon
2. Follow the installation wizard
3. When complete, restart the VM
4. Remove the ISO from the virtual optical drive before reboot

## VMware Setup

### Step 1: Create a New Virtual Machine

1. Open VMware and click "Create a New Virtual Machine"
2. Select "Custom (advanced)" and click "Next"
3. Select the appropriate hardware compatibility and click "Next"
4. Select "I will install the operating system later" and click "Next"
5. Select "Linux" as the guest OS
6. Select "Debian 10.x 64-bit" as the version
7. Name your VM "ÆOS" and choose a storage location
8. Click "Next"

### Step 2: Configure CPU and Memory

1. Specify at least 2 processors (4 recommended)
2. Specify at least 4 GB RAM (8 GB recommended)
3. Click "Next"

### Step 3: Configure Network

1. Select "NAT" for network connection
2. Click "Next"

### Step 4: Create Disk

1. Create a new virtual disk
2. Select "SCSI" as the controller type
3. Select "Create a new virtual disk"
4. Set disk size to at least 30 GB (50 GB recommended)
5. Select "Store virtual disk as a single file"
6. Click "Next" and then "Finish"

### Step 5: Customize Hardware

1. Click "Customize Hardware"
2. Select "CD/DVD"
3. Select "Use ISO image file"
4. Browse and select your ÆOS ISO file
5. Ensure "Connect at power on" is checked
6. Click "Close" and then "Finish"

### Step 6: Start the VM

1. Power on the virtual machine
2. The VM should boot from the ÆOS ISO
3. Select "ÆOS - Advanced Ethical Hacking OS" from the boot menu

### Step 7: Installation

Follow the same installation steps as described in the VirtualBox section.

## QEMU/KVM Setup

### Prerequisites

Ensure you have QEMU, KVM, and virt-manager installed:

```bash
sudo apt-get install qemu-kvm libvirt-daemon-system libvirt-clients bridge-utils virt-manager
```

### Step 1: Create a New Virtual Machine

1. Open Virtual Machine Manager (virt-manager)
2. Click the "Create a new virtual machine" button
3. Select "Local install media" and click "Forward"
4. Click "Browse" and select your ÆOS ISO file
5. In the "Choose the operating system" field:
   - Select "Linux" for OS type
   - Select "Debian 10" for Version
6. Click "Forward"

### Step 2: Configure Memory and CPU

1. Allocate at least 4 GB (4096 MB) of RAM
2. Allocate at least 2 CPUs
3. Click "Forward"

### Step 3: Configure Disk

1. Create a disk of at least 30 GB (50 GB recommended)
2. Click "Forward"

### Step 4: Final Configuration

1. Name your VM "ÆOS"
2. Check "Customize configuration before install"
3. Click "Finish"

### Step 5: Additional VM Configuration

1. In the configuration window, select "Display Spice"
2. Set "Listen type" to "None"
3. Click "Video" and select "Virtio" as the model
4. Click "Apply" and then "Begin Installation"

### Step 6: Installation

Follow the same installation steps as described in the VirtualBox section.

## Troubleshooting

### Issue: VM fails to boot from ISO

**Solution:**
1. Verify the ISO file is not corrupted
2. Ensure the ISO is properly attached to the VM
3. Check that the boot order prioritizes the CD/DVD drive
4. Try rebuilding the ISO with `sudo ./scripts/fixed_create_iso.sh`

### Issue: Graphics problems in the VM

**Solution:**
1. Boot with "ÆOS - Failsafe Mode" option
2. After installation, install appropriate guest additions/tools:
   ```bash
   # For VirtualBox
   sudo apt install virtualbox-guest-utils virtualbox-guest-x11
   
   # For VMware
   sudo apt install open-vm-tools open-vm-tools-desktop
   ```

### Issue: Network not working

**Solution:**
1. Check VM network settings (should be NAT or Bridged)
2. In the ÆOS system, run:
   ```bash
   sudo systemctl restart NetworkManager
   ```

### Issue: Performance is slow

**Solution:**
1. Increase RAM allocation (8+ GB)
2. Increase CPU cores (4+)
3. Enable 3D acceleration if available
4. Install VM guest tools/additions

## Performance Optimization

### VirtualBox Optimization

```bash
# Install VirtualBox Guest Additions
sudo apt update
sudo apt install virtualbox-guest-utils virtualbox-guest-x11
sudo reboot
```

### VMware Optimization

```bash
# Install VMware Tools
sudo apt update
sudo apt install open-vm-tools open-vm-tools-desktop
sudo reboot
```

### General Performance Tips

1. **Disable unnecessary services:**
   ```bash
   sudo systemctl disable bluetooth.service
   sudo systemctl disable cups.service  # If you don't need printing
   ```

2. **Optimize disk I/O:**
   ```bash
   # Add to /etc/fstab (for the root partition)
   # Change UUID as necessary
   UUID=xxxxx / ext4 defaults,noatime 0 1
   ```

3. **Reduce swappiness:**
   ```bash
   echo "vm.swappiness=10" | sudo tee -a /etc/sysctl.d/99-sysctl.conf
   sudo sysctl -p
   ```

4. **Use a lightweight desktop environment:**
   ÆOS already uses a optimized XFCE environment, which is lightweight.

---

For any further assistance, refer to the [ÆOS Documentation](https://github.com/yourusername/aeos) or submit an issue on GitHub.