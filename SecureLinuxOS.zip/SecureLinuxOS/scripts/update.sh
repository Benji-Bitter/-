#!/bin/bash

###############################################################################
#                       ÆOS Update Script                                     #
#                                                                             #
# This script updates the ÆOS system components, packages, and security tools #
# to ensure you have the latest features and security patches                 #
###############################################################################

# Exit on any error
set -e

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (sudo bash update.sh)"
  exit 1
fi

echo "======================================================"
echo "      ÆOS System Update                               "
echo "======================================================"

# Get current date for logs
UPDATE_DATE=$(date +"%Y-%m-%d %H:%M:%S")
echo "Update started: $UPDATE_DATE"
echo ""

# Update package lists
echo "Step 1/7: Updating package lists..."
apt-get update
echo "Package lists updated successfully."
echo ""

# Upgrade installed packages
echo "Step 2/7: Upgrading system packages..."
apt-get upgrade -y
echo "System packages upgraded successfully."
echo ""

# Upgrade distribution
echo "Step 3/7: Performing distribution upgrade..."
apt-get dist-upgrade -y
echo "Distribution upgrade completed successfully."
echo ""

# Update security tools
echo "Step 4/7: Updating security tools..."

# Update Metasploit
if [ -d "/opt/metasploit-framework" ]; then
  echo "Updating Metasploit Framework..."
  cd /opt/metasploit-framework
  git pull
  cd - > /dev/null
fi

# Update ExploitDB
if [ -d "/opt/exploit-db" ]; then
  echo "Updating Exploit-DB..."
  cd /opt/exploit-db
  git pull
  cd - > /dev/null
fi

# Update other tools (add more as needed)
echo "Updating additional security tools..."
apt-get install --only-upgrade wireshark nmap aircrack-ng hydra sqlmap dirb nikto -y

echo "Security tools updated successfully."
echo ""

# Update ÆOS components
echo "Step 5/7: Updating ÆOS core components..."
if [ -d "/opt/aeos" ]; then
  cd /opt/aeos
  git pull
  
  # Update Python dependencies
  if [ -f "/opt/aeos/requirements.txt" ]; then
    echo "Updating Python dependencies..."
    pip3 install --upgrade -r requirements.txt
  fi
  
  cd - > /dev/null
fi
echo "ÆOS core components updated successfully."
echo ""

# Clean up
echo "Step 6/7: Cleaning up..."
apt-get autoremove -y
apt-get autoclean -y
echo "Cleanup completed successfully."
echo ""

# Update finished
echo "Step 7/7: Finalizing update..."
UPDATE_END_DATE=$(date +"%Y-%m-%d %H:%M:%S")

# Record update in log
mkdir -p /var/log/aeos
echo "$UPDATE_DATE to $UPDATE_END_DATE - System Update" >> /var/log/aeos/updates.log

echo "======================================================"
echo "      ÆOS Update Completed Successfully!              "
echo "======================================================"
echo ""
echo "Update started: $UPDATE_DATE"
echo "Update completed: $UPDATE_END_DATE"
echo ""
echo "All components have been successfully updated."
echo "System is now running the latest version of ÆOS."
echo ""
echo "To keep your system secure:"
echo "- Run this update script regularly"
echo "- Check for security advisories at https://github.com/yourusername/aeos"
echo "- Verify the integrity of your tools before use"
echo ""
echo "Thank you for using ÆOS!"
echo "======================================================"