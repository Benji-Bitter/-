#!/bin/bash

# CyberOS Setup Script
# This script installs and configures the CyberOS environment
# Must be run as root or with sudo privileges

# Exit on any error
set -e

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (sudo bash setup.sh)"
  exit 1
fi

# Display welcome message
echo "======================================================"
echo "            CyberOS Installation Setup                "
echo "======================================================"
echo "This script will install and configure CyberOS on your"
echo "Linux system. This process will take some time."
echo "======================================================"
echo ""

# Check for compatible base system
if [ -f /etc/os-release ]; then
    . /etc/os-release
    if [[ "$ID" != "ubuntu" && "$ID" != "debian" ]]; then
        echo "Warning: This script is optimized for Ubuntu or Debian."
        echo "Some features may not work on $PRETTY_NAME."
        read -p "Continue anyway? (y/n) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
else
    echo "Cannot detect OS type. Proceed with caution."
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Update system and install required packages
echo "Updating system packages..."
apt update && apt upgrade -y

echo "Installing base dependencies..."
apt install -y git python3 python3-pip python3-venv python3-gi libgtk-3-dev \
    zsh tmux curl wget build-essential cmake pkg-config \
    ufw apparmor apparmor-utils selinux-basics

# Create installation directory
BASE_DIR="/opt/cyberos"
echo "Creating installation directory at $BASE_DIR"
mkdir -p "$BASE_DIR"

# Copy configuration to installation directory
echo "Installing CyberOS files..."
cp -r ../config "$BASE_DIR/"
cp -r ../scripts "$BASE_DIR/"
cp -r ../ui "$BASE_DIR/"
cp -r ../ide "$BASE_DIR/"
cp -r ../security "$BASE_DIR/"
cp -r ../docs "$BASE_DIR/"

# Setup Python environment
echo "Setting up Python environment..."
python3 -m venv "$BASE_DIR/venv"
"$BASE_DIR/venv/bin/pip" install -U pip
"$BASE_DIR/venv/bin/pip" install PyGObject pycairo matplotlib numpy pandas psutil requests pillow pygtk

# Install security tools
echo "Installing security tools..."
bash "$BASE_DIR/scripts/install_security_tools.sh"

# Install development tools
echo "Installing development tools..."
bash "$BASE_DIR/scripts/install_dev_tools.sh"

# Configure system security
echo "Configuring system security..."
python3 "$BASE_DIR/scripts/configure_system.py"

# Setup desktop environment
echo "Setting up desktop environment..."
# Create desktop entry
cat > /usr/share/applications/cyberos-dashboard.desktop << EOF
[Desktop Entry]
Name=CyberOS Dashboard
Comment=CyberOS Security Dashboard
Exec=$BASE_DIR/venv/bin/python3 $BASE_DIR/ui/dashboard/dashboard.py
Icon=$BASE_DIR/ui/icons/app_icons.svg
Terminal=false
Type=Application
Categories=Development;Security;
EOF

# Make scripts executable
chmod +x "$BASE_DIR/scripts/"*.sh
chmod +x "$BASE_DIR/scripts/"*.py

# Create symlinks
ln -sf "$BASE_DIR/scripts/setup.sh" /usr/local/bin/cyberos-setup
ln -sf "$BASE_DIR/ui/dashboard/dashboard.py" /usr/local/bin/cyberos-dashboard
ln -sf "$BASE_DIR/ide/cyberdev_ide.py" /usr/local/bin/cyberdev-ide

# Final setup steps
echo "Performing final configuration..."
# Set up firewall
ufw --force enable
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh

echo "======================================================"
echo "            CyberOS Installation Complete             "
echo "======================================================"
echo "To start the CyberOS dashboard, run: cyberos-dashboard"
echo "To start the CyberDev IDE, run: cyberdev-ide"
echo ""
echo "For more information, see the documentation at:"
echo "$BASE_DIR/docs/"
echo "======================================================"
