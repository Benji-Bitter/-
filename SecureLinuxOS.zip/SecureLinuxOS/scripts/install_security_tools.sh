#!/bin/bash

# ÆOS Security Tools Installation Script
# Installs and configures ethical hacking and penetration testing tools

# Exit on any error
set -e

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (sudo bash install_security_tools.sh)"
  exit 1
fi

echo "======================================================"
echo "      Installing ÆOS Security Tools                   "
echo "======================================================"

# Update system
apt update
apt upgrade -y

# Create tool directories
mkdir -p /opt/aeos/pentest/{network,web,wireless,forensics,social,crypto}

# Install dependencies
echo "Installing dependencies..."
apt install -y build-essential autoconf automake libtool pkg-config libssl-dev zlib1g-dev \
  libbz2-dev libreadline-dev libsqlite3-dev wget curl llvm libncurses5-dev libncursesw5-dev \
  xz-utils tk-dev libffi-dev liblzma-dev python3-openssl git libpcap-dev libusb-1.0-0-dev \
  libglib2.0-dev libdbus-1-dev libbluetooth-dev libnl-3-dev libnl-genl-3-dev \
  libnl-route-3-dev libnl-nf-3-dev libpcre3-dev libpcap-dev libpq-dev libsqlite3-dev \
  libnetfilter-queue-dev libnghttp2-dev librtmp-dev libssh2-1-dev libssh-dev \
  libcurl4-openssl-dev libxml2-dev libxslt1-dev libjson-c-dev libssl-dev libgeoip-dev \
  libpcre++-dev libyaml-dev libradcli-dev

echo "======================================================"
echo "      Installing Network Analysis Tools               "
echo "======================================================"

# Wireshark
echo "Installing Wireshark..."
apt install -y wireshark tshark

# Nmap
echo "Installing Nmap..."
apt install -y nmap ncat ndiff

# Masscan
echo "Installing Masscan..."
apt install -y masscan

# Netcat and other network utilities
echo "Installing network utilities..."
apt install -y netcat-openbsd socat tcpdump dsniff smbclient

# Install Nessus (just dependencies - would require download)
echo "Installing Nessus dependencies..."
apt install -y nessusd

# Scapy
echo "Installing Scapy..."
pip3 install scapy

echo "======================================================"
echo "      Installing Web Application Testing Tools        "
echo "======================================================"

# Burp Suite dependencies (would require download)
echo "Installing Burp Suite dependencies..."
apt install -y openjdk-11-jdk

# OWASP ZAP
echo "Installing OWASP ZAP dependencies..."
apt install -y zaproxy

# SQLmap
echo "Installing SQLmap..."
apt install -y sqlmap

# Nikto
echo "Installing Nikto..."
apt install -y nikto

# Dirb/Dirbuster
echo "Installing Dirb/Dirbuster..."
apt install -y dirb

# WPScan
echo "Installing WPScan..."
apt install -y ruby ruby-dev
gem install wpscan

echo "======================================================"
echo "      Installing Wireless Security Tools              "
echo "======================================================"

# Aircrack-ng
echo "Installing Aircrack-ng..."
apt install -y aircrack-ng

# Kismet
echo "Installing Kismet..."
apt install -y kismet

# Wifite
echo "Installing Wifite..."
apt install -y wifite

# Bluetooth utilities
echo "Installing Bluetooth utilities..."
apt install -y bluez bluez-tools bluetooth blueman

echo "======================================================"
echo "      Installing Password & Cryptography Tools        "
echo "======================================================"

# John the Ripper
echo "Installing John the Ripper..."
apt install -y john

# Hashcat
echo "Installing Hashcat..."
apt install -y hashcat

# Hydra
echo "Installing Hydra..."
apt install -y hydra

# Cryptography tools
echo "Installing cryptography tools..."
apt install -y gnupg openssl steghide outguess foremost

echo "======================================================"
echo "      Installing Forensics Tools                     "
echo "======================================================"

# Sleuth Kit & Autopsy dependencies
echo "Installing forensics tools..."
apt install -y sleuthkit testdisk photorec foremost scalpel dd_rescue ddrescue 

# Volatility
echo "Installing Volatility dependencies..."
apt install -y python3-pip python3-dev
pip3 install distorm3 yara-python pycrypto openpyxl ujson

echo "======================================================"
echo "      Installing Social Engineering Tools             "
echo "======================================================"

# SET dependencies
echo "Installing Social Engineering Toolkit dependencies..."
apt install -y apache2 python3-requests python3-pip

# BeEF dependencies
echo "Installing BeEF dependencies..."
apt install -y ruby-dev libsqlite3-dev nodejs

echo "======================================================"
echo "      Installing Exploitation Frameworks             "
echo "======================================================"

# Metasploit Framework dependencies
echo "Installing Metasploit Framework dependencies..."
apt install -y build-essential libpq-dev libpcap-dev libsqlite3-dev ruby ruby-dev

# Armitage
echo "Installing Armitage dependencies..."
apt install -y armitage

# Create launcher scripts

echo '#!/bin/bash
echo "Starting Network Analysis Toolkit..."
zenity --info --title="ÆOS Network Analysis" --text="Starting network analysis tools..." --width=300
' > /usr/local/bin/aeos-network
chmod +x /usr/local/bin/aeos-network

echo '#!/bin/bash
echo "Starting Web Assessment Toolkit..."
zenity --info --title="ÆOS Web Testing" --text="Starting web application testing tools..." --width=300
' > /usr/local/bin/aeos-web
chmod +x /usr/local/bin/aeos-web

echo '#!/bin/bash
echo "Starting Wireless Hacking Toolkit..."
zenity --info --title="ÆOS Wireless" --text="Starting wireless security tools..." --width=300
' > /usr/local/bin/aeos-wireless
chmod +x /usr/local/bin/aeos-wireless

echo '#!/bin/bash
echo "Starting Password Cracking Toolkit..."
zenity --info --title="ÆOS Password Cracking" --text="Starting password and hash cracking tools..." --width=300
' > /usr/local/bin/aeos-password
chmod +x /usr/local/bin/aeos-password

echo '#!/bin/bash
echo "Starting Digital Forensics Toolkit..."
zenity --info --title="ÆOS Forensics" --text="Starting digital forensics tools..." --width=300
' > /usr/local/bin/aeos-forensics
chmod +x /usr/local/bin/aeos-forensics

echo '#!/bin/bash
echo "Starting Social Engineering Toolkit..."
zenity --info --title="ÆOS Social Engineering" --text="Starting social engineering tools..." --width=300
' > /usr/local/bin/aeos-social
chmod +x /usr/local/bin/aeos-social

echo "======================================================"
echo "      Creating Desktop Entries                        "
echo "======================================================"

# Create desktop entries for tool categories
mkdir -p /usr/share/applications

cat > /usr/share/applications/aeos-network.desktop << EOF
[Desktop Entry]
Name=ÆOS Network Analysis
Comment=Network security assessment tools
Exec=/usr/local/bin/aeos-network
Icon=/opt/aeos/icons/network.png
Terminal=false
Type=Application
Categories=ÆOS;Security;
EOF

cat > /usr/share/applications/aeos-web.desktop << EOF
[Desktop Entry]
Name=ÆOS Web Testing
Comment=Web application security testing tools
Exec=/usr/local/bin/aeos-web
Icon=/opt/aeos/icons/web.png
Terminal=false
Type=Application
Categories=ÆOS;Security;
EOF

cat > /usr/share/applications/aeos-wireless.desktop << EOF
[Desktop Entry]
Name=ÆOS Wireless
Comment=Wireless security assessment tools
Exec=/usr/local/bin/aeos-wireless
Icon=/opt/aeos/icons/wireless.png
Terminal=false
Type=Application
Categories=ÆOS;Security;
EOF

cat > /usr/share/applications/aeos-forensics.desktop << EOF
[Desktop Entry]
Name=ÆOS Forensics
Comment=Digital forensics tools
Exec=/usr/local/bin/aeos-forensics
Icon=/opt/aeos/icons/forensics.png
Terminal=false
Type=Application
Categories=ÆOS;Security;
EOF

cat > /usr/share/applications/aeos-social.desktop << EOF
[Desktop Entry]
Name=ÆOS Social Engineering
Comment=Social engineering tools
Exec=/usr/local/bin/aeos-social
Icon=/opt/aeos/icons/social.png
Terminal=false
Type=Application
Categories=ÆOS;Security;
EOF

echo "======================================================"
echo "      Security Tools Installation Complete            "
echo "======================================================"

echo "The following tools have been installed or prepared for installation:"
echo "  - Network: Wireshark, Nmap, Masscan, Netcat, Scapy"
echo "  - Web: OWASP ZAP, SQLmap, Nikto, Dirb, WPScan"
echo "  - Wireless: Aircrack-ng, Kismet, Wifite"
echo "  - Password: John the Ripper, Hashcat, Hydra"
echo "  - Forensics: Sleuth Kit, TestDisk, Volatility"
echo "  - Social Engineering: SET dependencies, BeEF dependencies"
echo "  - Exploitation: Metasploit, Armitage dependencies"
echo ""
echo "Note: Some tools require additional setup or direct downloads"
echo "      from their respective official websites."
echo ""
echo "Use 'aeos-toolkit' to access all security tools from the menu."