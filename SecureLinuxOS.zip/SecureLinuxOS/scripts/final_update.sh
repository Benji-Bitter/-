#!/bin/bash

###############################################################################
#                       ÆOS Final Update Script                               #
#                                                                             #
# This script applies the final update package to ÆOS, enhancing security,    #
# performance, and usability features                                         #
###############################################################################

# Exit on any error
set -e

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (sudo bash final_update.sh)"
  exit 1
fi

echo "======================================================"
echo "      ÆOS Final System Update                          "
echo "======================================================"

# Get current date for logs
UPDATE_DATE=$(date +"%Y-%m-%d %H:%M:%S")
echo "Final Update started: $UPDATE_DATE"
echo ""

# Update package lists
echo "Step 1/10: Updating package repositories..."
apt-get update
echo "Package repositories updated successfully."
echo ""

# Install additional security tools
echo "Step 2/10: Installing advanced security tools..."
apt-get install -y clamav rkhunter lynis openvas nikto dirb sqlmap \
  nmap metasploit-framework wireshark aircrack-ng hydra hashcat \
  john-the-ripper wifite burpsuite zaproxy maltego beef-xss \
  foremost autopsy sleuthkit binwalk steghide volatility ghidra radare2
echo "Advanced security tools installed successfully."
echo ""

# Install performance optimizations
echo "Step 3/10: Applying performance optimizations..."
apt-get install -y preload irqbalance tuned
systemctl enable preload
systemctl start preload
systemctl enable tuned
systemctl start tuned
tuned-adm profile balanced

# Create performance settings
cat > /etc/sysctl.d/99-aeos-performance.conf << EOF
# ÆOS Performance Settings
vm.swappiness = 10
vm.vfs_cache_pressure = 50
net.core.somaxconn = 4096
net.ipv4.tcp_max_syn_backlog = 4096
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_tw_reuse = 1
EOF

sysctl -p /etc/sysctl.d/99-aeos-performance.conf
echo "Performance optimizations applied successfully."
echo ""

# Install hardened security settings
echo "Step 4/10: Implementing enhanced security measures..."
apt-get install -y apparmor apparmor-utils apparmor-profiles apparmor-profiles-extra
systemctl enable apparmor
systemctl start apparmor

# Secure SSH
cat > /etc/ssh/sshd_config.d/hardened.conf << EOF
# ÆOS Hardened SSH Configuration
Protocol 2
PermitRootLogin no
PasswordAuthentication yes
PubkeyAuthentication yes
X11Forwarding no
PermitEmptyPasswords no
MaxAuthTries 5
LoginGraceTime 30
TCPKeepAlive yes
ClientAliveInterval 300
ClientAliveCountMax 2
Banner /etc/issue.net
EOF

# Create custom SSH banner
cat > /etc/issue.net << EOF
=============================================================
                   ÆOS SECURITY WARNING
=============================================================
This system is restricted to authorized users only.
All activities are logged and monitored.
Unauthorized access is prohibited and prosecuted.
=============================================================
EOF

# Harden system configs
cat > /etc/modprobe.d/aeos-blacklist.conf << EOF
# ÆOS Security Module Blacklist
blacklist cramfs
blacklist freevxfs
blacklist jffs2
blacklist hfs
blacklist hfsplus
blacklist udf
blacklist usb-storage
EOF

# Setup automatic security updates
cat > /etc/apt/apt.conf.d/50unattended-upgrades << EOF
Unattended-Upgrade::Allowed-Origins {
    "Debian:bullseye";
    "Debian:bullseye-security";
    "Debian:bullseye-updates";
};
Unattended-Upgrade::Package-Blacklist {
};
Unattended-Upgrade::AutoFixInterruptedDpkg "true";
Unattended-Upgrade::MinimalSteps "true";
Unattended-Upgrade::Remove-Unused-Kernel-Packages "true";
Unattended-Upgrade::Remove-Unused-Dependencies "true";
Unattended-Upgrade::Automatic-Reboot "false";
Unattended-Upgrade::Automatic-Reboot-Time "02:00";
EOF

cat > /etc/apt/apt.conf.d/20auto-upgrades << EOF
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::AutocleanInterval "7";
EOF

# Setup firewall
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow http
ufw allow https
echo "y" | ufw enable

echo "Enhanced security measures implemented successfully."
echo ""

# Install desktop improvements
echo "Step 5/10: Enhancing desktop environment..."
apt-get install -y xfce4-goodies arc-theme papirus-icon-theme plank \
  compton conky-all xfce4-whiskermenu-plugin

# Create improved XFCE configuration
mkdir -p /etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/
cat > /etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/xfwm4.xml << EOF
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfwm4" version="1.0">
  <property name="general" type="empty">
    <property name="theme" type="string" value="Arc-Dark"/>
    <property name="workspace_count" type="int" value="4"/>
    <property name="use_compositing" type="bool" value="true"/>
    <property name="cycle_preview" type="bool" value="true"/>
  </property>
</channel>
EOF

cat > /etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml << EOF
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xsettings" version="1.0">
  <property name="Net" type="empty">
    <property name="ThemeName" type="string" value="Arc-Dark"/>
    <property name="IconThemeName" type="string" value="Papirus-Dark"/>
  </property>
  <property name="Gtk" type="empty">
    <property name="CursorThemeName" type="string" value="Adwaita"/>
  </property>
</channel>
EOF

# Apply to existing user
cp -r /etc/skel/.config /home/aeos/
chown -R aeos:aeos /home/aeos/.config

echo "Desktop environment enhancements applied successfully."
echo ""

# Setup security scanning schedule
echo "Step 6/10: Configuring automated security scanning..."
mkdir -p /opt/aeos/security/
cat > /opt/aeos/security/security_scan.sh << 'EOF'
#!/bin/bash

# ÆOS Automated Security Scan
SCAN_DATE=$(date +"%Y-%m-%d %H:%M:%S")
SCAN_REPORT_DIR="/var/log/aeos/security_scans"
SCAN_REPORT_FILE="${SCAN_REPORT_DIR}/security_scan_$(date +%Y%m%d).log"

mkdir -p "${SCAN_REPORT_DIR}"

echo "ÆOS Security Scan - ${SCAN_DATE}" > "${SCAN_REPORT_FILE}"
echo "=======================================" >> "${SCAN_REPORT_FILE}"

# Run ClamAV scan
echo "\n== ClamAV Malware Scan ==" >> "${SCAN_REPORT_FILE}"
clamscan --recursive=yes --infected /home >> "${SCAN_REPORT_FILE}" 2>&1

# Run rkhunter
echo "\n== RootKit Hunter Scan ==" >> "${SCAN_REPORT_FILE}"
rkhunter --checkall --skip-keypress >> "${SCAN_REPORT_FILE}" 2>&1

# Run Lynis audit
echo "\n== Lynis System Audit ==" >> "${SCAN_REPORT_FILE}"
lynis audit system --no-colors >> "${SCAN_REPORT_FILE}" 2>&1

# Run chkrootkit
echo "\n== ChkRootkit Scan ==" >> "${SCAN_REPORT_FILE}"
chkrootkit >> "${SCAN_REPORT_FILE}" 2>&1

# Permissions check on sensitive files
echo "\n== Sensitive File Permissions ==" >> "${SCAN_REPORT_FILE}"
ls -la /etc/passwd /etc/shadow /etc/group /etc/gshadow /etc/ssh/sshd_config >> "${SCAN_REPORT_FILE}" 2>&1

# Network connections check
echo "\n== Network Connections ==" >> "${SCAN_REPORT_FILE}"
netstat -tulanp >> "${SCAN_REPORT_FILE}" 2>&1

echo "\nScan completed at $(date +"%Y-%m-%d %H:%M:%S")" >> "${SCAN_REPORT_FILE}"

# Create a desktop notification if we're in a graphical environment
if [ -n "$DISPLAY" ]; then
  notify-send "ÆOS Security Scan Complete" "Scan report saved to ${SCAN_REPORT_FILE}"
fi
EOF

chmod +x /opt/aeos/security/security_scan.sh

# Add to crontab for weekly scanning
cat > /etc/cron.d/aeos-security-scan << EOF
# ÆOS Weekly Security Scan
0 2 * * 0 root /opt/aeos/security/security_scan.sh
EOF

echo "Automated security scanning configured successfully."
echo ""

# Setup advanced networking tools
echo "Step 7/10: Setting up advanced networking tools..."
apt-get install -y iptraf-ng iftop bmon traceroute mtr-tiny \
  tcptraceroute aircrack-ng kismet wireshark tshark

# Create network monitoring start script
mkdir -p /opt/aeos/network/
cat > /opt/aeos/network/monitor.sh << 'EOF'
#!/bin/bash

# ÆOS Network Monitoring Dashboard
TERM=xterm-256color

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (sudo bash monitor.sh)"
  exit 1
fi

# Function to monitor network interfaces
monitor_interfaces() {
  clear
  echo "==============================================="
  echo "  ÆOS Network Monitoring - Press q to quit     "
  echo "==============================================="
  
  # Run iftop in batch mode
  iftop -t -s 5 -n
  
  sleep 2
  
  # Show active connections
  echo "\nActive Connections:"
  echo "==============================================="
  netstat -tupan | head -20
  
  # Detect suspicious connections or services
  echo "\nPotentially Suspicious Services:"
  echo "==============================================="
  netstat -tupan | grep -v "127.0.0.1" | grep "LISTEN" | sort -u
}

# Main loop
while true; do
  monitor_interfaces
  echo "\nPress Ctrl+C to exit..."
  sleep 5
done
EOF

chmod +x /opt/aeos/network/monitor.sh

# Create desktop shortcut for network monitoring
mkdir -p /usr/share/applications/
cat > /usr/share/applications/aeos-network-monitor.desktop << EOF
[Desktop Entry]
Name=ÆOS Network Monitor
Comment=Real-time network monitoring and analysis
Exec=pkexec /opt/aeos/network/monitor.sh
Icon=/opt/aeos/icons/network.png
Terminal=true
Type=Application
Categories=ÆOS-Tools;
EOF

echo "Advanced networking tools setup successfully."
echo ""

# Setup pentesting workspace
echo "Step 8/10: Configuring penetration testing workspace..."
mkdir -p /opt/aeos/pentesting/{templates,reports,tools,wordlists}

# Download common wordlists
cd /opt/aeos/pentesting/wordlists
wget -q https://github.com/danielmiessler/SecLists/raw/master/Passwords/Common-Credentials/10-million-password-list-top-1000.txt
wget -q https://github.com/danielmiessler/SecLists/raw/master/Discovery/Web-Content/common.txt
wget -q https://github.com/danielmiessler/SecLists/raw/master/Usernames/top-usernames-shortlist.txt

# Create report template
cat > /opt/aeos/pentesting/templates/report_template.md << 'EOF'
# Penetration Test Report

## Executive Summary

[Provide a brief summary of the penetration test, including scope, objectives, and key findings]

## Scope

**Target Systems:**
- [List target systems, IP ranges, domains, etc.]

**Testing Period:**
- Start Date: [YYYY-MM-DD]
- End Date: [YYYY-MM-DD]

**Testing Type:**
- [e.g., Black Box, Grey Box, White Box]

## Findings Summary

| Severity | Count | Description |
|----------|-------|-------------|
| Critical | 0     | Vulnerabilities that pose an immediate threat |
| High     | 0     | Significant vulnerabilities requiring prompt attention |
| Medium   | 0     | Moderate risk vulnerabilities |
| Low      | 0     | Minor issues with minimal impact |
| Info     | 0     | Informational findings |

## Detailed Findings

### [Finding Title] - [Severity]

**Description:**
[Detailed description of the finding]

**Affected Systems:**
- [List affected systems]

**Proof of Concept:**
[Steps to reproduce or evidence]

**Impact:**
[Description of the potential impact]

**Recommendation:**
[Steps to remediate the issue]

## Methodology

1. Reconnaissance
2. Scanning and Enumeration
3. Vulnerability Assessment
4. Exploitation
5. Post-Exploitation
6. Reporting

## Tools Used

- [List tools used during the penetration test]

## Conclusion

[Summarize the overall security posture and key recommendations]

## Appendices

[Any additional information, screenshots, logs, etc.]
EOF

# Create pentesting quick-start script
cat > /opt/aeos/pentesting/start_assessment.sh << 'EOF'
#!/bin/bash

# ÆOS Penetration Testing Quick Start
echo "======================================================"
echo "      ÆOS Penetration Testing - Quick Start           "
echo "======================================================"

# Create project directory
read -p "Enter project name: " PROJECT_NAME
PROJECT_DIR="/home/aeos/pentests/$PROJECT_NAME"

if [ -d "$PROJECT_DIR" ]; then
  read -p "Project directory already exists. Overwrite? (y/n): " OVERWRITE
  if [ "$OVERWRITE" != "y" ]; then
    echo "Aborting."
    exit 1
  fi
fi

mkdir -p "$PROJECT_DIR"/{recon,scan,exploit,report,evidence,notes}

# Copy report template
cp /opt/aeos/pentesting/templates/report_template.md "$PROJECT_DIR/report/report.md"

# Create target list
read -p "Enter target IP or domain: " TARGET
echo "$TARGET" > "$PROJECT_DIR/targets.txt"

# Create initial scan script
cat > "$PROJECT_DIR/scan/initial_scan.sh" << SCANEOF
#!/bin/bash
# Initial scan script for $PROJECT_NAME

echo "Running initial reconnaissance on $TARGET"
mkdir -p "$PROJECT_DIR/scan/results"

# Run nmap scan
echo "Running Nmap scan..."
nmap -sV -sC -oA "$PROJECT_DIR/scan/results/nmap_initial" "$TARGET"

# Run directory scan
echo "Running directory enumeration..."
dirb http://$TARGET /opt/aeos/pentesting/wordlists/common.txt -o "$PROJECT_DIR/scan/results/dirb_results.txt"

echo "Initial scan complete. Results saved to $PROJECT_DIR/scan/results/"
SCANEOF

chmod +x "$PROJECT_DIR/scan/initial_scan.sh"

echo "Project setup complete! Your pentest workspace is ready at $PROJECT_DIR"
echo "To start your initial scan, run: $PROJECT_DIR/scan/initial_scan.sh"
echo ""
echo "Penetration testing workflow:"
echo "1. Complete your target definition in $PROJECT_DIR/targets.txt"
echo "2. Run reconnaissance and scanning scripts in $PROJECT_DIR/scan/"
echo "3. Document findings and evidence in $PROJECT_DIR/evidence/"
echo "4. Update your report at $PROJECT_DIR/report/report.md"
echo "5. Take notes during testing in $PROJECT_DIR/notes/"
echo ""
echo "Happy hacking! (Ethically, of course)"
EOF

chmod +x /opt/aeos/pentesting/start_assessment.sh

# Create desktop shortcut
cat > /usr/share/applications/aeos-pentesting.desktop << EOF
[Desktop Entry]
Name=ÆOS Penetration Testing
Comment=Start a new penetration testing project
Exec=/opt/aeos/pentesting/start_assessment.sh
Icon=/opt/aeos/icons/pentest.png
Terminal=true
Type=Application
Categories=ÆOS-Tools;
EOF

echo "Penetration testing workspace configured successfully."
echo ""

# Setup forensics toolkit
echo "Step 9/10: Setting up digital forensics toolkit..."
apt-get install -y autopsy sleuthkit dc3dd testdisk foremost scalpel \
  bulk_extractor gdb ghidra radare2 binwalk

# Create forensics workspace
mkdir -p /opt/aeos/forensics/{templates,cases,tools}

# Create forensics helper script
cat > /opt/aeos/forensics/create_case.sh << 'EOF'
#!/bin/bash

# ÆOS Digital Forensics Case Creation
echo "======================================================"
echo "      ÆOS Digital Forensics - New Case Setup          "
echo "======================================================"

# Get case information
read -p "Enter case number/ID: " CASE_ID
read -p "Enter case name: " CASE_NAME
read -p "Enter investigator name: " INVESTIGATOR
read -p "Enter evidence source (e.g., hard drive, memory dump): " EVIDENCE_SOURCE

# Sanitize inputs for file naming
CASE_ID_CLEAN=$(echo "$CASE_ID" | tr -cd '[:alnum:]-_')
CASE_NAME_CLEAN=$(echo "$CASE_NAME" | tr -cd '[:alnum:]-_ ')

# Create case directory
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
CASE_DIR="/home/aeos/forensics/$CASE_ID_CLEAN-$TIMESTAMP"
mkdir -p "$CASE_DIR"/{evidence,analysis,reports,notes,tools,chain_of_custody}

# Create case info file
cat > "$CASE_DIR/case_info.txt" << CASEINFO
Case ID: $CASE_ID
Case Name: $CASE_NAME
Investigator: $INVESTIGATOR
Evidence Source: $EVIDENCE_SOURCE
Date Created: $(date +"%Y-%m-%d %H:%M:%S")
CASEINFO

# Create chain of custody template
cat > "$CASE_DIR/chain_of_custody/chain_of_custody.txt" << CHAININFO
===============================================
CHAIN OF CUSTODY - CASE $CASE_ID
===============================================

EVIDENCE ITEM:
Description: $EVIDENCE_SOURCE
Identifier: 

CHAIN OF CUSTODY LOG:
1. $(date +"%Y-%m-%d %H:%M:%S") - Evidence received by $INVESTIGATOR for analysis
   Hash: [HASH TO BE ADDED]

[Add additional transfers below with date, time, person, action, and verification hash]

===============================================
HANDLING INSTRUCTIONS:
- Document all access to the evidence
- Calculate and verify hash values before and after analysis
- Store evidence in secure location when not in use
===============================================
CHAININFO

# Create initial analysis checklist
cat > "$CASE_DIR/analysis/analysis_checklist.txt" << CHECKLIST
# $CASE_NAME - Analysis Checklist

## Initial Steps
- [ ] Create forensic image/copy of evidence
- [ ] Verify hash of the evidence
- [ ] Document evidence details

## Analysis Tasks
- [ ] File system analysis
- [ ] Timeline creation
- [ ] File carving
- [ ] Registry analysis (if Windows)
- [ ] Log file examination
- [ ] Artifact analysis
- [ ] Keyword searching
- [ ] Memory analysis (if memory dump available)
- [ ] Network traffic analysis (if network capture available)

## Reporting
- [ ] Document findings
- [ ] Capture screenshots of evidence
- [ ] Prepare final report
- [ ] Review findings and evidence
CHECKLIST

# Create autopsy case script
cat > "$CASE_DIR/tools/start_autopsy.sh" << AUTOSTART
#!/bin/bash
# Start Autopsy for $CASE_NAME

# Create Autopsy case directory
mkdir -p "$CASE_DIR/analysis/autopsy"

# Start Autopsy
autopsy
AUTOSTART
chmod +x "$CASE_DIR/tools/start_autopsy.sh"

echo "Case setup complete! Your forensics workspace is ready at $CASE_DIR"
echo ""
echo "Recommended workflow:"
echo "1. Document evidence in chain of custody log"
echo "2. Create forensic images of your evidence"
echo "3. Calculate and verify hashes"
echo "4. Begin analysis using tools in $CASE_DIR/tools/"
echo "5. Document your findings"
echo "6. Prepare your report"
echo ""
echo "Remember to maintain chain of custody and document all actions!"
EOF

chmod +x /opt/aeos/forensics/create_case.sh

# Create desktop shortcut
cat > /usr/share/applications/aeos-forensics.desktop << EOF
[Desktop Entry]
Name=ÆOS Digital Forensics
Comment=Start a new digital forensics case
Exec=/opt/aeos/forensics/create_case.sh
Icon=/opt/aeos/icons/forensics.png
Terminal=true
Type=Application
Categories=ÆOS-Tools;
EOF

echo "Digital forensics toolkit setup successfully."
echo ""

# Finalize the update
echo "Step 10/10: Finalizing update and cleaning up..."

# Update ÆOS version
mkdir -p /etc/aeos
echo "ÆOS - Advanced Ethical Hacking OS v1.0 Final" > /etc/aeos/version

# Clean unnecessary packages
apt-get autoremove -y
apt-get autoclean -y

# Update system locales
locale-gen en_US.UTF-8

# Create update completion log
mkdir -p /var/log/aeos
UPDATE_END_DATE=$(date +"%Y-%m-%d %H:%M:%S")
echo "$UPDATE_DATE to $UPDATE_END_DATE - Final System Update" >> /var/log/aeos/updates.log

echo "======================================================"
echo "      ÆOS Final Update Completed Successfully!        "
echo "======================================================"
echo ""
echo "Your ÆOS system is now fully updated with all the latest features,"
echo "security tools, and optimizations."
echo ""
echo "Update started: $UPDATE_DATE"
echo "Update completed: $UPDATE_END_DATE"
echo ""
echo "New features and improvements include:"
echo "- Enhanced security tools and frameworks"
echo "- Performance optimizations for VM environments"
echo "- Hardened system security configurations"
echo "- Improved desktop environment and visuals"
echo "- Automated security scanning"
echo "- Advanced networking tools and monitoring"
echo "- Complete penetration testing workspace"
echo "- Digital forensics toolkit and workflow"
echo ""
echo "To launch the ÆOS Dashboard:"
echo "python3 /opt/aeos/ui/dashboard/dashboard_console.py"
echo ""
echo "Thank you for using ÆOS - The Ultimate Ethical Hacking OS!"
echo "======================================================"