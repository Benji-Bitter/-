#!/usr/bin/env python3

"""
CyberOS System Configuration Script
This script applies security-focused configuration to the base system
"""

import os
import json
import subprocess
import sys
import logging
from pathlib import Path
import shutil

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("/var/log/cyberos_setup.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("cyberos-setup")

def run_command(command, shell=False):
    """Run a system command and log output"""
    try:
        if shell:
            process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        else:
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        stdout, stderr = process.communicate()
        
        if stdout:
            logger.info(f"Command output: {stdout.decode('utf-8')}")
        if stderr:
            logger.warning(f"Command error: {stderr.decode('utf-8')}")
        
        return process.returncode == 0
    except Exception as e:
        logger.error(f"Error executing command {command}: {str(e)}")
        return False

def load_config():
    """Load the OS configuration file"""
    config_path = Path("/opt/cyberos/config/os-config.json")
    
    if not config_path.exists():
        logger.error("Configuration file not found")
        sys.exit(1)
        
    try:
        with open(config_path) as f:
            config = json.load(f)
        return config
    except Exception as e:
        logger.error(f"Error loading configuration: {str(e)}")
        sys.exit(1)

def configure_firewall(config):
    """Configure system firewall based on settings"""
    logger.info("Configuring system firewall...")
    
    # Configure UFW (Uncomplicated Firewall)
    run_command(["ufw", "--force", "enable"])
    run_command(["ufw", "default", "deny", "incoming"])
    run_command(["ufw", "default", "allow", "outgoing"])
    
    # Allow SSH
    run_command(["ufw", "allow", "ssh"])
    
    # Allow HTTP/HTTPS
    run_command(["ufw", "allow", "http"])
    run_command(["ufw", "allow", "https"])
    
    # Enable logging
    run_command(["ufw", "logging", "on"])
    
    # Reload firewall
    run_command(["ufw", "reload"])
    
    logger.info("Firewall configuration completed")

def harden_ssh():
    """Harden SSH configuration"""
    logger.info("Hardening SSH configuration...")
    
    ssh_config = "/etc/ssh/sshd_config"
    if not os.path.exists(ssh_config):
        logger.warning("SSH config not found, skipping SSH hardening")
        return
    
    # Backup original config
    shutil.copy2(ssh_config, f"{ssh_config}.bak")
    
    # Update SSH configuration
    ssh_settings = {
        "PermitRootLogin": "no",
        "PasswordAuthentication": "no",
        "PubkeyAuthentication": "yes",
        "PermitEmptyPasswords": "no",
        "X11Forwarding": "no",
        "MaxAuthTries": "3",
        "Protocol": "2",
        "LoginGraceTime": "60",
        "ClientAliveInterval": "300",
        "ClientAliveCountMax": "2"
    }
    
    for setting, value in ssh_settings.items():
        # Comment out existing settings
        run_command(f"sed -i 's/^{setting}.*/#&/' {ssh_config}", shell=True)
        # Add new setting
        run_command(f"echo '{setting} {value}' >> {ssh_config}", shell=True)
    
    # Restart SSH service
    run_command(["systemctl", "restart", "sshd"])
    
    logger.info("SSH hardening completed")

def configure_system_security(config):
    """Configure system security settings"""
    logger.info("Configuring system security...")
    
    # Enable AppArmor
    run_command(["systemctl", "enable", "apparmor"])
    run_command(["systemctl", "start", "apparmor"])
    
    # Configure password policies
    if config.get("system_configuration", {}).get("password_policy"):
        password_policy = config["system_configuration"]["password_policy"]
        
        # Configure PAM password quality requirements
        pwquality_conf = "/etc/security/pwquality.conf"
        if os.path.exists(pwquality_conf):
            with open(pwquality_conf, "a") as f:
                f.write(f"\nminlen = {password_policy.get('min_length', 12)}\n")
                f.write(f"minclass = 4\n")  # Require all character classes
                f.write(f"dcredit = -1\n")  # Require at least one digit
                f.write(f"ucredit = -1\n")  # Require at least one uppercase
                f.write(f"lcredit = -1\n")  # Require at least one lowercase
                f.write(f"ocredit = -1\n")  # Require at least one special char
                f.write(f"retry = 3\n")     # Allow 3 retries
        
        # Configure password aging
        if password_policy.get("max_age_days"):
            run_command(["sed", "-i", 
                        f"s/^PASS_MAX_DAYS.*/PASS_MAX_DAYS {password_policy.get('max_age_days')}/g", 
                        "/etc/login.defs"])
    
    # Enable ASLR (Address Space Layout Randomization)
    with open("/etc/sysctl.d/99-security.conf", "a") as f:
        f.write("kernel.randomize_va_space = 2\n")
    
    # Disable core dumps
    with open("/etc/security/limits.conf", "a") as f:
        f.write("* hard core 0\n")
    
    # Apply sysctl changes
    run_command(["sysctl", "-p", "/etc/sysctl.d/99-security.conf"])
    
    logger.info("System security configuration completed")

def configure_auditd():
    """Configure system auditing with auditd"""
    logger.info("Configuring system auditing...")
    
    # Install auditd if not already installed
    run_command(["apt", "install", "-y", "auditd", "audispd-plugins"])
    
    # Configure audit rules
    audit_rules = """
# Audit system date/time changes
-a always,exit -F arch=b64 -S adjtimex -S settimeofday -S stime -S clock_settime -k time-change
-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -S clock_settime -k time-change

# Audit user/group changes
-w /etc/group -p wa -k identity
-w /etc/passwd -p wa -k identity
-w /etc/shadow -p wa -k identity
-w /etc/sudoers -p wa -k identity

# Audit system admin actions
-w /etc/sudoers -p wa -k actions
-w /var/log/sudo.log -p wa -k actions

# Audit login/logout events
-w /var/log/wtmp -p wa -k session
-w /var/log/btmp -p wa -k session

# Audit suspicious activity
-w /usr/bin/wget -p x -k suspicious
-w /usr/bin/curl -p x -k suspicious
-w /usr/bin/base64 -p x -k suspicious
-w /bin/nc -p x -k suspicious
-w /bin/netcat -p x -k suspicious
-w /usr/bin/ncat -p x -k suspicious

# Audit mount operations
-a always,exit -F arch=b64 -S mount -S umount2 -k mount
-a always,exit -F arch=b32 -S mount -S umount -S umount2 -k mount

# Monitor for use of system calls associated with process execution
-a always,exit -F arch=b64 -S execve -k exec
-a always,exit -F arch=b32 -S execve -k exec
"""
    
    with open("/etc/audit/rules.d/cyberos.rules", "w") as f:
        f.write(audit_rules)
    
    # Enable and start auditd
    run_command(["systemctl", "enable", "auditd"])
    run_command(["systemctl", "start", "auditd"])
    run_command(["auditctl", "-R", "/etc/audit/rules.d/cyberos.rules"])
    
    logger.info("System auditing configuration completed")

def setup_malware_scanning():
    """Configure ClamAV for malware scanning"""
    logger.info("Setting up malware scanning...")
    
    # Install ClamAV if not already installed
    run_command(["apt", "install", "-y", "clamav", "clamav-daemon"])
    
    # Update virus definitions
    run_command(["systemctl", "stop", "clamav-freshclam"])
    run_command(["freshclam"])
    run_command(["systemctl", "start", "clamav-freshclam"])
    run_command(["systemctl", "enable", "clamav-freshclam"])
    
    # Set up daily scan cron job
    cron_job = "0 2 * * * /usr/bin/clamscan -r /home --move=/var/quarantine --quiet --infected"
    cron_file = "/etc/cron.d/clamav-scan"
    
    # Create quarantine directory
    os.makedirs("/var/quarantine", exist_ok=True)
    
    with open(cron_file, "w") as f:
        f.write(f"{cron_job}\n")
    
    # Set proper permissions
    os.chmod(cron_file, 0o644)
    
    logger.info("Malware scanning setup completed")

def main():
    """Main configuration function"""
    logger.info("Starting CyberOS system configuration")
    
    if os.geteuid() != 0:
        logger.error("This script must be run as root")
        sys.exit(1)
    
    try:
        # Load configuration
        config = load_config()
        
        # Configure system security components
        configure_firewall(config)
        harden_ssh()
        configure_system_security(config)
        configure_auditd()
        setup_malware_scanning()
        
        logger.info("CyberOS system configuration completed successfully")
    except Exception as e:
        logger.error(f"Error during system configuration: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
