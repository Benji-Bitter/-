#!/bin/bash

# CyberOS Development Tools Installation Script
# This script installs essential development tools and programming languages

# Exit on any error
set -e

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (sudo bash install_dev_tools.sh)"
  exit 1
fi

echo "======================================================"
echo "      Installing CyberOS Development Tools            "
echo "======================================================"

# Update system
apt update

# Install C/C++ development tools
echo "Installing C/C++ development tools..."
apt install -y build-essential cmake gcc g++ gdb clang clang-format clang-tidy llvm valgrind

# Install Python development tools
echo "Installing Python development tools..."
apt install -y python3 python3-pip python3-dev python3-venv ipython3 pylint

# Install essential Python libraries
pip3 install -U black flake8 pytest mypy isort jupyter notebook

# Install Rust
echo "Installing Rust..."
if ! command -v rustc > /dev/null; then
    apt install -y curl
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    source $HOME/.cargo/env
    rustup component add clippy rustfmt
    rustup toolchain install nightly
fi

# Install Go
echo "Installing Go..."
apt install -y golang-go

# Install JavaScript/TypeScript development tools
echo "Installing JavaScript/TypeScript development tools..."
apt install -y nodejs npm
npm install -g typescript ts-node eslint prettier

# Install Java development tools
echo "Installing Java development tools..."
apt install -y default-jdk ant maven gradle

# Install version control systems
echo "Installing version control systems..."
apt install -y git git-lfs mercurial subversion

# Install build tools and utilities
echo "Installing build tools and utilities..."
apt install -y autoconf automake libtool pkg-config make ninja-build meson

# Install database development tools
echo "Installing database development tools..."
apt install -y sqlite3 libsqlite3-dev postgresql-client mysql-client

# Install editor dependencies
echo "Installing editor dependencies..."
apt install -y vim nano emacs neovim

# Install documentation tools
echo "Installing documentation tools..."
apt install -y doxygen graphviz pandoc texlive-latex-base

# Install debuggers and profilers
echo "Installing debuggers and profilers..."
apt install -y strace ltrace gdb rr perf-tools-unstable linux-tools-common linux-tools-generic

# Install networking tools for developers
echo "Installing networking tools for developers..."
apt install -y curl wget netcat socat mtr traceroute whois

# Install Docker for container development
echo "Installing Docker..."
apt install -y apt-transport-https ca-certificates gnupg lsb-release
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
echo "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
apt update
apt install -y docker-ce docker-ce-cli containerd.io
systemctl enable docker
systemctl start docker

# Install VSCode if desired
echo "Installing Visual Studio Code..."
apt install -y software-properties-common
wget -qO- https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > packages.microsoft.gpg
install -o root -g root -m 644 packages.microsoft.gpg /etc/apt/trusted.gpg.d/
echo "deb [arch=amd64 signed-by=/etc/apt/trusted.gpg.d/packages.microsoft.gpg] https://packages.microsoft.com/repos/vscode stable main" > /etc/apt/sources.list.d/vscode.list
apt update
apt install -y code
rm -f packages.microsoft.gpg

# Install essential VSCode extensions
echo "Installing VSCode extensions..."
code --install-extension ms-vscode.cpptools
code --install-extension ms-python.python
code --install-extension rust-lang.rust-analyzer
code --install-extension golang.go
code --install-extension ms-vscode.cmake-tools
code --install-extension esbenp.prettier-vscode
code --install-extension dbaeumer.vscode-eslint
code --install-extension ms-azuretools.vscode-docker

# Create IDE configuration directory
IDE_CONFIG_DIR="/opt/cyberos/ide/config"
mkdir -p "$IDE_CONFIG_DIR"

# Set up custom IDE configuration
echo "Setting up IDE configuration..."
cat > "$IDE_CONFIG_DIR/vscode_settings.json" << EOF
{
  "editor.fontFamily": "Source Code Pro, Consolas, 'Courier New', monospace",
  "editor.fontSize": 14,
  "editor.lineHeight": 24,
  "editor.rulers": [80, 120],
  "editor.formatOnSave": true,
  "editor.renderWhitespace": "boundary",
  "editor.suggestSelection": "first",
  "editor.minimap.enabled": true,
  "editor.cursorBlinking": "smooth",
  "editor.cursorSmoothCaretAnimation": "on",
  "editor.tabSize": 4,
  "editor.insertSpaces": true,
  "editor.wordWrap": "off",
  "workbench.colorTheme": "Default Dark+",
  "workbench.iconTheme": "vs-seti",
  "files.autoSave": "afterDelay",
  "files.autoSaveDelay": 1000,
  "files.trimTrailingWhitespace": true,
  "files.insertFinalNewline": true,
  "terminal.integrated.fontFamily": "MesloLGS NF, Menlo, Monaco, 'Courier New', monospace",
  "terminal.integrated.fontSize": 13,
  "git.enableSmartCommit": true,
  "git.autofetch": true,
  "python.linting.enabled": true,
  "python.linting.pylintEnabled": true,
  "python.formatting.provider": "black",
  "python.formatting.blackArgs": ["--line-length", "88"],
  "C_Cpp.clang_format_style": "{ BasedOnStyle: Google, IndentWidth: 4, ColumnLimit: 120 }",
  "rust-analyzer.checkOnSave.command": "clippy",
  "go.formatTool": "goimports",
  "javascript.format.enable": true,
  "javascript.updateImportsOnFileMove.enabled": "always",
  "typescript.updateImportsOnFileMove.enabled": "always"
}
EOF

echo "======================================================"
echo "      Development Tools Installation Complete         "
echo "======================================================"
