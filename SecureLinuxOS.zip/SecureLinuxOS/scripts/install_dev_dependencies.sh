#!/bin/bash

# ÆOS Development Dependencies Installation Script
# This script installs all dependencies required for ÆOS development

# Exit on any error
set -e

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (sudo bash install_dev_dependencies.sh)"
  exit 1
fi

echo "======================================================"
echo "      Installing ÆOS Development Dependencies          "
echo "======================================================"

# Update system
apt update
apt upgrade -y

# Install core build dependencies
echo "Installing core build dependencies..."
apt install -y build-essential git curl wget squashfs-tools xorriso isolinux \
  memtest86+ grub-pc-bin grub-efi-amd64-bin mtools debootstrap

# Install Python dependencies
echo "Installing Python dependencies..."
apt install -y python3 python3-pip python3-dev python3-venv

# Install UI development tools
echo "Installing UI development tools..."
apt install -y python3-pyqt5 python3-matplotlib python3-psutil

# Install documentation tools
echo "Installing documentation tools..."
apt install -y pandoc texlive-xetex

# Set up Python virtual environment
if [ ! -d "venv" ]; then
  echo "Setting up Python virtual environment..."
  python3 -m venv venv
  . venv/bin/activate
  pip install --upgrade pip
  pip install -r requirements.txt
else
  echo "Python virtual environment already exists."
fi

# Install Docker (for containerized builds)
echo "Installing Docker..."
apt install -y apt-transport-https ca-certificates gnupg lsb-release
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
echo \
  "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
apt update
apt install -y docker-ce docker-ce-cli containerd.io

# Create requirements.txt if it doesn't exist
if [ ! -f "requirements.txt" ]; then
  echo "Creating requirements.txt..."
  cat > requirements.txt << EOF
# ÆOS Python Dependencies
PyQt5>=5.15.0
matplotlib>=3.5.0
numpy>=1.21.0
psutil>=5.8.0
pytest>=6.2.5
black>=21.5b2
flake8>=3.9.2
sphinx>=4.0.2
pytest-cov>=2.12.1
EOF
fi

echo "======================================================"
echo "      Development Dependencies Installation Complete   "
echo "======================================================"

echo "The following development tools have been installed:"
echo "  - Build essentials (gcc, make, etc.)"
echo "  - ISO building tools (squashfs-tools, xorriso, isolinux)"
echo "  - Python development environment"
echo "  - UI development libraries (PyQt5, matplotlib)"
echo "  - Docker for containerized builds"
echo "  - Documentation tools (pandoc, texlive)"
echo ""
echo "You can now build ÆOS with ./scripts/create_iso.sh"