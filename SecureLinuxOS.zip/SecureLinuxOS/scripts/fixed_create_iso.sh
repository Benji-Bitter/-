#!/bin/bash

###############################################################################
#                       ÆOS ISO Creation Script                               #
#                                                                             #
# This script builds a complete, bootable ISO image of the ÆOS system         #
# with all security tools, customizations, and optimizations pre-installed.   #
#                                                                             #
# The resulting ISO can be:                                                   #
# - Burned to a USB drive for booting on physical hardware                    #
# - Used directly in virtual machines like VirtualBox or VMware               #
# - Deployed to cloud environments that support custom images                 #
###############################################################################

# Exit on any error
set -e

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (sudo bash create_iso.sh)"
  exit 1
fi

echo "======================================================"
echo "      ÆOS ISO Creation Script                         "
echo "======================================================"

# Base directory
BASE_DIR="$(pwd)"
WORK_DIR="/tmp/aeos-iso"
OUTPUT_DIR="${BASE_DIR}/output"
ISO_NAME="aeos-$(date +%Y%m%d).iso"

# Create working directories
mkdir -p "${WORK_DIR}/iso"
mkdir -p "${WORK_DIR}/squashfs"
mkdir -p "${OUTPUT_DIR}"

# Install required packages
echo "Installing required packages..."
apt-get update
apt-get install -y squashfs-tools xorriso isolinux memtest86+ grub-pc-bin grub-efi-amd64-bin mtools

# Set up base system
echo "Setting up base system..."
debootstrap --arch=amd64 bullseye "${WORK_DIR}/squashfs"

# Mount necessary filesystems for chroot
mount --bind /dev "${WORK_DIR}/squashfs/dev"
mount --bind /dev/pts "${WORK_DIR}/squashfs/dev/pts"
mount -t proc none "${WORK_DIR}/squashfs/proc"
mount -t sysfs none "${WORK_DIR}/squashfs/sys"

# Configure base system
cat > "${WORK_DIR}/squashfs/root/setup.sh" << 'EOF'
#!/bin/bash
set -e

echo "======================================================"
echo "      Building ÆOS - The Ultimate Cybersecurity OS    "
echo "======================================================"

# Set up repositories
cat > /etc/apt/sources.list << 'EOSOURCES'
deb http://deb.debian.org/debian bullseye main contrib non-free
deb http://security.debian.org/debian-security bullseye-security main contrib non-free
deb http://deb.debian.org/debian bullseye-updates main contrib non-free
EOSOURCES

# Update and install essential packages
echo "Installing base system packages..."
apt-get update
apt-get install -y --no-install-recommends linux-image-amd64 live-boot systemd-sysv \
  network-manager sudo wget curl git ca-certificates bash-completion \
  xserver-xorg-core xserver-xorg-input-all xserver-xorg-video-all \
  xfce4 xfce4-goodies lightdm plymouth plymouth-themes firefox-esr \
  python3 python3-pip python3-dev python3-pyqt5 python3-matplotlib python3-psutil

# Install security essentials
echo "Installing core security packages..."
apt-get install -y net-tools wireshark nmap tcpdump netcat-openbsd hydra \
  sqlmap dirb nikto aircrack-ng hashcat john openvpn tor proxychains \
  metasploit-framework exploitdb

# Install development tools
echo "Installing development tools..."
apt-get install -y build-essential gcc g++ gdb make cmake ninja-build git \
  python3-venv python3-pip nodejs npm golang openjdk-11-jdk ruby \
  vim nano emacs neovim

# Configure hardened security settings
echo "Configuring security hardening..."
# Firewall setup
apt-get install -y ufw
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow http
ufw allow https
echo "y" | ufw enable

# Set up default user with secure defaults
echo "Setting up default user..."
useradd -m -s /bin/bash aeos
echo "aeos:changeme" | chpasswd
usermod -aG sudo aeos

# Set up sudo
echo "aeos ALL=(ALL) NOPASSWD: ALL" > /etc/sudoers.d/aeos
chmod 0440 /etc/sudoers.d/aeos

# Set up ÆOS branding
echo "Setting up ÆOS branding..."
mkdir -p /etc/aeos
echo "ÆOS - Advanced Ethical Hacking OS v1.0" > /etc/aeos/version
echo "ÆOS" > /etc/hostname

# Configure hosts file
cat > /etc/hosts << 'EOHOSTS'
127.0.0.1       localhost
127.0.1.1       ÆOS

# The following lines are desirable for IPv6 capable hosts
::1             localhost ip6-localhost ip6-loopback
ff02::1         ip6-allnodes
ff02::2         ip6-allrouters
EOHOSTS

# Set up dark theme
echo "Setting up dark theme..."
mkdir -p /usr/share/themes/ÆOSDark
# We'd add actual theme files here in a real implementation

# Set up Plymouth boot splash
echo "Setting up custom boot splash..."
plymouth-set-default-theme -R bgrt
mkdir -p /usr/share/plymouth/themes/aeos
cp /boot/splash.png /usr/share/plymouth/themes/aeos/

# Set up desktop environment
echo "Configuring desktop environment..."
mkdir -p /opt/aeos/{icons,backgrounds,themes,tools,scripts}
mkdir -p /usr/share/backgrounds/aeos

# Add desktop shortcuts for tools
mkdir -p /home/aeos/Desktop

# Create XFCE menu structure for security tools
mkdir -p /etc/xdg/menus/applications-merged/
cat > /etc/xdg/menus/applications-merged/aeos-pentesting.menu << 'EOMENU'
<!DOCTYPE Menu PUBLIC "-//freedesktop//DTD Menu 1.0//EN"
 "http://www.freedesktop.org/standards/menu-spec/1.0/menu.dtd">
<Menu>
  <Name>Applications</Name>
  <Menu>
    <Name>ÆOS Tools</Name>
    <Directory>aeos-tools.directory</Directory>
    <Include>
      <Category>ÆOS-Tools</Category>
    </Include>
  </Menu>
</Menu>
EOMENU

# Create directories file
mkdir -p /usr/share/desktop-directories/
cat > /usr/share/desktop-directories/aeos-tools.directory << 'EODIR'
[Desktop Entry]
Name=ÆOS Security Tools
Icon=applications-hacking
Type=Directory
EODIR

# Create desktop file for launching the dashboard
cat > /usr/share/applications/aeos-dashboard.desktop << 'EODESKTOP'
[Desktop Entry]
Name=ÆOS Dashboard
Comment=System monitoring and security dashboard
Exec=/opt/aeos/ui/dashboard/dashboard_console.py
Icon=/opt/aeos/icons/dashboard.png
Terminal=true
Type=Application
Categories=ÆOS-Tools;
EODESKTOP

# Configure automatic updates
echo "Setting up automatic security updates..."
apt-get install -y unattended-upgrades apt-listchanges
cat > /etc/apt/apt.conf.d/20auto-upgrades << 'EOUPGRADE'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::AutocleanInterval "7";
EOUPGRADE

# Configure SSH server with secure defaults
echo "Configuring secure SSH server..."
apt-get install -y openssh-server
cat > /etc/ssh/sshd_config.d/hardened.conf << 'EOSSH'
Protocol 2
PermitRootLogin no
PasswordAuthentication yes
X11Forwarding no
AllowTcpForwarding yes
AllowAgentForwarding yes
PermitEmptyPasswords no
MaxAuthTries 3
LoginGraceTime 30
EOSSH

# Clean up
echo "Performing final cleanup..."
apt-get clean
rm -rf /var/lib/apt/lists/*

echo "======================================================"
echo "      ÆOS System Setup Complete                       "
echo "======================================================"
EOF

# Copy boot splash
cp "${BASE_DIR}/boot/splash.png" "${WORK_DIR}/squashfs/boot/"

# Make setup script executable
chmod +x "${WORK_DIR}/squashfs/root/setup.sh"

# Execute setup script in chroot
chroot "${WORK_DIR}/squashfs" /bin/bash /root/setup.sh

# Copy project files to the chroot
echo "Copying ÆOS files to the image..."
cp -r "${BASE_DIR}/scripts" "${WORK_DIR}/squashfs/opt/aeos/"
cp -r "${BASE_DIR}/ui" "${WORK_DIR}/squashfs/opt/aeos/"
cp -r "${BASE_DIR}/pentest" "${WORK_DIR}/squashfs/opt/aeos/"
cp -r "${BASE_DIR}/forensics" "${WORK_DIR}/squashfs/opt/aeos/"
cp -r "${BASE_DIR}/crypto" "${WORK_DIR}/squashfs/opt/aeos/"
cp -r "${BASE_DIR}/boot" "${WORK_DIR}/squashfs/opt/aeos/"

# Clean up chroot
rm "${WORK_DIR}/squashfs/root/setup.sh"
umount "${WORK_DIR}/squashfs/sys"
umount "${WORK_DIR}/squashfs/proc"
umount "${WORK_DIR}/squashfs/dev/pts"
umount "${WORK_DIR}/squashfs/dev"

# Create squashfs
echo "Creating squashfs filesystem..."
mksquashfs "${WORK_DIR}/squashfs" "${WORK_DIR}/iso/live/filesystem.squashfs" -comp xz -e boot

# Copy boot files
cp "${WORK_DIR}/squashfs/boot/vmlinuz-"* "${WORK_DIR}/iso/live/vmlinuz"
cp "${WORK_DIR}/squashfs/boot/initrd.img-"* "${WORK_DIR}/iso/live/initrd"

# Set up ISOLINUX bootloader
echo "Setting up bootloader..."
mkdir -p "${WORK_DIR}/iso/isolinux"
cp /usr/lib/ISOLINUX/isolinux.bin "${WORK_DIR}/iso/isolinux/"
cp /usr/lib/syslinux/modules/bios/*.c32 "${WORK_DIR}/iso/isolinux/"

# Create isolinux.cfg
cat > "${WORK_DIR}/iso/isolinux/isolinux.cfg" << 'EOF'
UI menu.c32

PROMPT 0
MENU TITLE ÆOS Boot Menu
TIMEOUT 30
DEFAULT aeos

LABEL aeos
  MENU LABEL ÆOS - Advanced Ethical Hacking OS
  LINUX /live/vmlinuz
  INITRD /live/initrd
  APPEND boot=live quiet splash

LABEL aeos_failsafe
  MENU LABEL ÆOS - Failsafe Mode
  LINUX /live/vmlinuz
  INITRD /live/initrd
  APPEND boot=live nomodeset

LABEL memtest
  MENU LABEL Memory Test
  LINUX /live/memtest
EOF

# Copy memtest
cp /boot/memtest86+.bin "${WORK_DIR}/iso/live/memtest"

# Set up GRUB for EFI boot
mkdir -p "${WORK_DIR}/iso/boot/grub"
cat > "${WORK_DIR}/iso/boot/grub/grub.cfg" << 'EOF'
insmod part_gpt
insmod part_msdos
insmod fat
insmod iso9660

set default="0"
set timeout=30

# UEFI firmware workaround
if [ "${grub_platform}" == "efi" ]; then
    set timeout=0
    terminal_output console
    search --no-floppy --file --set=root /live/vmlinuz
    linux /live/vmlinuz boot=live quiet splash
    initrd /live/initrd
    boot
fi

menuentry "ÆOS - Advanced Ethical Hacking OS" {
    search --no-floppy --file --set=root /live/vmlinuz
    linux /live/vmlinuz boot=live quiet splash
    initrd /live/initrd
}

menuentry "ÆOS - Failsafe Mode" {
    search --no-floppy --file --set=root /live/vmlinuz
    linux /live/vmlinuz boot=live nomodeset
    initrd /live/initrd
}
EOF

# Create EFI directory structure
mkdir -p "${WORK_DIR}/iso/EFI/BOOT"
grub-mkstandalone --format=x86_64-efi --output="${WORK_DIR}/iso/EFI/BOOT/BOOTX64.EFI" \
    --locales="" --fonts="" "boot/grub/grub.cfg=${WORK_DIR}/iso/boot/grub/grub.cfg"

# Create the ISO
echo "Creating ISO image..."
xorriso -as mkisofs -iso-level 3 -o "${OUTPUT_DIR}/${ISO_NAME}" \
    -full-iso9660-filenames -volid "ÆOS" \
    -isohybrid-mbr /usr/lib/ISOLINUX/isohdpfx.bin \
    -eltorito-boot isolinux/isolinux.bin -no-emul-boot -boot-load-size 4 -boot-info-table \
    --eltorito-catalog isolinux/boot.cat \
    --grub2-boot-info --grub2-mbr /usr/lib/grub/i386-pc/boot_hybrid.img \
    -eltorito-alt-boot -e EFI/BOOT/BOOTX64.EFI -no-emul-boot -isohybrid-gpt-basdat \
    -append_partition 2 0xef "${WORK_DIR}/iso/EFI/BOOT/BOOTX64.EFI" \
    "${WORK_DIR}/iso"

# Clean up
echo "Cleaning up..."
rm -rf "${WORK_DIR}"

# Output success message
echo "======================================================"
echo "      ÆOS ISO Creation Completed Successfully!        "
echo "======================================================"
echo ""
echo "ISO File: ${OUTPUT_DIR}/${ISO_NAME}"
echo "Size: $(du -h ${OUTPUT_DIR}/${ISO_NAME} | cut -f1)"
echo ""
echo "Installation Instructions:"
echo "------------------------"
echo "1. Burn to USB drive:"
echo "   sudo dd if=${OUTPUT_DIR}/${ISO_NAME} of=/dev/sdX bs=4M status=progress"
echo "   (Replace /dev/sdX with your USB drive device)"
echo ""
echo "2. Boot from the USB drive or use in a virtual machine"
echo ""
echo "3. Log in with these credentials:"
echo "   Username: aeos"
echo "   Password: changeme"
echo ""
echo "4. Change your password immediately using:"
echo "   passwd"
echo ""
echo "For more information and documentation, visit:"
echo "https://github.com/yourusername/aeos"
echo ""
echo "Remember: This OS is for ethical hacking and security"
echo "research purposes only. Always use responsibly."
echo "======================================================"