# ÆOS - Advanced Ethical Hacking Operating System

<div align="center">
  <img src="boot/splash.png" alt="ÆOS Logo" width="300">
  <h3>The Ultimate Cybersecurity-Focused Linux Distribution</h3>
  <p><strong>Kali Linux Redefined: 100x Better, Faster, and More Powerful</strong></p>
</div>

## 🔒 Overview

ÆOS (Advanced Ethical Hacking Operating System) is a powerful cybersecurity-focused Linux distribution designed as a significant improvement over Kali Linux and other security-oriented operating systems. Combining cutting-edge hacking and penetration testing tools with a modern, dark-themed UI/UX, ÆOS provides security professionals with an efficient, visually appealing, and feature-rich platform for ethical hacking and security research.

## 🚀 Quick Start Guide

### Getting ÆOS Running in 3 Simple Steps

1. **Clone and prepare the repository**
   ```bash
   # Clone the repository
   git clone https://github.com/yourusername/aeos.git
   cd aeos
   
   # Make scripts executable
   chmod +x scripts/*.sh
   ```

2. **Build the ISO**
   ```bash
   # Install build dependencies
   sudo ./scripts/install_dev_dependencies.sh
   
   # Create the ÆOS bootable ISO
   sudo ./scripts/fixed_create_iso.sh
   
   # The ISO will be in the ./output directory
   ```

3. **Run in a VM**
   ```bash
   # If using VirtualBox
   VBoxManage createvm --name "ÆOS" --ostype "Debian_64" --register
   VBoxManage modifyvm "ÆOS" --memory 4096 --cpus 2 --vram 128
   VBoxManage createhd --filename "ÆOS.vdi" --size 30000
   VBoxManage storagectl "ÆOS" --name "SATA" --add sata
   VBoxManage storageattach "ÆOS" --storagectl "SATA" --port 0 --device 0 --type hdd --medium "ÆOS.vdi"
   VBoxManage storageattach "ÆOS" --storagectl "SATA" --port 1 --device 0 --type dvddrive --medium output/aeos-YYYYMMDD.iso
   VBoxManage startvm "ÆOS"
   ```
   
   For detailed VM setup instructions, see [VM Setup Guide](docs/VM_SETUP.md).

### Uploading to GitHub

1. **Create a GitHub repository**
   ```bash
   # Initialize git repository
   git init
   git add .
   git commit -m "Initial commit of ÆOS - Advanced Ethical Hacking OS"
   
   # Add GitHub remote and push
   git remote add origin https://github.com/yourusername/aeos.git
   git push -u origin main
   ```

2. **Create a release with the ISO**
   - Go to your GitHub repository page
   - Click "Releases" in the right sidebar
   - Click "Create a new release"
   - Set the tag version (e.g., "v1.0")
   - Attach your ISO file
   - Publish the release

For detailed GitHub setup instructions, see [GitHub Setup Guide](github/GITHUB_SETUP.md).

## ⚡ Key Features

- **🛠️ Comprehensive Security Tools**: Complete suite of pre-installed penetration testing, forensics, and vulnerability assessment tools
- **🖥️ Modern Dark UI**: Sleek, visually appealing dark-themed interface with intuitive navigation
- **🚀 Enhanced Performance**: Optimized for speed and efficiency, even on resource-constrained hardware
- **🔐 Hardened Security**: Built-in security features to protect the OS itself from compromise
- **🧩 Modular Design**: Easily extensible architecture for adding new tools and capabilities
- **📊 Real-time Monitoring**: Advanced system and network monitoring dashboard
- **👨‍💻 Integrated Development**: Built-in IDE and development tools for security research
- **📚 Extensive Documentation**: Comprehensive guides and references for all included tools

## ⚠️ DISCLAIMER

**ÆOS is designed for ETHICAL and LEGAL use only.**

This operating system contains powerful security testing tools that should only be used:
- With explicit permission from system owners
- On your own systems for educational purposes
- In authorized security assessments and penetration tests

The developers of ÆOS take NO RESPONSIBILITY for any misuse of these tools. If you use this operating system to commit illegal activities, you are solely responsible for the consequences. Unauthorized access to computer systems is a criminal offense in most jurisdictions.

## 🔧 Installation

### System Requirements

- 64-bit x86 processor (x86_64 / AMD64)
- Minimum 4GB RAM (8GB+ recommended)
- 20GB free disk space
- Internet connection for updates
- USB drive (8GB+) for installation media

### Setup Instructions

#### 1. Getting the ISO

You can either download a pre-built ISO image or build one yourself:

**Option A: Download ISO**
```bash
# Coming soon - the ISO will be available for download
```

**Option B: Build ISO from Source**
```bash
# Clone the repository
git clone https://github.com/yourusername/aeos.git
cd aeos

# Install build dependencies
sudo ./scripts/install_dev_dependencies.sh

# Build the ISO
sudo ./scripts/fixed_create_iso.sh

# The ISO file will be in the ./output directory
```

#### 2. Creating Bootable USB

**Using dd (Linux/macOS)**
```bash
# Replace /dev/sdX with your USB device (be careful to get this right!)
sudo dd if=aeos-YYYYMMDD.iso of=/dev/sdX bs=4M status=progress
```

**Using Etcher (All platforms)**
1. Download and install [Etcher](https://www.balena.io/etcher/)
2. Open Etcher, select the ÆOS ISO file
3. Select your USB drive
4. Click "Flash!"

#### 3. Booting from USB

1. Insert the USB drive into the target computer
2. Restart the computer and enter the boot menu (typically by pressing F12, F10, or Esc during startup)
3. Select the USB drive from the boot menu
4. Choose "ÆOS - Advanced Ethical Hacking OS" from the boot menu

#### 4. Installation to Hard Drive

1. Once booted into the live environment, double-click the "Install ÆOS" icon on the desktop
2. Follow the graphical installer prompts
3. Reboot when installation completes
4. Remove the USB drive when prompted

#### 5. First Login

Default credentials:
- Username: `aeos`
- Password: `changeme`

**Important:** Change your password immediately after first login by running:
```bash
passwd
```

## 🧰 Included Security Tools

ÆOS comes packed with a wide array of security tools organized into categories:

### Network Analysis & Reconnaissance
- Wireshark, tshark, tcpdump
- Nmap, Masscan, hping3
- Scapy, netcat, socat
- Aircrack-ng, Kismet, Wifite

### Web Application Security
- OWASP ZAP, Burp Suite
- SQLmap, NoSQLmap
- Nikto, Wapiti, Dirb
- WPScan, CMSmap

### Exploitation Frameworks
- Metasploit Framework
- BeEF, Empire, Koadic
- Exploit-DB collection

### Password & Crypto Tools
- John the Ripper, Hashcat
- Hydra, Medusa
- OpenSSL, GnuPG

### Forensics & Reverse Engineering
- Volatility Framework
- Autopsy, Sleuth Kit
- Ghidra, Radare2
- Binwalk, Foremost

### Security Assessment
- OpenVAS
- Lynis
- OWASP ASVS tools

## 🚀 Using ÆOS

### Dashboard

The ÆOS Dashboard provides a central interface for system monitoring and security status. Launch it from the desktop icon or application menu, or by running:

```bash
sudo python3 /opt/aeos/ui/dashboard/dashboard_console.py
```

### Tool Categories

ÆOS organizes tools into logical categories accessible from the main menu:
- **Network**: Tools for network analysis and reconnaissance
- **Web**: Web application security testing tools
- **Exploitation**: Exploitation frameworks and tools
- **Crypto**: Password and cryptography tools
- **Forensics**: Digital forensics and analysis tools
- **Development**: Development and coding tools

### Customization

ÆOS is designed to be highly customizable:

```bash
# Install additional tools
sudo apt update
sudo apt install <package-name>

# Configure UI preferences
xfce4-settings-manager

# Add custom scripts
mkdir -p ~/scripts
```

## 🔄 Updating

Keep your ÆOS system up-to-date with the latest security tools and patches:

```bash
# Update system packages
sudo apt update
sudo apt upgrade

# Update ÆOS core components
cd /opt/aeos
git pull
sudo ./scripts/update.sh
```

## 🤝 Contributing

We welcome contributions to improve ÆOS! Here's how you can help:

1. Fork the repository
2. Create a feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request

See the [CONTRIBUTING.md](github/CONTRIBUTING.md) file for more details.

## 📜 License

This project is open source and available under the MIT License with additional usage restrictions.

## 🔗 Links & Resources

- [Project Website](#) (Coming soon)
- [Documentation](#) (Coming soon)
- [Community Forum](#) (Coming soon)

## 📞 Support

For questions, issues, or feature requests:
- Open an issue on GitHub
- Join our community forum
- Email the maintainers at [your-email@example.com]

---

**Remember:** The power of these tools comes with responsibility. Always use ÆOS ethically and legally.