#!/usr/bin/env python3

"""
CyberDev IDE
A lightweight, security-focused integrated development environment for CyberOS
"""

import os
import sys
import signal
import json
import gi
import subprocess
import tempfile
import threading
import time

gi.require_version('Gtk', '3.0')
gi.require_version('GtkSource', '4')
gi.require_version('Vte', '2.91')
from gi.repository import Gtk, Gdk, GLib, Gio, GtkSource, Vte, Pango

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ide.language_support.python_support import PythonSupport
from ide.language_support.c_cpp_support import CCppSupport
from ide.language_support.rust_support import RustSupport

class CyberDevIDE(Gtk.Window):
    """Main IDE window for CyberOS development environment"""
    
    def __init__(self):
        Gtk.Window.__init__(self, title="CyberDev IDE")
        
        # Set up the window
        self.set_default_size(1200, 800)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.connect("destroy", Gtk.main_quit)
        
        # Initialize language support modules
        self.python_support = PythonSupport()
        self.c_cpp_support = CCppSupport()
        self.rust_support = RustSupport()
        
        # Load configuration
        self.config = self.load_config()
        
        # Initialize ui components
        self.current_file = None
        self.modified = False
        self.init_ui()
        
        # Apply CSS styling
        self.apply_css()
        
        # Set up keyboard shortcuts
        self.setup_accelerators()
        
        # Register signal handlers
        signal.signal(signal.SIGINT, signal.SIG_DFL)
    
    def load_config(self):
        """Load IDE configuration"""
        config_path = "/opt/cyberos/ide/config/vscode_settings.json"
        
        try:
            with open(config_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading configuration: {e}")
            return {
                "editor.fontFamily": "Source Code Pro, Consolas, 'Courier New', monospace",
                "editor.fontSize": 14,
                "editor.tabSize": 4,
                "editor.insertSpaces": True,
                "editor.rulers": [80, 120],
                "editor.wordWrap": "off",
                "workbench.colorTheme": "dark"
            }
    
    def apply_css(self):
        """Apply CSS styling to the IDE"""
        css_provider = Gtk.CssProvider()
        css_path = "/opt/cyberos/ui/theme/dark-theme.css"
        
        try:
            css_provider.load_from_path(css_path)
            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(),
                css_provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )
        except Exception as e:
            print(f"Error loading CSS: {e}")
            # Fallback inline CSS if file not found
            css = b"""
            .sidebar {
                background-color: #16213E;
                color: #F5F5F5;
            }
            .editor {
                background-color: #1A1A2E;
                color: #F5F5F5;
            }
            .terminal {
                background-color: #000000;
                color: #33FF33;
            }
            .sidebar-button {
                padding: 8px;
                border: none;
                background-color: transparent;
                color: #F5F5F5;
                border-radius: 0;
            }
            .sidebar-button:hover {
                background-color: #0F3460;
            }
            .toolbar {
                background-color: #16213E;
                border-bottom: 1px solid #0F3460;
            }
            """
            css_provider.load_from_data(css)
            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(),
                css_provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )
    
    def init_ui(self):
        """Initialize the user interface"""
        # Create main box
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.add(main_box)
        
        # Create toolbar
        toolbar = self.create_toolbar()
        main_box.pack_start(toolbar, False, False, 0)
        
        # Create paned container for sidebar and content
        self.paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        main_box.pack_start(self.paned, True, True, 0)
        
        # Create sidebar
        sidebar = self.create_sidebar()
        self.paned.pack1(sidebar, False, False)
        
        # Create content area (editor and terminal)
        content = self.create_content()
        self.paned.pack2(content, True, False)
        
        # Create status bar
        statusbar = self.create_statusbar()
        main_box.pack_start(statusbar, False, False, 0)
        
        # Set initial pane position
        self.paned.set_position(250)
    
    def create_toolbar(self):
        """Create the IDE toolbar"""
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        toolbar.get_style_context().add_class("toolbar")
        toolbar.set_property("margin", 5)
        
        # File operations
        new_button = self.create_toolbar_button("document-new-symbolic", "New File (Ctrl+N)")
        new_button.connect("clicked", self.on_new_clicked)
        
        open_button = self.create_toolbar_button("document-open-symbolic", "Open File (Ctrl+O)")
        open_button.connect("clicked", self.on_open_clicked)
        
        save_button = self.create_toolbar_button("document-save-symbolic", "Save File (Ctrl+S)")
        save_button.connect("clicked", self.on_save_clicked)
        
        save_as_button = self.create_toolbar_button("document-save-as-symbolic", "Save As (Ctrl+Shift+S)")
        save_as_button.connect("clicked", self.on_save_as_clicked)
        
        # Add separator
        separator1 = Gtk.Separator(orientation=Gtk.Orientation.VERTICAL)
        separator1.set_property("margin", 5)
        
        # Edit operations
        undo_button = self.create_toolbar_button("edit-undo-symbolic", "Undo (Ctrl+Z)")
        undo_button.connect("clicked", self.on_undo_clicked)
        
        redo_button = self.create_toolbar_button("edit-redo-symbolic", "Redo (Ctrl+Shift+Z)")
        redo_button.connect("clicked", self.on_redo_clicked)
        
        cut_button = self.create_toolbar_button("edit-cut-symbolic", "Cut (Ctrl+X)")
        cut_button.connect("clicked", self.on_cut_clicked)
        
        copy_button = self.create_toolbar_button("edit-copy-symbolic", "Copy (Ctrl+C)")
        copy_button.connect("clicked", self.on_copy_clicked)
        
        paste_button = self.create_toolbar_button("edit-paste-symbolic", "Paste (Ctrl+V)")
        paste_button.connect("clicked", self.on_paste_clicked)
        
        # Add separator
        separator2 = Gtk.Separator(orientation=Gtk.Orientation.VERTICAL)
        separator2.set_property("margin", 5)
        
        # Run/build operations
        run_button = self.create_toolbar_button("media-playback-start-symbolic", "Run (F5)")
        run_button.connect("clicked", self.on_run_clicked)
        
        build_button = self.create_toolbar_button("system-run-symbolic", "Build (F6)")
        build_button.connect("clicked", self.on_build_clicked)
        
        debug_button = self.create_toolbar_button("debug-symbolic", "Debug (F9)")
        debug_button.connect("clicked", self.on_debug_clicked)
        
        # Add separator
        separator3 = Gtk.Separator(orientation=Gtk.Orientation.VERTICAL)
        separator3.set_property("margin", 5)
        
        # Help and settings
        settings_button = self.create_toolbar_button("preferences-system-symbolic", "Settings")
        settings_button.connect("clicked", self.on_settings_clicked)
        
        help_button = self.create_toolbar_button("help-browser-symbolic", "Help")
        help_button.connect("clicked", self.on_help_clicked)
        
        # Add all elements to toolbar
        toolbar.pack_start(new_button, False, False, 0)
        toolbar.pack_start(open_button, False, False, 0)
        toolbar.pack_start(save_button, False, False, 0)
        toolbar.pack_start(save_as_button, False, False, 0)
        toolbar.pack_start(separator1, False, False, 0)
        toolbar.pack_start(undo_button, False, False, 0)
        toolbar.pack_start(redo_button, False, False, 0)
        toolbar.pack_start(cut_button, False, False, 0)
        toolbar.pack_start(copy_button, False, False, 0)
        toolbar.pack_start(paste_button, False, False, 0)
        toolbar.pack_start(separator2, False, False, 0)
        toolbar.pack_start(run_button, False, False, 0)
        toolbar.pack_start(build_button, False, False, 0)
        toolbar.pack_start(debug_button, False, False, 0)
        toolbar.pack_start(separator3, False, False, 0)
        toolbar.pack_end(help_button, False, False, 0)
        toolbar.pack_end(settings_button, False, False, 0)
        
        return toolbar
    
    def create_toolbar_button(self, icon_name, tooltip):
        """Create a styled toolbar button"""
        button = Gtk.Button()
        button.set_relief(Gtk.ReliefStyle.NONE)
        button.set_tooltip_text(tooltip)
        
        icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.LARGE_TOOLBAR)
        button.add(icon)
        
        return button
    
    def create_sidebar(self):
        """Create the IDE sidebar"""
        sidebar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        sidebar.set_size_request(250, -1)
        sidebar.get_style_context().add_class("sidebar")
        
        # Create notebook for tabs
        self.sidebar_notebook = Gtk.Notebook()
        self.sidebar_notebook.set_tab_pos(Gtk.PositionType.BOTTOM)
        
        # Create file explorer tab
        file_explorer = self.create_file_explorer()
        file_explorer_label = Gtk.Image.new_from_icon_name("folder-symbolic", Gtk.IconSize.MENU)
        self.sidebar_notebook.append_page(file_explorer, file_explorer_label)
        self.sidebar_notebook.set_tab_tooltip_text(file_explorer, "Explorer")
        
        # Create outline tab
        outline = self.create_outline()
        outline_label = Gtk.Image.new_from_icon_name("view-list-symbolic", Gtk.IconSize.MENU)
        self.sidebar_notebook.append_page(outline, outline_label)
        self.sidebar_notebook.set_tab_tooltip_text(outline, "Outline")
        
        # Create search tab
        search = self.create_search()
        search_label = Gtk.Image.new_from_icon_name("edit-find-symbolic", Gtk.IconSize.MENU)
        self.sidebar_notebook.append_page(search, search_label)
        self.sidebar_notebook.set_tab_tooltip_text(search, "Search")
        
        # Create git tab
        git = self.create_git()
        git_label = Gtk.Image.new_from_icon_name("document-save-as-symbolic", Gtk.IconSize.MENU)
        self.sidebar_notebook.append_page(git, git_label)
        self.sidebar_notebook.set_tab_tooltip_text(git, "Source Control")
        
        # Create debug tab
        debug = self.create_debug()
        debug_label = Gtk.Image.new_from_icon_name("debug-symbolic", Gtk.IconSize.MENU)
        self.sidebar_notebook.append_page(debug, debug_label)
        self.sidebar_notebook.set_tab_tooltip_text(debug, "Debug")
        
        # Add notebook to sidebar
        sidebar.pack_start(self.sidebar_notebook, True, True, 0)
        
        return sidebar
    
    def create_file_explorer(self):
        """Create the file explorer panel"""
        explorer_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        
        # Create toolbar
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        toolbar.set_property("margin", 5)
        
        # Add toolbar buttons
        new_folder_button = self.create_toolbar_button("folder-new-symbolic", "New Folder")
        new_folder_button.connect("clicked", self.on_new_folder_clicked)
        
        new_file_button = self.create_toolbar_button("document-new-symbolic", "New File")
        new_file_button.connect("clicked", self.on_new_file_clicked)
        
        refresh_button = self.create_toolbar_button("view-refresh-symbolic", "Refresh")
        refresh_button.connect("clicked", self.on_refresh_clicked)
        
        # Add buttons to toolbar
        toolbar.pack_start(new_folder_button, False, False, 0)
        toolbar.pack_start(new_file_button, False, False, 0)
        toolbar.pack_end(refresh_button, False, False, 0)
        
        # Add toolbar to explorer box
        explorer_box.pack_start(toolbar, False, False, 0)
        
        # Create a tree view for files
        scrolled_window = Gtk.ScrolledWindow()
        scrolled_window.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        
        # Set up the file tree store and view
        self.file_store = Gtk.TreeStore(str, str, str)  # name, path, icon
        self.file_view = Gtk.TreeView(model=self.file_store)
        self.file_view.set_headers_visible(False)
        
        # Create a column for the file name and icon
        renderer_icon = Gtk.CellRendererPixbuf()
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("Files")
        column.pack_start(renderer_icon, False)
        column.pack_start(renderer_text, True)
        column.add_attribute(renderer_icon, "icon-name", 2)
        column.add_attribute(renderer_text, "text", 0)
        
        self.file_view.append_column(column)
        
        # Connect double-click event to open files
        self.file_view.connect("row-activated", self.on_file_activated)
        
        # Create right-click context menu for files
        self.file_view.connect("button-press-event", self.on_file_right_click)
        
        # Add the tree view to the scrolled window
        scrolled_window.add(self.file_view)
        
        # Add the scrolled window to the explorer box
        explorer_box.pack_start(scrolled_window, True, True, 0)
        
        # Load the current working directory
        self.refresh_file_explorer()
        
        return explorer_box
    
    def refresh_file_explorer(self, path=None):
        """Refresh the file explorer tree view"""
        self.file_store.clear()
        
        # Use current working directory if no path provided
        if not path:
            path = os.getcwd()
        
        # Start from the root of the file system
        self.load_directory(path, None)
    
    def load_directory(self, path, parent):
        """Load a directory into the file explorer"""
        try:
            # Get list of files and dirs in the path
            items = os.listdir(path)
            items.sort()
            
            # First add directories
            for item in items:
                item_path = os.path.join(path, item)
                if os.path.isdir(item_path) and not item.startswith('.'):
                    child = self.file_store.append(parent, [item, item_path, "folder"])
            
            # Then add files
            for item in items:
                item_path = os.path.join(path, item)
                if os.path.isfile(item_path) and not item.startswith('.'):
                    icon = self.get_file_icon(item)
                    self.file_store.append(parent, [item, item_path, icon])
                    
        except Exception as e:
            print(f"Error loading directory {path}: {e}")
    
    def get_file_icon(self, filename):
        """Get the appropriate icon for a file type"""
        extension = os.path.splitext(filename)[1].lower()
        
        if extension in ['.py', '.pyw']:
            return "text-x-python"
        elif extension in ['.c', '.cpp', '.cc', '.h', '.hpp']:
            return "text-x-csrc"
        elif extension in ['.rs']:
            return "text-x-rust"
        elif extension in ['.js', '.json']:
            return "text-x-javascript"
        elif extension in ['.html', '.htm']:
            return "text-html"
        elif extension in ['.css']:
            return "text-css"
        elif extension in ['.xml', '.svg']:
            return "text-xml"
        elif extension in ['.txt', '.md']:
            return "text-x-generic"
        elif extension in ['.sh', '.bash']:
            return "application-x-executable"
        else:
            return "text-x-generic"
    
    def create_outline(self):
        """Create the code outline panel"""
        outline_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        
        # Create scrolled window for outline
        scrolled_window = Gtk.ScrolledWindow()
        scrolled_window.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        
        # Set up the outline tree store and view
        self.outline_store = Gtk.TreeStore(str, str, str)  # name, type, icon
        self.outline_view = Gtk.TreeView(model=self.outline_store)
        self.outline_view.set_headers_visible(False)
        
        # Create a column for the outline items
        renderer_icon = Gtk.CellRendererPixbuf()
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("Elements")
        column.pack_start(renderer_icon, False)
        column.pack_start(renderer_text, True)
        column.add_attribute(renderer_icon, "icon-name", 2)
        column.add_attribute(renderer_text, "text", 0)
        
        self.outline_view.append_column(column)
        
        # Connect click event to navigate to elements
        self.outline_view.connect("row-activated", self.on_outline_item_activated)
        
        # Add the tree view to the scrolled window
        scrolled_window.add(self.outline_view)
        
        # Add the scrolled window to the outline box
        outline_box.pack_start(scrolled_window, True, True, 0)
        
        return outline_box
    
    def update_outline(self):
        """Update the code outline based on the current file"""
        self.outline_store.clear()
        
        if not self.current_file:
            return
        
        # Get extension
        ext = os.path.splitext(self.current_file)[1].lower()
        
        # Get code from editor
        buffer = self.source_view.get_buffer()
        start_iter = buffer.get_start_iter()
        end_iter = buffer.get_end_iter()
        code = buffer.get_text(start_iter, end_iter, True)
        
        # Process based on file type
        if ext in ['.py', '.pyw']:
            self.python_support.parse_outline(code, self.outline_store)
        elif ext in ['.c', '.cpp', '.cc', '.h', '.hpp']:
            self.c_cpp_support.parse_outline(code, self.outline_store)
        elif ext in ['.rs']:
            self.rust_support.parse_outline(code, self.outline_store)
    
    def create_search(self):
        """Create the search panel"""
        search_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        
        # Create search entry
        search_entry_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        search_entry_box.set_property("margin", 5)
        
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text("Search in files")
        self.search_entry.connect("activate", self.on_search_activated)
        
        search_button = Gtk.Button.new_from_icon_name("edit-find-symbolic", Gtk.IconSize.BUTTON)
        search_button.connect("clicked", self.on_search_activated)
        
        # Add to box
        search_entry_box.pack_start(self.search_entry, True, True, 0)
        search_entry_box.pack_start(search_button, False, False, 0)
        search_box.pack_start(search_entry_box, False, False, 0)
        
        # Create search options
        options_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        options_box.set_property("margin", 5)
        
        # Case sensitive option
        self.case_sensitive_check = Gtk.CheckButton.new_with_label("Case sensitive")
        self.regex_check = Gtk.CheckButton.new_with_label("Regular expression")
        
        options_box.pack_start(self.case_sensitive_check, False, False, 0)
        options_box.pack_start(self.regex_check, False, False, 0)
        search_box.pack_start(options_box, False, False, 0)
        
        # Create results area
        scrolled_window = Gtk.ScrolledWindow()
        scrolled_window.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        
        self.search_store = Gtk.ListStore(str, str, int, str)  # file, match, line, context
        self.search_view = Gtk.TreeView(model=self.search_store)
        
        # Add columns
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("File", renderer_text, text=0)
        self.search_view.append_column(column)
        
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("Line", renderer_text, text=2)
        column.set_min_width(50)
        column.set_max_width(50)
        self.search_view.append_column(column)
        
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("Match", renderer_text, text=3)
        self.search_view.append_column(column)
        
        # Connect double-click to navigate to result
        self.search_view.connect("row-activated", self.on_search_result_activated)
        
        scrolled_window.add(self.search_view)
        search_box.pack_start(scrolled_window, True, True, 0)
        
        return search_box
    
    def create_git(self):
        """Create the git integration panel"""
        git_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        
        # Create toolbar
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        toolbar.set_property("margin", 5)
        
        # Commit button
        commit_button = self.create_toolbar_button("document-save-symbolic", "Commit")
        commit_button.connect("clicked", self.on_git_commit_clicked)
        
        # Push button
        push_button = self.create_toolbar_button("go-up-symbolic", "Push")
        push_button.connect("clicked", self.on_git_push_clicked)
        
        # Pull button
        pull_button = self.create_toolbar_button("go-down-symbolic", "Pull")
        pull_button.connect("clicked", self.on_git_pull_clicked)
        
        # Add buttons to toolbar
        toolbar.pack_start(commit_button, False, False, 0)
        toolbar.pack_start(push_button, False, False, 0)
        toolbar.pack_start(pull_button, False, False, 0)
        
        # Add toolbar to git box
        git_box.pack_start(toolbar, False, False, 0)
        
        # Create changes list
        scrolled_window = Gtk.ScrolledWindow()
        scrolled_window.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        
        # Changes tree view
        self.git_store = Gtk.TreeStore(str, str, str)  # status, file, path
        self.git_view = Gtk.TreeView(model=self.git_store)
        
        # Add columns
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("Status", renderer_text, text=0)
        column.set_min_width(80)
        column.set_max_width(80)
        self.git_view.append_column(column)
        
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("File", renderer_text, text=1)
        self.git_view.append_column(column)
        
        # Add tree view to scrolled window
        scrolled_window.add(self.git_view)
        
        # Add scrolled window to git box
        git_box.pack_start(scrolled_window, True, True, 0)
        
        # Add commit message entry
        commit_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        commit_box.set_property("margin", 5)
        
        commit_label = Gtk.Label(label="Commit Message:")
        commit_label.set_halign(Gtk.Align.START)
        
        self.commit_entry = Gtk.Entry()
        self.commit_entry.set_placeholder_text("Enter commit message")
        
        commit_box.pack_start(commit_label, False, False, 0)
        commit_box.pack_start(self.commit_entry, False, False, 0)
        
        git_box.pack_start(commit_box, False, False, 0)
        
        # Update git status
        self.update_git_status()
        
        return git_box
    
    def update_git_status(self):
        """Update git status in the panel"""
        self.git_store.clear()
        
        # Check if current directory is a git repository
        if not os.path.exists(".git"):
            self.git_store.append(None, ["INFO", "Not a git repository", ""])
            return
        
        try:
            # Get git status
            status_output = subprocess.check_output(
                ["git", "status", "--porcelain"],
                universal_newlines=True
            )
            
            if not status_output:
                self.git_store.append(None, ["CLEAN", "No changes", ""])
                return
            
            # Parse status output
            for line in status_output.splitlines():
                status_code = line[:2]
                file_path = line[3:]
                
                status_text = "Unknown"
                if status_code == "A ":
                    status_text = "Added"
                elif status_code == "M ":
                    status_text = "Modified"
                elif status_code == " M":
                    status_text = "Modified"
                elif status_code == "D ":
                    status_text = "Deleted"
                elif status_code == " D":
                    status_text = "Deleted"
                elif status_code == "??":
                    status_text = "Untracked"
                elif status_code == "R ":
                    status_text = "Renamed"
                elif status_code == "C ":
                    status_text = "Copied"
                elif status_code == "UU":
                    status_text = "Conflict"
                
                self.git_store.append(None, [status_text, file_path, file_path])
                
        except Exception as e:
            print(f"Error getting git status: {e}")
            self.git_store.append(None, ["ERROR", str(e), ""])
    
    def create_debug(self):
        """Create the debugging panel"""
        debug_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        
        # Create toolbar
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        toolbar.set_property("margin", 5)
        
        # Debug buttons
        start_button = self.create_toolbar_button("media-playback-start-symbolic", "Start Debugging")
        start_button.connect("clicked", self.on_debug_start_clicked)
        
        pause_button = self.create_toolbar_button("media-playback-pause-symbolic", "Pause")
        pause_button.connect("clicked", self.on_debug_pause_clicked)
        
        stop_button = self.create_toolbar_button("media-playback-stop-symbolic", "Stop")
        stop_button.connect("clicked", self.on_debug_stop_clicked)
        
        step_button = self.create_toolbar_button("go-next-symbolic", "Step Over")
        step_button.connect("clicked", self.on_debug_step_clicked)
        
        # Add buttons to toolbar
        toolbar.pack_start(start_button, False, False, 0)
        toolbar.pack_start(pause_button, False, False, 0)
        toolbar.pack_start(stop_button, False, False, 0)
        toolbar.pack_start(step_button, False, False, 0)
        
        # Add toolbar to debug box
        debug_box.pack_start(toolbar, False, False, 0)
        
        # Create notebook for debug panels
        debug_notebook = Gtk.Notebook()
        
        # Variables panel
        variables_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        variables_scroll = Gtk.ScrolledWindow()
        variables_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        
        self.variables_store = Gtk.TreeStore(str, str, str)  # name, value, type
        self.variables_view = Gtk.TreeView(model=self.variables_store)
        
        # Add columns
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("Name", renderer_text, text=0)
        self.variables_view.append_column(column)
        
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("Value", renderer_text, text=1)
        self.variables_view.append_column(column)
        
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("Type", renderer_text, text=2)
        self.variables_view.append_column(column)
        
        variables_scroll.add(self.variables_view)
        variables_box.pack_start(variables_scroll, True, True, 0)
        
        # Breakpoints panel
        breakpoints_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        breakpoints_scroll = Gtk.ScrolledWindow()
        breakpoints_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        
        self.breakpoints_store = Gtk.ListStore(str, int, bool)  # file, line, enabled
        self.breakpoints_view = Gtk.TreeView(model=self.breakpoints_store)
        
        # Add columns
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("File", renderer_text, text=0)
        self.breakpoints_view.append_column(column)
        
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("Line", renderer_text, text=1)
        self.breakpoints_view.append_column(column)
        
        renderer_toggle = Gtk.CellRendererToggle()
        renderer_toggle.connect("toggled", self.on_breakpoint_toggled)
        column = Gtk.TreeViewColumn("Enabled", renderer_toggle, active=2)
        self.breakpoints_view.append_column(column)
        
        breakpoints_scroll.add(self.breakpoints_view)
        breakpoints_box.pack_start(breakpoints_scroll, True, True, 0)
        
        # Call stack panel
        callstack_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        callstack_scroll = Gtk.ScrolledWindow()
        callstack_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        
        self.callstack_store = Gtk.ListStore(str, str, int)  # function, file, line
        self.callstack_view = Gtk.TreeView(model=self.callstack_store)
        
        # Add columns
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("Function", renderer_text, text=0)
        self.callstack_view.append_column(column)
        
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("File", renderer_text, text=1)
        self.callstack_view.append_column(column)
        
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("Line", renderer_text, text=2)
        self.callstack_view.append_column(column)
        
        callstack_scroll.add(self.callstack_view)
        callstack_box.pack_start(callstack_scroll, True, True, 0)
        
        # Add panels to notebook
        debug_notebook.append_page(variables_box, Gtk.Label(label="Variables"))
        debug_notebook.append_page(breakpoints_box, Gtk.Label(label="Breakpoints"))
        debug_notebook.append_page(callstack_box, Gtk.Label(label="Call Stack"))
        
        # Add notebook to debug box
        debug_box.pack_start(debug_notebook, True, True, 0)
        
        return debug_box
    
    def create_content(self):
        """Create the main content area (editor and terminal)"""
        # Create vertical paned container for editor and terminal
        content_paned = Gtk.Paned(orientation=Gtk.Orientation.VERTICAL)
        
        # Create source editor
        editor_box = self.create_editor()
        content_paned.pack1(editor_box, True, False)
        
        # Create terminal
        terminal_box = self.create_terminal()
        content_paned.pack2(terminal_box, False, False)
        
        # Set initial pane position
        content_paned.set_position(550)
        
        return content_paned
    
    def create_editor(self):
        """Create the source code editor"""
        editor_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        editor_box.get_style_context().add_class("editor")
        
        # Create scrolled window for the editor
        scrolled_window = Gtk.ScrolledWindow()
        scrolled_window.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        
        # Initialize GtkSource components
        self.source_language_manager = GtkSource.LanguageManager()
        self.source_style_scheme_manager = GtkSource.StyleSchemeManager()
        
        # Create source buffer
        self.source_buffer = GtkSource.Buffer()
        self.source_buffer.set_style_scheme(
            self.source_style_scheme_manager.get_scheme("oblivion")
        )
        self.source_buffer.set_highlight_syntax(True)
        self.source_buffer.set_highlight_matching_brackets(True)
        self.source_buffer.connect("changed", self.on_buffer_changed)
        
        # Create source view (editor widget)
        self.source_view = GtkSource.View.new_with_buffer(self.source_buffer)
        self.source_view.set_show_line_numbers(True)
        self.source_view.set_auto_indent(True)
        self.source_view.set_tab_width(self.config.get("editor.tabSize", 4))
        self.source_view.set_insert_spaces_instead_of_tabs(self.config.get("editor.insertSpaces", True))
        self.source_view.set_smart_backspace(True)
        self.source_view.set_show_right_margin(True)
        
        # Set font
        font_desc = Pango.FontDescription(self.config.get("editor.fontFamily", "Source Code Pro"))
        font_desc.set_size(self.config.get("editor.fontSize", 14) * Pango.SCALE)
        self.source_view.override_font(font_desc)
        
        # Set right margin position(s)
        margin_positions = self.config.get("editor.rulers", [80])
        if isinstance(margin_positions, list):
            if len(margin_positions) > 0:
                self.source_view.set_right_margin_position(margin_positions[0])
        
        # Add source view to scrolled window
        scrolled_window.add(self.source_view)
        
        # Add scrolled window to editor box
        editor_box.pack_start(scrolled_window, True, True, 0)
        
        return editor_box
    
    def create_terminal(self):
        """Create the integrated terminal"""
        terminal_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        
        # Create header bar for the terminal
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        header_box.get_style_context().add_class("terminal-header")
        
        # Terminal label
        terminal_label = Gtk.Label(label="Terminal")
        terminal_label.set_property("margin", 5)
        
        # Clear button
        clear_button = self.create_toolbar_button("edit-clear-symbolic", "Clear Terminal")
        clear_button.connect("clicked", self.on_clear_terminal_clicked)
        
        # Add elements to header
        header_box.pack_start(terminal_label, False, False, 5)
        header_box.pack_end(clear_button, False, False, 5)
        
        # Add header to terminal box
        terminal_box.pack_start(header_box, False, False, 0)
        
        # Create VTE terminal
        self.terminal = Vte.Terminal()
        self.terminal.set_scrollback_lines(10000)
        
        # Configure terminal colors
        self.terminal.set_color_background(Gdk.RGBA(0, 0, 0, 1))  # Black background
        self.terminal.set_color_foreground(Gdk.RGBA(0.2, 1, 0.2, 1))  # Green text
        
        # Set font (match editor font)
        font_desc = Pango.FontDescription(self.config.get("editor.fontFamily", "Source Code Pro"))
        font_desc.set_size(self.config.get("editor.fontSize", 14) * Pango.SCALE)
        self.terminal.set_font(font_desc)
        
        # Start the shell
        shell = os.environ.get('SHELL', '/bin/bash')
        self.terminal.spawn_sync(
            Vte.PtyFlags.DEFAULT,
            os.getcwd(),  # Working directory
            [shell],      # Command
            [],           # Environment
            GLib.SpawnFlags.DO_NOT_REAP_CHILD,
            None, None
        )
        
        # Add terminal to box
        terminal_box.pack_start(self.terminal, True, True, 0)
        terminal_box.get_style_context().add_class("terminal")
        
        return terminal_box
    
    def create_statusbar(self):
        """Create the status bar at the bottom of the IDE"""
        statusbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        statusbar.set_property("margin", 5)
        
        # File info
        self.file_info_label = Gtk.Label(label="No file open")
        self.file_info_label.set_halign(Gtk.Align.START)
        
        # Cursor position
        self.cursor_pos_label = Gtk.Label(label="Ln 1, Col 1")
        
        # Encoding
        self.encoding_label = Gtk.Label(label="UTF-8")
        
        # Line ending
        self.line_ending_label = Gtk.Label(label="LF")
        
        # Language
        self.language_label = Gtk.Label(label="Plain Text")
        
        # Add all elements to status bar
        statusbar.pack_start(self.file_info_label, False, False, 0)
        statusbar.pack_end(self.language_label, False, False, 0)
        statusbar.pack_end(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL), False, False, 5)
        statusbar.pack_end(self.line_ending_label, False, False, 0)
        statusbar.pack_end(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL), False, False, 5)
        statusbar.pack_end(self.encoding_label, False, False, 0)
        statusbar.pack_end(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL), False, False, 5)
        statusbar.pack_end(self.cursor_pos_label, False, False, 0)
        
        return statusbar
    
    def setup_accelerators(self):
        """Set up keyboard shortcuts"""
        accel_group = Gtk.AccelGroup()
        self.add_accel_group(accel_group)
        
        # File operations
        # Ctrl+N: New File
        key, mod = Gtk.accelerator_parse("<Control>n")
        accel_group.connect(key, mod, Gtk.AccelFlags.VISIBLE, 
                           lambda *args: self.on_new_clicked(None))
        
        # Ctrl+O: Open File
        key, mod = Gtk.accelerator_parse("<Control>o")
        accel_group.connect(key, mod, Gtk.AccelFlags.VISIBLE, 
                           lambda *args: self.on_open_clicked(None))
        
        # Ctrl+S: Save File
        key, mod = Gtk.accelerator_parse("<Control>s")
        accel_group.connect(key, mod, Gtk.AccelFlags.VISIBLE, 
                           lambda *args: self.on_save_clicked(None))
        
        # Ctrl+Shift+S: Save As
        key, mod = Gtk.accelerator_parse("<Control><Shift>s")
        accel_group.connect(key, mod, Gtk.AccelFlags.VISIBLE, 
                           lambda *args: self.on_save_as_clicked(None))
        
        # Edit operations
        # Ctrl+Z: Undo
        key, mod = Gtk.accelerator_parse("<Control>z")
        accel_group.connect(key, mod, Gtk.AccelFlags.VISIBLE, 
                           lambda *args: self.on_undo_clicked(None))
        
        # Ctrl+Shift+Z: Redo
        key, mod = Gtk.accelerator_parse("<Control><Shift>z")
        accel_group.connect(key, mod, Gtk.AccelFlags.VISIBLE, 
                           lambda *args: self.on_redo_clicked(None))
        
        # Run operations
        # F5: Run
        key, mod = Gtk.accelerator_parse("F5")
        accel_group.connect(key, mod, Gtk.AccelFlags.VISIBLE, 
                           lambda *args: self.on_run_clicked(None))
        
        # F6: Build
        key, mod = Gtk.accelerator_parse("F6")
        accel_group.connect(key, mod, Gtk.AccelFlags.VISIBLE, 
                           lambda *args: self.on_build_clicked(None))
        
        # F9: Debug
        key, mod = Gtk.accelerator_parse("F9")
        accel_group.connect(key, mod, Gtk.AccelFlags.VISIBLE, 
                           lambda *args: self.on_debug_clicked(None))
    
    def on_buffer_changed(self, buffer):
        """Handle when the text buffer is changed"""
        if not self.modified and self.current_file:
            self.modified = True
            self.update_title()
        
        # Update cursor position
        mark = buffer.get_insert()
        iter = buffer.get_iter_at_mark(mark)
        line = iter.get_line() + 1
        col = iter.get_line_offset() + 1
        self.cursor_pos_label.set_text(f"Ln {line}, Col {col}")
    
    def update_title(self):
        """Update the window title with current file name and modification status"""
        if self.current_file:
            basename = os.path.basename(self.current_file)
            title = f"{basename}{'*' if self.modified else ''} - CyberDev IDE"
            self.set_title(title)
        else:
            self.set_title("CyberDev IDE")
    
    def on_new_clicked(self, button):
        """Handle new file button click"""
        # Check if current file is modified
        if self.current_file is not None and self.modified:
            dialog = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.QUESTION,
                buttons=Gtk.ButtonsType.YES_NO,
                text="Save changes to current file?"
            )
            response = dialog.run()
            dialog.destroy()
            
            if response == Gtk.ResponseType.YES:
                self.on_save_clicked(None)
        
        # Clear the buffer
        self.source_buffer.set_text("")
        
        # Reset file tracking
        self.current_file = None
        self.modified = False
        
        # Update language to plain text
        self.source_buffer.set_language(None)
        self.language_label.set_text("Plain Text")
        
        # Update file info
        self.file_info_label.set_text("No file open")
        
        # Update window title
        self.update_title()
    
    def on_open_clicked(self, button):
        """Handle open file button click"""
        dialog = Gtk.FileChooserDialog(
            title="Open File",
            parent=self,
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN, Gtk.ResponseType.OK
        )
        
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            self.open_file(dialog.get_filename())
            
        dialog.destroy()
    
    def open_file(self, filename):
        """Open a file in the editor"""
        try:
            with open(filename, 'r') as f:
                content = f.read()
            
            # Set buffer text
            self.source_buffer.set_text(content)
            
            # Set current file and modified status
            self.current_file = filename
            self.modified = False
            
            # Update language based on file extension
            self.detect_and_set_language(filename)
            
            # Update file info
            basename = os.path.basename(filename)
            self.file_info_label.set_text(basename)
            
            # Update window title
            self.update_title()
            
            # Update outline
            self.update_outline()
            
            print(f"Opened file: {filename}")
            
        except Exception as e:
            dialog = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.ERROR,
                buttons=Gtk.ButtonsType.OK,
                text="Error opening file"
            )
            dialog.format_secondary_text(str(e))
            dialog.run()
            dialog.destroy()
            print(f"Error opening file: {e}")
    
    def detect_and_set_language(self, filename):
        """Detect and set the appropriate language for syntax highlighting"""
        ext = os.path.splitext(filename)[1].lower()
        
        language = None
        language_name = "Plain Text"
        
        if ext in ['.py', '.pyw']:
            language = self.source_language_manager.get_language('python')
            language_name = "Python"
        elif ext in ['.c']:
            language = self.source_language_manager.get_language('c')
            language_name = "C"
        elif ext in ['.cpp', '.cc', '.h', '.hpp']:
            language = self.source_language_manager.get_language('cpp')
            language_name = "C++"
        elif ext in ['.rs']:
            language = self.source_language_manager.get_language('rust')
            language_name = "Rust"
        elif ext in ['.js']:
            language = self.source_language_manager.get_language('js')
            language_name = "JavaScript"
        elif ext in ['.html', '.htm']:
            language = self.source_language_manager.get_language('html')
            language_name = "HTML"
        elif ext in ['.css']:
            language = self.source_language_manager.get_language('css')
            language_name = "CSS"
        elif ext in ['.xml', '.svg']:
            language = self.source_language_manager.get_language('xml')
            language_name = "XML"
        elif ext in ['.json']:
            language = self.source_language_manager.get_language('json')
            language_name = "JSON"
        elif ext in ['.sh', '.bash']:
            language = self.source_language_manager.get_language('sh')
            language_name = "Shell"
        elif ext in ['.md']:
            language = self.source_language_manager.get_language('markdown')
            language_name = "Markdown"
        
        # Set language for syntax highlighting
        self.source_buffer.set_language(language)
        
        # Update language label
        self.language_label.set_text(language_name)
    
    def on_save_clicked(self, button):
        """Handle save file button click"""
        if self.current_file is None:
            self.on_save_as_clicked(button)
        else:
            self.save_file(self.current_file)
    
    def on_save_as_clicked(self, button):
        """Handle save as button click"""
        dialog = Gtk.FileChooserDialog(
            title="Save As",
            parent=self,
            action=Gtk.FileChooserAction.SAVE
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_SAVE, Gtk.ResponseType.OK
        )
        dialog.set_do_overwrite_confirmation(True)
        
        # Set current file as default if exists
        if self.current_file is not None:
            dialog.set_filename(self.current_file)
        
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            self.save_file(dialog.get_filename())
            
        dialog.destroy()
    
    def save_file(self, filename):
        """Save current buffer to file"""
        try:
            # Get buffer content
            buffer = self.source_view.get_buffer()
            start_iter = buffer.get_start_iter()
            end_iter = buffer.get_end_iter()
            text = buffer.get_text(start_iter, end_iter, True)
            
            # Write to file
            with open(filename, 'w') as f:
                f.write(text)
            
            # Update current file and modified status
            self.current_file = filename
            self.modified = False
            
            # Update language if needed
            self.detect_and_set_language(filename)
            
            # Update file info
            basename = os.path.basename(filename)
            self.file_info_label.set_text(basename)
            
            # Update window title
            self.update_title()
            
            # Update git status
            self.update_git_status()
            
            print(f"Saved file: {filename}")
            
        except Exception as e:
            dialog = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.ERROR,
                buttons=Gtk.ButtonsType.OK,
                text="Error saving file"
            )
            dialog.format_secondary_text(str(e))
            dialog.run()
            dialog.destroy()
            print(f"Error saving file: {e}")
    
    def on_undo_clicked(self, button):
        """Handle undo button click"""
        if self.source_buffer.can_undo():
            self.source_buffer.undo()
    
    def on_redo_clicked(self, button):
        """Handle redo button click"""
        if self.source_buffer.can_redo():
            self.source_buffer.redo()
    
    def on_cut_clicked(self, button):
        """Handle cut button click"""
        clipboard = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
        self.source_buffer.cut_clipboard(clipboard, True)
    
    def on_copy_clicked(self, button):
        """Handle copy button click"""
        clipboard = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
        self.source_buffer.copy_clipboard(clipboard)
    
    def on_paste_clicked(self, button):
        """Handle paste button click"""
        clipboard = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
        self.source_buffer.paste_clipboard(clipboard, None, True)
    
    def on_find_clicked(self, button):
        """Handle find button click"""
        # Switch to search tab
        self.sidebar_notebook.set_current_page(2)
        
        # Focus search entry
        self.search_entry.grab_focus()
    
    def on_replace_clicked(self, button):
        """Handle replace button click"""
        # Not implemented in this version
        pass
    
    def on_run_clicked(self, button):
        """Handle run button click"""
        if self.current_file is None:
            dialog = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text="No file to run"
            )
            dialog.format_secondary_text("Please save your file first.")
            dialog.run()
            dialog.destroy()
            return
        
        # Save current file if modified
        if self.modified:
            self.save_file(self.current_file)
        
        # Determine how to run the file based on extension
        ext = os.path.splitext(self.current_file)[1].lower()
        
        # Build the command
        cmd = []
        
        if ext in ['.py', '.pyw']:
            cmd = ["python3", self.current_file]
        elif ext in ['.js']:
            cmd = ["node", self.current_file]
        elif ext in ['.html', '.htm']:
            cmd = ["xdg-open", self.current_file]
        elif ext in ['.sh', '.bash']:
            cmd = ["bash", self.current_file]
        elif ext in ['.rs']:
            # For Rust, we need to handle cargo projects differently
            if os.path.exists("Cargo.toml"):
                cmd = ["cargo", "run"]
            else:
                dialog = Gtk.MessageDialog(
                    transient_for=self,
                    flags=0,
                    message_type=Gtk.MessageType.INFO,
                    buttons=Gtk.ButtonsType.OK,
                    text="Cannot run Rust file directly"
                )
                dialog.format_secondary_text("Please use 'cargo run' for Rust projects.")
                dialog.run()
                dialog.destroy()
                return
        else:
            # For other files (C/C++), need to build first
            dialog = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text="File type requires building first"
            )
            dialog.format_secondary_text("Please build the project before running.")
            dialog.run()
            dialog.destroy()
            return
        
        # Execute the command in the terminal
        self.terminal.reset(True, True)
        
        # For commands that should run in the terminal
        working_dir = os.path.dirname(self.current_file) or os.getcwd()
        
        # Change to the working directory in the terminal
        cd_cmd = f"cd {working_dir}\n"
        self.terminal.feed_child(cd_cmd.encode())
        
        # Run the command
        run_cmd = " ".join(cmd) + "\n"
        self.terminal.feed_child(run_cmd.encode())
    
    def on_build_clicked(self, button):
        """Handle build button click"""
        if self.current_file is None:
            dialog = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text="No file to build"
            )
            dialog.format_secondary_text("Please save your file first.")
            dialog.run()
            dialog.destroy()
            return
        
        # Save current file if modified
        if self.modified:
            self.save_file(self.current_file)
        
        # Determine how to build the file based on extension
        ext = os.path.splitext(self.current_file)[1].lower()
        
        # Build the command
        cmd = []
        
        if ext in ['.c']:
            base_name = os.path.splitext(os.path.basename(self.current_file))[0]
            output_name = os.path.join(os.path.dirname(self.current_file), base_name)
            cmd = ["gcc", "-o", output_name, self.current_file]
        elif ext in ['.cpp', '.cc']:
            base_name = os.path.splitext(os.path.basename(self.current_file))[0]
            output_name = os.path.join(os.path.dirname(self.current_file), base_name)
            cmd = ["g++", "-o", output_name, self.current_file]
        elif ext in ['.rs']:
            # For Rust, use cargo
            if os.path.exists("Cargo.toml"):
                cmd = ["cargo", "build"]
            else:
                cmd = ["rustc", self.current_file]
        elif ext in ['.py', '.js', '.html', '.sh']:
            dialog = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text="No build required"
            )
            dialog.format_secondary_text("This file type doesn't require building.")
            dialog.run()
            dialog.destroy()
            return
        else:
            dialog = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text="Unsupported file type for building"
            )
            dialog.run()
            dialog.destroy()
            return
        
        # Execute the command in the terminal
        self.terminal.reset(True, True)
        
        # Get working directory
        working_dir = os.path.dirname(self.current_file) or os.getcwd()
        
        # Change to the working directory in the terminal
        cd_cmd = f"cd {working_dir}\n"
        self.terminal.feed_child(cd_cmd.encode())
        
        # Run the build command
        build_cmd = " ".join(cmd) + "\n"
        self.terminal.feed_child(build_cmd.encode())
    
    def on_debug_clicked(self, button):
        """Handle debug button click"""
        # Open the debug panel
        self.sidebar_notebook.set_current_page(4)
        
        # Not fully implemented in this version
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text="Debug functionality"
        )
        dialog.format_secondary_text("Debugging is not fully implemented in this version.")
        dialog.run()
        dialog.destroy()
    
    def on_settings_clicked(self, button):
        """Handle settings button click"""
        # Create settings dialog
        dialog = Gtk.Dialog(
            title="IDE Settings",
            parent=self,
            flags=0,
            buttons=(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
                     Gtk.STOCK_OK, Gtk.ResponseType.OK)
        )
        dialog.set_default_size(400, 300)
        
        # Create settings notebook
        notebook = Gtk.Notebook()
        dialog.get_content_area().pack_start(notebook, True, True, 0)
        
        # Editor settings page
        editor_grid = Gtk.Grid()
        editor_grid.set_row_spacing(10)
        editor_grid.set_column_spacing(10)
        editor_grid.set_property("margin", 10)
        
        # Font settings
        font_label = Gtk.Label(label="Font:")
        font_label.set_halign(Gtk.Align.START)
        
        font_button = Gtk.FontButton()
        font_desc = Pango.FontDescription(self.config.get("editor.fontFamily", "Source Code Pro"))
        font_desc.set_size(self.config.get("editor.fontSize", 14) * Pango.SCALE)
        font_button.set_font_desc(font_desc)
        
        editor_grid.attach(font_label, 0, 0, 1, 1)
        editor_grid.attach(font_button, 1, 0, 1, 1)
        
        # Tab size
        tab_size_label = Gtk.Label(label="Tab size:")
        tab_size_label.set_halign(Gtk.Align.START)
        
        tab_size_spin = Gtk.SpinButton.new_with_range(1, 8, 1)
        tab_size_spin.set_value(self.config.get("editor.tabSize", 4))
        
        editor_grid.attach(tab_size_label, 0, 1, 1, 1)
        editor_grid.attach(tab_size_spin, 1, 1, 1, 1)
        
        # Insert spaces
        insert_spaces_label = Gtk.Label(label="Insert spaces:")
        insert_spaces_label.set_halign(Gtk.Align.START)
        
        insert_spaces_switch = Gtk.Switch()
        insert_spaces_switch.set_active(self.config.get("editor.insertSpaces", True))
        
        editor_grid.attach(insert_spaces_label, 0, 2, 1, 1)
        editor_grid.attach(insert_spaces_switch, 1, 2, 1, 1)
        
        # Word wrap
        word_wrap_label = Gtk.Label(label="Word wrap:")
        word_wrap_label.set_halign(Gtk.Align.START)
        
        word_wrap_switch = Gtk.Switch()
        word_wrap_switch.set_active(self.config.get("editor.wordWrap", "off") != "off")
        
        editor_grid.attach(word_wrap_label, 0, 3, 1, 1)
        editor_grid.attach(word_wrap_switch, 1, 3, 1, 1)
        
        # Add editor settings page
        notebook.append_page(editor_grid, Gtk.Label(label="Editor"))
        
        # Theme settings page
        theme_grid = Gtk.Grid()
        theme_grid.set_row_spacing(10)
        theme_grid.set_column_spacing(10)
        theme_grid.set_property("margin", 10)
        
        # Theme selection
        theme_label = Gtk.Label(label="Color theme:")
        theme_label.set_halign(Gtk.Align.START)
        
        theme_combo = Gtk.ComboBoxText()
        for theme in ["Dark", "Light", "High Contrast"]:
            theme_combo.append_text(theme)
        theme_combo.set_active(0)  # Set default to Dark
        
        theme_grid.attach(theme_label, 0, 0, 1, 1)
        theme_grid.attach(theme_combo, 1, 0, 1, 1)
        
        # Icon theme
        icon_label = Gtk.Label(label="Icon theme:")
        icon_label.set_halign(Gtk.Align.START)
        
        icon_combo = Gtk.ComboBoxText()
        for icon_theme in ["Default", "Minimal", "Classic"]:
            icon_combo.append_text(icon_theme)
        icon_combo.set_active(0)  # Set default
        
        theme_grid.attach(icon_label, 0, 1, 1, 1)
        theme_grid.attach(icon_combo, 1, 1, 1, 1)
        
        # Add theme settings page
        notebook.append_page(theme_grid, Gtk.Label(label="Theme"))
        
        # Show dialog
        dialog.show_all()
        response = dialog.run()
        
        if response == Gtk.ResponseType.OK:
            # Apply settings
            # Font
            font_desc = font_button.get_font_desc()
            self.source_view.override_font(font_desc)
            
            # Tab size
            tab_size = tab_size_spin.get_value_as_int()
            self.source_view.set_tab_width(tab_size)
            
            # Insert spaces
            insert_spaces = insert_spaces_switch.get_active()
            self.source_view.set_insert_spaces_instead_of_tabs(insert_spaces)
            
            # Word wrap
            word_wrap = word_wrap_switch.get_active()
            if word_wrap:
                self.source_view.set_wrap_mode(Gtk.WrapMode.WORD)
            else:
                self.source_view.set_wrap_mode(Gtk.WrapMode.NONE)
            
            # Save settings (in a real implementation, we would save to config file)
            print("Settings updated")
        
        dialog.destroy()
    
    def on_help_clicked(self, button):
        """Handle help button click"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text="CyberDev IDE Help"
        )
        help_text = """
CyberDev IDE is a lightweight, security-focused integrated development environment.

Key Shortcuts:
Ctrl+N: New File
Ctrl+O: Open File
Ctrl+S: Save File
Ctrl+Shift+S: Save As
Ctrl+Z: Undo
Ctrl+Shift+Z: Redo
F5: Run
F6: Build
F9: Debug

For more information, see the CyberOS documentation.
"""
        dialog.format_secondary_text(help_text)
        dialog.run()
        dialog.destroy()
    
    def on_new_folder_clicked(self, button):
        """Handle new folder button click in file explorer"""
        dialog = Gtk.Dialog(
            title="Create New Folder",
            parent=self,
            flags=0,
            buttons=(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
                     Gtk.STOCK_OK, Gtk.ResponseType.OK)
        )
        
        box = dialog.get_content_area()
        box.set_property("margin", 10)
        
        label = Gtk.Label(label="Folder name:")
        box.pack_start(label, False, False, 5)
        
        entry = Gtk.Entry()
        entry.set_text("New Folder")
        box.pack_start(entry, False, False, 5)
        
        dialog.show_all()
        response = dialog.run()
        
        if response == Gtk.ResponseType.OK:
            folder_name = entry.get_text()
            try:
                os.makedirs(os.path.join(os.getcwd(), folder_name), exist_ok=True)
                self.refresh_file_explorer()
            except Exception as e:
                error_dialog = Gtk.MessageDialog(
                    transient_for=self,
                    flags=0,
                    message_type=Gtk.MessageType.ERROR,
                    buttons=Gtk.ButtonsType.OK,
                    text="Error creating folder"
                )
                error_dialog.format_secondary_text(str(e))
                error_dialog.run()
                error_dialog.destroy()
        
        dialog.destroy()
    
    def on_new_file_clicked(self, button):
        """Handle new file button click in file explorer"""
        dialog = Gtk.Dialog(
            title="Create New File",
            parent=self,
            flags=0,
            buttons=(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
                     Gtk.STOCK_OK, Gtk.ResponseType.OK)
        )
        
        box = dialog.get_content_area()
        box.set_property("margin", 10)
        
        label = Gtk.Label(label="File name:")
        box.pack_start(label, False, False, 5)
        
        entry = Gtk.Entry()
        entry.set_text("new_file.py")
        box.pack_start(entry, False, False, 5)
        
        dialog.show_all()
        response = dialog.run()
        
        if response == Gtk.ResponseType.OK:
            file_name = entry.get_text()
            try:
                file_path = os.path.join(os.getcwd(), file_name)
                with open(file_path, 'w') as f:
                    f.write("")
                self.refresh_file_explorer()
                self.open_file(file_path)
            except Exception as e:
                error_dialog = Gtk.MessageDialog(
                    transient_for=self,
                    flags=0,
                    message_type=Gtk.MessageType.ERROR,
                    buttons=Gtk.ButtonsType.OK,
                    text="Error creating file"
                )
                error_dialog.format_secondary_text(str(e))
                error_dialog.run()
                error_dialog.destroy()
        
        dialog.destroy()
    
    def on_refresh_clicked(self, button):
        """Handle refresh button click in file explorer"""
        self.refresh_file_explorer()
    
    def on_file_activated(self, view, path, column):
        """Handle double-click on a file in the file explorer"""
        model = view.get_model()
        iter = model.get_iter(path)
        item_path = model.get_value(iter, 1)
        
        if os.path.isfile(item_path):
            # Open the file
            self.open_file(item_path)
        elif os.path.isdir(item_path):
            # Navigate to the directory
            self.refresh_file_explorer(item_path)
    
    def on_file_right_click(self, view, event):
        """Handle right-click on a file in the file explorer"""
        if event.button == 3:  # Right mouse button
            # Get the path at the position
            path_info = view.get_path_at_pos(int(event.x), int(event.y))
            if path_info is not None:
                path, column, cell_x, cell_y = path_info
                view.set_cursor(path, column, 0)
                
                # Get the item
                model = view.get_model()
                iter = model.get_iter(path)
                item_name = model.get_value(iter, 0)
                item_path = model.get_value(iter, 1)
                
                # Create popup menu
                menu = Gtk.Menu()
                
                # Open item
                open_item = Gtk.MenuItem(label="Open")
                open_item.connect("activate", lambda w: self.open_file(item_path) if os.path.isfile(item_path) else self.refresh_file_explorer(item_path))
                menu.append(open_item)
                
                # Add separator
                menu.append(Gtk.SeparatorMenuItem())
                
                # Delete item
                delete_item = Gtk.MenuItem(label="Delete")
                delete_item.connect("activate", lambda w: self.delete_file_or_folder(item_path))
                menu.append(delete_item)
                
                # Rename item
                rename_item = Gtk.MenuItem(label="Rename")
                rename_item.connect("activate", lambda w: self.rename_file_or_folder(item_path))
                menu.append(rename_item)
                
                menu.show_all()
                menu.popup_at_pointer(event)
                return True
        return False
    
    def delete_file_or_folder(self, path):
        """Delete a file or folder"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=f"Delete {os.path.basename(path)}?"
        )
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            try:
                if os.path.isfile(path):
                    os.remove(path)
                elif os.path.isdir(path):
                    import shutil
                    shutil.rmtree(path)
                self.refresh_file_explorer()
            except Exception as e:
                error_dialog = Gtk.MessageDialog(
                    transient_for=self,
                    flags=0,
                    message_type=Gtk.MessageType.ERROR,
                    buttons=Gtk.ButtonsType.OK,
                    text="Error deleting item"
                )
                error_dialog.format_secondary_text(str(e))
                error_dialog.run()
                error_dialog.destroy()
    
    def rename_file_or_folder(self, path):
        """Rename a file or folder"""
        dialog = Gtk.Dialog(
            title="Rename",
            parent=self,
            flags=0,
            buttons=(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
                     Gtk.STOCK_OK, Gtk.ResponseType.OK)
        )
        
        box = dialog.get_content_area()
        box.set_property("margin", 10)
        
        label = Gtk.Label(label="New name:")
        box.pack_start(label, False, False, 5)
        
        entry = Gtk.Entry()
        entry.set_text(os.path.basename(path))
        box.pack_start(entry, False, False, 5)
        
        dialog.show_all()
        response = dialog.run()
        
        if response == Gtk.ResponseType.OK:
            new_name = entry.get_text()
            try:
                new_path = os.path.join(os.path.dirname(path), new_name)
                os.rename(path, new_path)
                self.refresh_file_explorer()
            except Exception as e:
                error_dialog = Gtk.MessageDialog(
                    transient_for=self,
                    flags=0,
                    message_type=Gtk.MessageType.ERROR,
                    buttons=Gtk.ButtonsType.OK,
                    text="Error renaming item"
                )
                error_dialog.format_secondary_text(str(e))
                error_dialog.run()
                error_dialog.destroy()
        
        dialog.destroy()
    
    def on_search_activated(self, widget):
        """Handle search activation"""
        search_text = self.search_entry.get_text()
        if not search_text:
            return
        
        # Clear previous results
        self.search_store.clear()
        
        case_sensitive = self.case_sensitive_check.get_active()
        use_regex = self.regex_check.get_active()
        
        # Search in the current open file first
        if self.current_file:
            self.search_in_file(self.current_file, search_text, case_sensitive, use_regex)
        
        # Then search in other files in the current directory
        for root, dirs, files in os.walk(os.getcwd()):
            for file in files:
                # Skip binary files and large files
                if self.is_text_file(file):
                    file_path = os.path.join(root, file)
                    if file_path != self.current_file:  # Skip if it's the current file (already searched)
                        self.search_in_file(file_path, search_text, case_sensitive, use_regex)
    
    def is_text_file(self, filename):
        """Check if a file is likely a text file based on extension"""
        text_extensions = ['.py', '.c', '.cpp', '.h', '.hpp', '.rs', '.js', '.html', 
                         '.css', '.xml', '.json', '.md', '.txt', '.sh', '.bash']
        ext = os.path.splitext(filename)[1].lower()
        return ext in text_extensions
    
    def search_in_file(self, file_path, search_text, case_sensitive, use_regex):
        """Search for text in a file"""
        try:
            with open(file_path, 'r') as f:
                lines = f.readlines()
            
            import re
            file_display = os.path.basename(file_path)
            
            for i, line in enumerate(lines):
                if use_regex:
                    flags = 0 if case_sensitive else re.IGNORECASE
                    matches = list(re.finditer(search_text, line, flags))
                    for match in matches:
                        self.search_store.append([file_display, file_path, i + 1, line.strip()])
                else:
                    if case_sensitive:
                        if search_text in line:
                            self.search_store.append([file_display, file_path, i + 1, line.strip()])
                    else:
                        if search_text.lower() in line.lower():
                            self.search_store.append([file_display, file_path, i + 1, line.strip()])
        except Exception as e:
            print(f"Error searching in {file_path}: {e}")
    
    def on_search_result_activated(self, view, path, column):
        """Handle double-click on a search result"""
        model = view.get_model()
        iter = model.get_iter(path)
        file_path = model.get_value(iter, 1)
        line_num = model.get_value(iter, 2)
        
        # Open the file
        self.open_file(file_path)
        
        # Scroll to the line
        buffer = self.source_view.get_buffer()
        iter = buffer.get_iter_at_line(line_num - 1)
        buffer.place_cursor(iter)
        self.source_view.scroll_to_iter(iter, 0.0, True, 0.0, 0.5)
    
    def on_outline_item_activated(self, view, path, column):
        """Handle click on an outline item"""
        model = view.get_model()
        iter = model.get_iter(path)
        name = model.get_value(iter, 0)
        type_name = model.get_value(iter, 1)
        
        # Determine line number based on item type and name
        # This is a simplified approach; real parsing would be more complex
        buffer = self.source_view.get_buffer()
        start_iter = buffer.get_start_iter()
        end_iter = buffer.get_end_iter()
        code = buffer.get_text(start_iter, end_iter, True)
        
        lines = code.split('\n')
        line_num = 0
        
        if type_name == "class":
            pattern = f"class {name}"
        elif type_name == "function":
            pattern = f"def {name}"
        elif type_name == "method":
            pattern = f"def {name}"
        elif type_name == "struct":
            pattern = f"struct {name}"
        elif type_name == "enum":
            pattern = f"enum {name}"
        else:
            pattern = name
        
        for i, line in enumerate(lines):
            if pattern in line:
                line_num = i
                break
        
        # Scroll to the line
        iter = buffer.get_iter_at_line(line_num)
        buffer.place_cursor(iter)
        self.source_view.scroll_to_iter(iter, 0.0, True, 0.0, 0.5)
    
    def on_git_commit_clicked(self, button):
        """Handle git commit button click"""
        if not os.path.exists(".git"):
            dialog = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text="Not a git repository"
            )
            dialog.format_secondary_text("Initialize a git repository first.")
            dialog.run()
            dialog.destroy()
            return
        
        # Get commit message
        commit_message = self.commit_entry.get_text()
        if not commit_message:
            dialog = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text="No commit message"
            )
            dialog.format_secondary_text("Please enter a commit message.")
            dialog.run()
            dialog.destroy()
            return
        
        try:
            # Add all changes
            subprocess.run(["git", "add", "."], check=True)
            
            # Commit
            subprocess.run(["git", "commit", "-m", commit_message], check=True)
            
            # Update git status
            self.update_git_status()
            
            # Clear commit message
            self.commit_entry.set_text("")
            
            # Show success message
            dialog = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text="Commit successful"
            )
            dialog.run()
            dialog.destroy()
            
        except Exception as e:
            dialog = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.ERROR,
                buttons=Gtk.ButtonsType.OK,
                text="Error committing changes"
            )
            dialog.format_secondary_text(str(e))
            dialog.run()
            dialog.destroy()
    
    def on_git_push_clicked(self, button):
        """Handle git push button click"""
        if not os.path.exists(".git"):
            dialog = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text="Not a git repository"
            )
            dialog.run()
            dialog.destroy()
            return
        
        # Execute git push in the terminal
        self.terminal.reset(True, True)
        self.terminal.feed_child("git push\n".encode())
    
    def on_git_pull_clicked(self, button):
        """Handle git pull button click"""
        if not os.path.exists(".git"):
            dialog = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text="Not a git repository"
            )
            dialog.run()
            dialog.destroy()
            return
        
        # Execute git pull in the terminal
        self.terminal.reset(True, True)
        self.terminal.feed_child("git pull\n".encode())
    
    def on_clear_terminal_clicked(self, button):
        """Handle clear terminal button click"""
        self.terminal.reset(True, True)
    
    def on_debug_start_clicked(self, button):
        """Handle debug start button click"""
        # Not fully implemented
        # Would initialize debugger for current file
        pass
    
    def on_debug_pause_clicked(self, button):
        """Handle debug pause button click"""
        # Not fully implemented
        pass
    
    def on_debug_stop_clicked(self, button):
        """Handle debug stop button click"""
        # Not fully implemented
        pass
    
    def on_debug_step_clicked(self, button):
        """Handle debug step button click"""
        # Not fully implemented
        pass
    
    def on_breakpoint_toggled(self, renderer, path):
        """Handle breakpoint toggle"""
        iter = self.breakpoints_store.get_iter(path)
        current_value = self.breakpoints_store.get_value(iter, 2)
        self.breakpoints_store.set_value(iter, 2, not current_value)

def main():
    """Main entry point for the IDE"""
    ide = CyberDevIDE()
    ide.show_all()
    Gtk.main()

if __name__ == "__main__":
    main()
