#!/usr/bin/env python3

"""
Python Language Support
Provides code intelligence, linting, and other Python-specific tools
"""

import os
import re
import ast
import threading
import subprocess
from gi.repository import Gtk

class PythonSupport:
    """Python language support for the CyberDev IDE"""
    
    def __init__(self):
        """Initialize Python language support"""
        # Icons for different Python constructs
        self.icons = {
            "class": "text-x-script",
            "function": "system-run-symbolic",
            "method": "system-run-symbolic",
            "variable": "text-x-generic",
            "import": "emblem-downloads",
            "decorator": "emblem-symbolic-link",
            "constant": "emblem-important-symbolic",
            "module": "package-x-generic",
            "error": "dialog-error-symbolic"
        }
    
    def parse_outline(self, code, store):
        """Parse Python code and populate the outline view"""
        try:
            # Clear existing store first
            store.clear()
            
            # Parse code into AST
            tree = ast.parse(code)
            
            # Add imports
            imports_parent = store.append(None, ["Imports", "section", "package-x-generic"])
            for node in ast.iter_child_nodes(tree):
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    if isinstance(node, ast.Import):
                        for name in node.names:
                            store.append(imports_parent, [name.name, "import", self.icons["import"]])
                    else:  # ImportFrom
                        module = node.module or ""
                        for name in node.names:
                            import_name = f"{module}.{name.name}" if module else name.name
                            store.append(imports_parent, [import_name, "import", self.icons["import"]])
            
            # Add classes, functions, and global variables
            for node in ast.iter_child_nodes(tree):
                if isinstance(node, ast.ClassDef):
                    # Add class
                    class_item = store.append(None, [node.name, "class", self.icons["class"]])
                    
                    # Add class methods
                    for class_node in ast.iter_child_nodes(node):
                        if isinstance(class_node, ast.FunctionDef):
                            method_name = class_node.name
                            if method_name.startswith("__") and method_name.endswith("__"):
                                method_icon = "emblem-important-symbolic"
                            else:
                                method_icon = self.icons["method"]
                            store.append(class_item, [method_name, "method", method_icon])
                        elif isinstance(class_node, ast.Assign):
                            # Add class variables
                            for target in class_node.targets:
                                if isinstance(target, ast.Name):
                                    var_name = target.id
                                    var_type = "constant" if var_name.isupper() else "variable"
                                    var_icon = self.icons["constant"] if var_name.isupper() else self.icons["variable"]
                                    store.append(class_item, [var_name, var_type, var_icon])
                
                elif isinstance(node, ast.FunctionDef):
                    # Add function
                    if node.decorator_list:
                        # If it has decorators, mark it differently
                        store.append(None, [node.name, "function", self.icons["decorator"]])
                    else:
                        store.append(None, [node.name, "function", self.icons["function"]])
                
                elif isinstance(node, ast.Assign):
                    # Add global variables
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            var_name = target.id
                            var_type = "constant" if var_name.isupper() else "variable"
                            var_icon = self.icons["constant"] if var_name.isupper() else self.icons["variable"]
                            store.append(None, [var_name, var_type, var_icon])
            
        except SyntaxError as e:
            store.append(None, [f"Syntax error: {e}", "error", self.icons["error"]])
        except Exception as e:
            store.append(None, [f"Error parsing: {e}", "error", self.icons["error"]])
    
    def get_autocomplete_suggestions(self, code, line, column):
        """Get code completion suggestions at a given position"""
        try:
            # This is a simplified implementation
            # A real implementation would use jedi or another Python
            # language server to provide intelligent completions
            
            # For this demo, we'll do a simple parsing for context-based suggestions
            suggestions = []
            
            # Split the code into lines and get the current line
            lines = code.split('\n')
            if line < len(lines):
                current_line = lines[line][:column]
                
                # Check for import completion
                import_match = re.search(r'import\s+(\w*)$', current_line)
                if import_match:
                    prefix = import_match.group(1)
                    suggestions = self.get_module_suggestions(prefix)
                
                # Check for from ... import completion
                from_import_match = re.search(r'from\s+(\w+)\s+import\s+(\w*)$', current_line)
                if from_import_match:
                    module = from_import_match.group(1)
                    prefix = from_import_match.group(2)
                    suggestions = self.get_module_members(module, prefix)
                
                # Check for method/attribute completion
                obj_match = re.search(r'(\w+)\.(\w*)$', current_line)
                if obj_match:
                    obj = obj_match.group(1)
                    prefix = obj_match.group(2)
                    suggestions = self.get_object_members(obj, prefix, code)
                
                # Check for variable/function completion
                var_match = re.search(r'\b(\w*)$', current_line)
                if var_match and not import_match and not from_import_match and not obj_match:
                    prefix = var_match.group(1)
                    suggestions = self.get_local_variables(prefix, code, line)
            
            return suggestions
        except Exception as e:
            print(f"Error getting autocomplete suggestions: {e}")
            return []
    
    def get_module_suggestions(self, prefix):
        """Get module completion suggestions"""
        # In a real implementation, this would scan all available Python modules
        common_modules = [
            "os", "sys", "re", "math", "datetime", "time", "json", "csv",
            "random", "collections", "itertools", "functools", "pathlib",
            "threading", "multiprocessing", "subprocess", "socket", "http",
            "urllib", "argparse", "logging", "unittest", "pytest", "numpy",
            "pandas", "matplotlib", "django", "flask", "requests"
        ]
        
        return [m for m in common_modules if m.startswith(prefix)]
    
    def get_module_members(self, module, prefix):
        """Get members of a module for import completion"""
        try:
            # Try to import the module and get its members
            cmd = [
                "python3", "-c", 
                f"import {module}; print(dir({module}))"
            ]
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=2
            )
            if result.returncode == 0:
                members = eval(result.stdout.strip())
                return [m for m in members if m.startswith(prefix) and not m.startswith('_')]
        except Exception:
            pass
        
        return []
    
    def get_object_members(self, obj, prefix, code):
        """Get members of an object for attribute completion"""
        try:
            # This is a simplified implementation
            # A real implementation would use the AST to find the object type
            # and then suggest appropriate members
            
            # Special handling for common modules and types
            if obj == "os":
                common_attrs = [
                    "path", "environ", "getcwd", "chdir", "listdir", "mkdir",
                    "makedirs", "remove", "rmdir", "rename", "system", "walk"
                ]
            elif obj == "sys":
                common_attrs = [
                    "argv", "path", "stdin", "stdout", "stderr", "exit",
                    "platform", "version", "modules", "executable"
                ]
            elif obj == "re":
                common_attrs = [
                    "match", "search", "findall", "split", "sub", "subn",
                    "compile", "IGNORECASE", "MULTILINE", "DOTALL"
                ]
            elif obj == "math":
                common_attrs = [
                    "pi", "e", "sin", "cos", "tan", "log", "log10", "exp",
                    "sqrt", "floor", "ceil", "degrees", "radians"
                ]
            elif obj == "str":
                common_attrs = [
                    "lower", "upper", "strip", "split", "join", "replace",
                    "find", "index", "count", "startswith", "endswith", "format"
                ]
            elif obj == "list":
                common_attrs = [
                    "append", "extend", "insert", "remove", "pop", "clear",
                    "index", "count", "sort", "reverse", "copy"
                ]
            elif obj == "dict":
                common_attrs = [
                    "keys", "values", "items", "get", "clear", "copy",
                    "fromkeys", "pop", "popitem", "setdefault", "update"
                ]
            else:
                # Generic fallback attributes for any object
                common_attrs = [
                    "append", "extend", "add", "update", "remove", "clear",
                    "keys", "values", "items", "get", "set", "pop", "index",
                    "count", "split", "join", "strip", "lower", "upper",
                    "replace", "find", "format", "read", "write", "close"
                ]
            
            return [a for a in common_attrs if a.startswith(prefix)]
        except Exception:
            return []
    
    def get_local_variables(self, prefix, code, current_line):
        """Get local variables and functions for completion"""
        try:
            # Parse the code and extract variable and function names
            tree = ast.parse(code)
            variables = set()
            
            # Add built-in names
            builtin_names = [
                "print", "input", "range", "len", "int", "float", "str", "list",
                "tuple", "dict", "set", "bool", "open", "type", "dir", "help",
                "max", "min", "sum", "sorted", "any", "all", "enumerate", "zip",
                "map", "filter", "lambda", "abs", "round", "pow", "divmod"
            ]
            variables.update(builtin_names)
            
            # Extract all names from the AST
            for node in ast.walk(tree):
                # Get function and class definitions
                if isinstance(node, ast.FunctionDef) or isinstance(node, ast.ClassDef):
                    variables.add(node.name)
                
                # Get variable names from assignments
                elif isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            variables.add(target.id)
                
                # Get import names
                elif isinstance(node, ast.Import):
                    for name in node.names:
                        if name.asname:
                            variables.add(name.asname)
                        else:
                            variables.add(name.name.split('.')[0])
                
                elif isinstance(node, ast.ImportFrom):
                    for name in node.names:
                        if name.asname:
                            variables.add(name.asname)
                        else:
                            variables.add(name.name)
            
            # Filter by prefix
            return sorted([v for v in variables if v.startswith(prefix)])
        except Exception:
            return []
    
    def lint_code(self, code):
        """Lint Python code and return errors"""
        try:
            # Check for syntax errors
            try:
                ast.parse(code)
            except SyntaxError as e:
                return [(e.lineno, e.offset, f"Syntax error: {e.msg}")]
            
            # Run flake8 if available
            with tempfile.NamedTemporaryFile(suffix='.py', delete=False) as temp:
                temp.write(code.encode('utf-8'))
                temp_name = temp.name
            
            try:
                result = subprocess.run(
                    ["flake8", "--format=default", temp_name],
                    capture_output=True, text=True, timeout=5
                )
                
                errors = []
                for line in result.stdout.splitlines():
                    parts = line.split(':', 3)
                    if len(parts) >= 3:
                        line_num = int(parts[1])
                        col_num = int(parts[2])
                        message = parts[3].strip()
                        errors.append((line_num, col_num, message))
                
                return errors
            except Exception:
                # Flake8 not available or error running it
                return []
            finally:
                # Clean up temp file
                os.unlink(temp_name)
        except Exception as e:
            print(f"Error linting code: {e}")
            return []
    
    def run_code(self, code, args=None):
        """Run Python code and return the result"""
        try:
            # Write code to temporary file
            with tempfile.NamedTemporaryFile(suffix='.py', delete=False) as temp:
                temp.write(code.encode('utf-8'))
                temp_name = temp.name
            
            cmd = ["python3", temp_name]
            if args:
                cmd.extend(args)
            
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=30
            )
            
            return {
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode
            }
        except subprocess.TimeoutExpired:
            return {
                "stdout": "",
                "stderr": "Execution timed out after 30 seconds",
                "returncode": -1
            }
        except Exception as e:
            return {
                "stdout": "",
                "stderr": f"Error running code: {e}",
                "returncode": -1
            }
        finally:
            # Clean up temp file
            if os.path.exists(temp_name):
                os.unlink(temp_name)
    
    def format_code(self, code):
        """Format Python code using black"""
        try:
            # Check if black is installed
            result = subprocess.run(
                ["black", "--version"],
                capture_output=True, text=True
            )
            
            if result.returncode != 0:
                # Black not available
                return code
            
            # Format code using black
            with tempfile.NamedTemporaryFile(suffix='.py', delete=False) as temp:
                temp.write(code.encode('utf-8'))
                temp_name = temp.name
            
            result = subprocess.run(
                ["black", "-q", temp_name],
                capture_output=True, text=True
            )
            
            if result.returncode == 0:
                with open(temp_name, 'r') as f:
                    formatted_code = f.read()
                return formatted_code
            else:
                return code
        except Exception as e:
            print(f"Error formatting code: {e}")
            return code
        finally:
            # Clean up temp file
            if 'temp_name' in locals() and os.path.exists(temp_name):
                os.unlink(temp_name)
