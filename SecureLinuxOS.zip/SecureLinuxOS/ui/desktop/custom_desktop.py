#!/usr/bin/env python3

"""
CyberOS Custom Desktop Environment
A lightweight desktop environment with modern UI elements and security features
"""

import os
import sys
import signal
import json
import gi

gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
gi.require_version('Wnck', '3.0')
from gi.repository import Gtk, Gdk, GdkPixbuf, GLib, Wnck, Pango

class CyberOSDesktop:
    """Main desktop environment manager for CyberOS"""
    
    def __init__(self):
        self.config = self.load_config()
        
        # Initialize components
        self.init_display()
        self.init_theme()
        self.init_desktop()
        self.init_panel()
        self.init_dock()
        self.init_workspaces()
        
        # Setup keyboard shortcuts
        self.setup_shortcuts()
        
        # Setup signal handlers
        signal.signal(signal.SIGINT, signal.SIG_DFL)
    
    def load_config(self):
        """Load desktop configuration from file"""
        config_path = "/opt/cyberos/config/os-config.json"
        
        try:
            with open(config_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading configuration: {e}")
            # Return default configuration
            return {
                "ui_configuration": {
                    "color_scheme": {
                        "primary": "#1A1A2E",
                        "secondary": "#16213E",
                        "accent": "#0F3460",
                        "highlight": "#E94560",
                        "text_primary": "#F5F5F5",
                        "text_secondary": "#AAAAAA"
                    },
                    "font_family": "Source Code Pro",
                    "icon_theme": "cyber-icons",
                    "window_manager": "custom_wm",
                    "effects": {
                        "transparency": True,
                        "animations": True,
                        "rounded_corners": True
                    }
                }
            }
    
    def init_display(self):
        """Initialize display settings"""
        # Get primary display
        display = Gdk.Display.get_default()
        monitor = display.get_primary_monitor()
        
        if monitor:
            geometry = monitor.get_geometry()
            self.screen_width = geometry.width
            self.screen_height = geometry.height
        else:
            # Default values if unable to get monitor
            self.screen_width = 1920
            self.screen_height = 1080
        
        print(f"Display initialized: {self.screen_width}x{self.screen_height}")
    
    def init_theme(self):
        """Initialize theme settings"""
        # Set GTK theme
        settings = Gtk.Settings.get_default()
        if settings:
            settings.set_property("gtk-theme-name", "Adwaita-dark")
            settings.set_property("gtk-application-prefer-dark-theme", True)
            
            # Set icon theme if available
            icon_theme = self.config["ui_configuration"].get("icon_theme", "Adwaita")
            settings.set_property("gtk-icon-theme-name", icon_theme)
            
            # Set font
            font_family = self.config["ui_configuration"].get("font_family", "Source Code Pro")
            settings.set_property("gtk-font-name", f"{font_family} 10")
        
        # Apply custom CSS
        self.apply_custom_css()
        
        print("Theme settings applied")
    
    def apply_custom_css(self):
        """Apply custom CSS for desktop components"""
        css_provider = Gtk.CssProvider()
        css_path = "/opt/cyberos/ui/theme/dark-theme.css"
        
        try:
            css_provider.load_from_path(css_path)
            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(),
                css_provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )
        except Exception as e:
            print(f"Error loading CSS: {e}")
            # Fallback inline CSS if file not found
            css = b"""
            .desktop-background {
                background-color: #1A1A2E;
            }
            .panel {
                background-color: #16213E;
                color: #F5F5F5;
                border-bottom: 1px solid #0F3460;
            }
            .dock {
                background-color: rgba(22, 33, 62, 0.8);
                border-radius: 10px;
            }
            .workspace-switcher {
                background-color: rgba(22, 33, 62, 0.8);
                border-radius: 5px;
                padding: 5px;
            }
            .workspace-button {
                background-color: transparent;
                border: 1px solid #0F3460;
                border-radius: 3px;
                min-width: 20px;
                min-height: 20px;
            }
            .workspace-button.active {
                background-color: #E94560;
                border-color: #E94560;
            }
            """
            css_provider.load_from_data(css)
            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(),
                css_provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )
    
    def init_desktop(self):
        """Initialize desktop window and background"""
        # Create main desktop window
        self.desktop_window = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
        self.desktop_window.set_title("CyberOS Desktop")
        self.desktop_window.set_default_size(self.screen_width, self.screen_height)
        self.desktop_window.set_decorated(False)
        self.desktop_window.set_skip_taskbar_hint(True)
        self.desktop_window.set_skip_pager_hint(True)
        self.desktop_window.set_keep_below(True)
        self.desktop_window.set_position(Gtk.WindowPosition.CENTER)
        
        # Connect signals
        self.desktop_window.connect("destroy", Gtk.main_quit)
        self.desktop_window.connect("key-press-event", self.on_key_press)
        
        # Set background
        self.desktop_bg = Gtk.EventBox()
        self.desktop_bg.get_style_context().add_class("desktop-background")
        
        # Try to load wallpaper
        try:
            wallpaper_path = "/opt/cyberos/ui/backgrounds/cyberos-default.jpg"
            if os.path.exists(wallpaper_path):
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                    wallpaper_path, 
                    self.screen_width, 
                    self.screen_height, 
                    False
                )
                bg_image = Gtk.Image.new_from_pixbuf(pixbuf)
                self.desktop_bg.add(bg_image)
            else:
                # Use solid color background if wallpaper not found
                self.desktop_bg.set_name("desktop")
        except Exception as e:
            print(f"Error setting wallpaper: {e}")
            # Use solid color background if error
            self.desktop_bg.set_name("desktop")
        
        # Set up desktop icons container
        self.desktop_icons = Gtk.Fixed()
        
        # Add some basic desktop icons
        self.add_desktop_icon("Dashboard", "utilities-system-monitor-symbolic", self.launch_dashboard, 50, 50)
        self.add_desktop_icon("Terminal", "utilities-terminal-symbolic", self.launch_terminal, 50, 150)
        self.add_desktop_icon("Security Center", "security-high-symbolic", self.launch_security_center, 50, 250)
        self.add_desktop_icon("IDE", "applications-engineering-symbolic", self.launch_ide, 50, 350)
        
        # Add desktop components to layout
        self.desktop_layout = Gtk.Overlay()
        self.desktop_layout.add(self.desktop_bg)
        self.desktop_layout.add_overlay(self.desktop_icons)
        
        # Add layout to window
        self.desktop_window.add(self.desktop_layout)
    
    def add_desktop_icon(self, label_text, icon_name, callback, x, y):
        """Add an icon to the desktop"""
        # Create icon box
        icon_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        icon_box.set_property("margin", 10)
        
        # Create icon button
        button = Gtk.Button()
        button.set_relief(Gtk.ReliefStyle.NONE)
        
        # Set icon
        icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.DIALOG)
        button.add(icon)
        
        # Connect click event
        button.connect("clicked", callback)
        
        # Create label
        label = Gtk.Label(label=label_text)
        label.set_line_wrap(True)
        label.set_justify(Gtk.Justification.CENTER)
        label.set_max_width_chars(15)
        
        # Style the label
        label.override_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(1, 1, 1, 1))
        
        # Add to box
        icon_box.pack_start(button, False, False, 0)
        icon_box.pack_start(label, False, False, 0)
        
        # Add to desktop
        self.desktop_icons.put(icon_box, x, y)
    
    def init_panel(self):
        """Initialize top panel"""
        # Create panel container
        self.panel = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.panel.set_size_request(-1, 30)
        self.panel.get_style_context().add_class("panel")
        
        # Add applications menu
        apps_button = Gtk.Button()
        apps_icon = Gtk.Image.new_from_icon_name("view-grid-symbolic", Gtk.IconSize.SMALL_TOOLBAR)
        apps_button.add(apps_icon)
        apps_button.set_tooltip_text("Applications")
        apps_button.connect("clicked", self.show_applications_menu)
        
        # Add system status area (right side)
        status_area = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        status_area.set_halign(Gtk.Align.END)
        status_area.set_hexpand(True)
        
        # Network status
        network_button = Gtk.Button()
        network_icon = Gtk.Image.new_from_icon_name("network-wireless-signal-excellent-symbolic", Gtk.IconSize.SMALL_TOOLBAR)
        network_button.add(network_icon)
        network_button.set_tooltip_text("Network Settings")
        
        # Battery status
        battery_button = Gtk.Button()
        battery_icon = Gtk.Image.new_from_icon_name("battery-full-symbolic", Gtk.IconSize.SMALL_TOOLBAR)
        battery_button.add(battery_icon)
        battery_button.set_tooltip_text("Battery: 100%")
        
        # Volume
        volume_button = Gtk.VolumeButton()
        volume_button.set_value(0.75)
        
        # Clock
        self.clock_label = Gtk.Label()
        self.update_clock()
        GLib.timeout_add_seconds(1, self.update_clock)
        
        # User menu
        user_button = Gtk.Button()
        user_icon = Gtk.Image.new_from_icon_name("system-users-symbolic", Gtk.IconSize.SMALL_TOOLBAR)
        user_button.add(user_icon)
        user_button.set_tooltip_text("User Menu")
        user_button.connect("clicked", self.show_user_menu)
        
        # Add elements to panel
        self.panel.pack_start(apps_button, False, False, 5)
        
        status_area.pack_end(user_button, False, False, 5)
        status_area.pack_end(self.clock_label, False, False, 5)
        status_area.pack_end(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL), False, False, 5)
        status_area.pack_end(volume_button, False, False, 5)
        status_area.pack_end(battery_button, False, False, 5)
        status_area.pack_end(network_button, False, False, 5)
        
        self.panel.pack_end(status_area, True, True, 5)
        
        # Add panel to desktop
        self.desktop_layout.add_overlay(self.panel)
        self.panel.set_valign(Gtk.Align.START)
    
    def update_clock(self):
        """Update the clock in the panel"""
        import datetime
        now = datetime.datetime.now()
        self.clock_label.set_text(now.strftime("%H:%M"))
        return True  # Continue timer
    
    def init_dock(self):
        """Initialize dock/taskbar at the bottom of the screen"""
        # Create dock container
        self.dock = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        self.dock.set_property("margin", 10)
        self.dock.get_style_context().add_class("dock")
        
        # Add common applications
        self.add_dock_button("utilities-terminal-symbolic", "Terminal", self.launch_terminal)
        self.add_dock_button("web-browser-symbolic", "Web Browser", self.launch_browser)
        self.add_dock_button("utilities-system-monitor-symbolic", "Dashboard", self.launch_dashboard)
        self.add_dock_button("applications-engineering-symbolic", "IDE", self.launch_ide)
        self.add_dock_button("security-high-symbolic", "Security Center", self.launch_security_center)
        self.add_dock_button("preferences-system-symbolic", "Settings", self.launch_settings)
        
        # Add dock to desktop
        self.desktop_layout.add_overlay(self.dock)
        self.dock.set_valign(Gtk.Align.END)
        self.dock.set_halign(Gtk.Align.CENTER)
    
    def add_dock_button(self, icon_name, tooltip, callback):
        """Add a button to the dock"""
        button = Gtk.Button()
        button.set_relief(Gtk.ReliefStyle.NONE)
        
        icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.LARGE_TOOLBAR)
        button.add(icon)
        
        button.set_tooltip_text(tooltip)
        button.connect("clicked", callback)
        
        self.dock.pack_start(button, False, False, 5)
    
    def init_workspaces(self):
        """Initialize workspace switcher"""
        # Create workspace switcher container
        self.workspace_switcher = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        self.workspace_switcher.set_property("margin", 10)
        self.workspace_switcher.get_style_context().add_class("workspace-switcher")
        
        # Create workspace buttons
        self.workspace_buttons = []
        for i in range(4):  # Create 4 workspaces
            button = Gtk.Button()
            button.set_relief(Gtk.ReliefStyle.NONE)
            button.set_size_request(20, 20)
            button.get_style_context().add_class("workspace-button")
            
            if i == 0:  # Mark first workspace as active
                button.get_style_context().add_class("active")
            
            # Set workspace number as data
            button.workspace_id = i
            
            # Connect click event
            button.connect("clicked", self.switch_workspace)
            
            self.workspace_buttons.append(button)
            self.workspace_switcher.pack_start(button, False, False, 0)
        
        # Add workspace switcher to desktop
        self.desktop_layout.add_overlay(self.workspace_switcher)
        self.workspace_switcher.set_valign(Gtk.Align.END)
        self.workspace_switcher.set_halign(Gtk.Align.END)
    
    def switch_workspace(self, button):
        """Switch to selected workspace"""
        # Reset all buttons
        for btn in self.workspace_buttons:
            btn.get_style_context().remove_class("active")
        
        # Activate selected button
        button.get_style_context().add_class("active")
        
        # In a real implementation, this would switch workspaces
        print(f"Switching to workspace {button.workspace_id + 1}")
    
    def setup_shortcuts(self):
        """Setup keyboard shortcuts for desktop interactions"""
        # This would typically use a window manager or compositor API
        # For this example, we'll use key press events on the desktop window
        pass
    
    def on_key_press(self, widget, event):
        """Handle keyboard shortcuts"""
        keyval = event.keyval
        state = event.state
        
        # Alt+Tab for window switching
        if keyval == Gdk.KEY_Tab and state & Gdk.ModifierType.MOD1_MASK:
            self.switch_windows()
            return True
        
        # Ctrl+Alt+T for terminal
        if (keyval == Gdk.KEY_t and 
            state & Gdk.ModifierType.CONTROL_MASK and 
            state & Gdk.ModifierType.MOD1_MASK):
            self.launch_terminal(None)
            return True
        
        # Ctrl+Alt+D for dashboard
        if (keyval == Gdk.KEY_d and 
            state & Gdk.ModifierType.CONTROL_MASK and 
            state & Gdk.ModifierType.MOD1_MASK):
            self.launch_dashboard(None)
            return True
        
        return False
    
    def switch_windows(self):
        """Switch between open windows"""
        # This would use a window manager API in a real implementation
        print("Window switcher activated")
    
    def show_applications_menu(self, button):
        """Show the applications menu"""
        # Create a popup menu
        menu = Gtk.Menu()
        
        # Add menu items
        items = [
            ("Dashboard", "utilities-system-monitor-symbolic", self.launch_dashboard),
            ("Terminal", "utilities-terminal-symbolic", self.launch_terminal),
            ("IDE", "applications-engineering-symbolic", self.launch_ide),
            ("Web Browser", "web-browser-symbolic", self.launch_browser),
            ("Security Center", "security-high-symbolic", self.launch_security_center),
            ("File Manager", "system-file-manager-symbolic", self.launch_file_manager),
            ("Settings", "preferences-system-symbolic", self.launch_settings)
        ]
        
        for label_text, icon_name, callback in items:
            item = Gtk.MenuItem()
            
            # Create box for icon and label
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
            
            # Add icon
            icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.MENU)
            box.pack_start(icon, False, False, 0)
            
            # Add label
            label = Gtk.Label(label=label_text)
            box.pack_start(label, False, False, 0)
            
            item.add(box)
            item.connect("activate", callback)
            menu.append(item)
        
        # Add separator
        menu.append(Gtk.SeparatorMenuItem())
        
        # Add logout/power options
        power_item = Gtk.MenuItem()
        power_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        power_icon = Gtk.Image.new_from_icon_name("system-shutdown-symbolic", Gtk.IconSize.MENU)
        power_label = Gtk.Label(label="Power Options")
        power_box.pack_start(power_icon, False, False, 0)
        power_box.pack_start(power_label, False, False, 0)
        power_item.add(power_box)
        power_item.connect("activate", self.show_power_menu)
        menu.append(power_item)
        
        # Show the menu
        menu.show_all()
        menu.popup_at_widget(button, Gdk.Gravity.SOUTH_WEST, Gdk.Gravity.NORTH_WEST, None)
    
    def show_user_menu(self, button):
        """Show the user menu"""
        # Create a popup menu
        menu = Gtk.Menu()
        
        # Get current user
        username = os.environ.get("USER", "user")
        
        # Add user info
        user_item = Gtk.MenuItem()
        user_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        user_icon = Gtk.Image.new_from_icon_name("avatar-default-symbolic", Gtk.IconSize.LARGE_TOOLBAR)
        user_label = Gtk.Label()
        user_label.set_markup(f"<b>{username}</b>")
        user_box.pack_start(user_icon, False, False, 0)
        user_box.pack_start(user_label, False, False, 0)
        user_item.add(user_box)
        user_item.set_sensitive(False)
        menu.append(user_item)
        
        menu.append(Gtk.SeparatorMenuItem())
        
        # Add menu items
        items = [
            ("Account Settings", "preferences-system-users-symbolic", self.launch_account_settings),
            ("Lock Screen", "system-lock-screen-symbolic", self.lock_screen),
            ("Logout", "system-log-out-symbolic", self.logout)
        ]
        
        for label_text, icon_name, callback in items:
            item = Gtk.MenuItem()
            
            # Create box for icon and label
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
            
            # Add icon
            icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.MENU)
            box.pack_start(icon, False, False, 0)
            
            # Add label
            label = Gtk.Label(label=label_text)
            box.pack_start(label, False, False, 0)
            
            item.add(box)
            item.connect("activate", callback)
            menu.append(item)
        
        # Show the menu
        menu.show_all()
        menu.popup_at_widget(button, Gdk.Gravity.SOUTH_EAST, Gdk.Gravity.NORTH_EAST, None)
    
    def show_power_menu(self, button):
        """Show power options menu"""
        # Create a popup menu
        menu = Gtk.Menu()
        
        # Add menu items
        items = [
            ("Lock Screen", "system-lock-screen-symbolic", self.lock_screen),
            ("Logout", "system-log-out-symbolic", self.logout),
            ("Restart", "system-reboot-symbolic", self.restart),
            ("Shutdown", "system-shutdown-symbolic", self.shutdown)
        ]
        
        for label_text, icon_name, callback in items:
            item = Gtk.MenuItem()
            
            # Create box for icon and label
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
            
            # Add icon
            icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.MENU)
            box.pack_start(icon, False, False, 0)
            
            # Add label
            label = Gtk.Label(label=label_text)
            box.pack_start(label, False, False, 0)
            
            item.add(box)
            item.connect("activate", callback)
            menu.append(item)
        
        # Show the menu
        menu.show_all()
        menu.popup_at_pointer(None)
    
    def launch_dashboard(self, widget):
        """Launch the CyberOS dashboard"""
        try:
            os.system("cyberos-dashboard &")
        except Exception as e:
            print(f"Error launching dashboard: {e}")
    
    def launch_terminal(self, widget):
        """Launch terminal emulator"""
        try:
            os.system("x-terminal-emulator &")
        except Exception as e:
            print(f"Error launching terminal: {e}")
    
    def launch_browser(self, widget):
        """Launch web browser"""
        try:
            os.system("x-www-browser &")
        except Exception as e:
            print(f"Error launching browser: {e}")
    
    def launch_ide(self, widget):
        """Launch CyberDev IDE"""
        try:
            os.system("cyberdev-ide &")
        except Exception as e:
            print(f"Error launching IDE: {e}")
    
    def launch_security_center(self, widget):
        """Launch security center"""
        # This would launch a security-focused application
        print("Launching Security Center")
    
    def launch_file_manager(self, widget):
        """Launch file manager"""
        try:
            os.system("xdg-open ~ &")
        except Exception as e:
            print(f"Error launching file manager: {e}")
    
    def launch_settings(self, widget):
        """Launch settings application"""
        # This would launch a settings application
        print("Launching Settings")
    
    def launch_account_settings(self, widget):
        """Launch account settings"""
        # This would launch account settings
        print("Launching Account Settings")
    
    def lock_screen(self, widget):
        """Lock the screen"""
        try:
            os.system("xdg-screensaver lock")
        except Exception as e:
            print(f"Error locking screen: {e}")
    
    def logout(self, widget):
        """Logout the current user"""
        dialog = Gtk.MessageDialog(
            transient_for=self.desktop_window,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text="Are you sure you want to logout?"
        )
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            Gtk.main_quit()
    
    def restart(self, widget):
        """Restart the system"""
        dialog = Gtk.MessageDialog(
            transient_for=self.desktop_window,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text="Are you sure you want to restart the system?"
        )
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            try:
                os.system("systemctl reboot")
            except Exception as e:
                print(f"Error restarting: {e}")
    
    def shutdown(self, widget):
        """Shutdown the system"""
        dialog = Gtk.MessageDialog(
            transient_for=self.desktop_window,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text="Are you sure you want to shutdown the system?"
        )
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            try:
                os.system("systemctl poweroff")
            except Exception as e:
                print(f"Error shutting down: {e}")
    
    def run(self):
        """Start the desktop environment"""
        self.desktop_window.show_all()
        Gtk.main()

def main():
    """Main entry point for the desktop environment"""
    desktop = CyberOSDesktop()
    desktop.run()

if __name__ == "__main__":
    main()
