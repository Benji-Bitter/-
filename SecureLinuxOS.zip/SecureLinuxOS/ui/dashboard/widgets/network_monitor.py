#!/usr/bin/env python3

"""
Network Monitor Widget
Displays network information, connections, and statistics
"""

import os
import subprocess
import threading
import time
import json
import gi
import psutil
import socket
from datetime import datetime

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk

class NetworkMonitorWidget(Gtk.Box):
    """Widget for monitoring network connections and traffic"""
    
    def __init__(self):
        Gtk.Box.__init__(self, orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.set_size_request(600, 300)
        self.get_style_context().add_class("widget")
        
        # Store network history for graphs
        self.network_history = {
            "timestamps": [],
            "bytes_sent": [],
            "bytes_recv": []
        }
        
        # Store historical network usage
        self.last_bytes_sent = 0
        self.last_bytes_recv = 0
        self.last_check_time = time.time()
        
        # Create widget header
        self.create_header()
        
        # Create widget content
        self.create_content()
        
        # Initialize the widget with data
        self.update()
    
    def create_header(self):
        """Create the widget header"""
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        header_box.get_style_context().add_class("widget-header")
        
        # Widget title
        title_icon = Gtk.Image.new_from_icon_name("network-transmit-receive-symbolic", Gtk.IconSize.MENU)
        title_label = Gtk.Label()
        title_label.set_markup("<b>Network Monitor</b>")
        
        # Widget controls
        refresh_button = Gtk.Button.new_from_icon_name("view-refresh-symbolic", Gtk.IconSize.MENU)
        refresh_button.set_tooltip_text("Refresh")
        refresh_button.connect("clicked", self.on_refresh_clicked)
        
        options_button = Gtk.MenuButton()
        options_button.set_image(Gtk.Image.new_from_icon_name("emblem-system-symbolic", Gtk.IconSize.MENU))
        options_button.set_tooltip_text("Options")
        
        # Create options menu
        menu = Gtk.Menu()
        
        detail_item = Gtk.MenuItem(label="Network Details")
        detail_item.connect("activate", self.on_network_details)
        menu.append(detail_item)
        
        traffic_item = Gtk.MenuItem(label="Traffic Analysis")
        menu.append(traffic_item)
        
        ports_item = Gtk.MenuItem(label="Open Ports")
        menu.append(ports_item)
        
        menu.show_all()
        options_button.set_popup(menu)
        
        # Add elements to header
        header_box.pack_start(title_icon, False, False, 0)
        header_box.pack_start(title_label, False, False, 0)
        header_box.pack_end(options_button, False, False, 0)
        header_box.pack_end(refresh_button, False, False, 0)
        
        self.pack_start(header_box, False, False, 0)
    
    def create_content(self):
        """Create the widget content"""
        content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        content_box.set_property("margin", 10)
        
        # Network interfaces section
        interfaces_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        
        # Interface selection
        selection_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        selection_label = Gtk.Label(label="Interface:", xalign=0)
        
        # Create interface dropdown
        self.interface_combo = Gtk.ComboBoxText()
        self.populate_interfaces()
        
        selection_box.pack_start(selection_label, False, False, 0)
        selection_box.pack_start(self.interface_combo, True, True, 0)
        
        # Network status
        status_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        
        # IP Address
        ip_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        ip_label = Gtk.Label(label="IP Address:", xalign=0)
        self.ip_value = Gtk.Label(xalign=0)
        ip_box.pack_start(ip_label, False, False, 0)
        ip_box.pack_start(self.ip_value, True, True, 0)
        
        # MAC Address
        mac_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        mac_label = Gtk.Label(label="MAC Address:", xalign=0)
        self.mac_value = Gtk.Label(xalign=0)
        mac_box.pack_start(mac_label, False, False, 0)
        mac_box.pack_start(self.mac_value, True, True, 0)
        
        # Status
        status_label_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        status_label = Gtk.Label(label="Status:", xalign=0)
        self.status_value = Gtk.Label(xalign=0)
        status_label_box.pack_start(status_label, False, False, 0)
        status_label_box.pack_start(self.status_value, True, True, 0)
        
        # Interface statistics
        stats_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        
        # Traffic rates
        rates_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        
        # Upload rate
        upload_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        upload_label = Gtk.Label(label="Upload", xalign=0.5)
        self.upload_value = Gtk.Label(xalign=0.5)
        self.upload_value.set_markup("<span size='large' weight='bold'>0 KB/s</span>")
        upload_box.pack_start(upload_label, False, False, 0)
        upload_box.pack_start(self.upload_value, False, False, 0)
        
        # Download rate
        download_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        download_label = Gtk.Label(label="Download", xalign=0.5)
        self.download_value = Gtk.Label(xalign=0.5)
        self.download_value.set_markup("<span size='large' weight='bold'>0 KB/s</span>")
        download_box.pack_start(download_label, False, False, 0)
        download_box.pack_start(self.download_value, False, False, 0)
        
        # Total transferred
        total_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        total_label = Gtk.Label(label="Total Transferred", xalign=0.5)
        self.total_value = Gtk.Label(xalign=0.5)
        self.total_value.set_markup("<span size='large' weight='bold'>0 MB</span>")
        total_box.pack_start(total_label, False, False, 0)
        total_box.pack_start(self.total_value, False, False, 0)
        
        # Add all boxes to rates box
        rates_box.pack_start(upload_box, True, True, 0)
        rates_box.pack_start(download_box, True, True, 0)
        rates_box.pack_start(total_box, True, True, 0)
        
        # Add all elements to their containers
        interfaces_box.pack_start(selection_box, False, False, 0)
        interfaces_box.pack_start(ip_box, False, False, 0)
        interfaces_box.pack_start(mac_box, False, False, 0)
        interfaces_box.pack_start(status_label_box, False, False, 0)
        
        stats_box.pack_start(rates_box, False, False, 0)
        
        # Active connections section
        connections_frame = Gtk.Frame()
        connections_frame.set_label("Active Connections")
        connections_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        connections_box.set_property("margin", 10)
        
        # Create scrolled window for connections
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_min_content_height(150)
        
        # Create treeview for connections
        self.connections_store = Gtk.ListStore(str, str, str, str, str)
        self.connections_view = Gtk.TreeView(model=self.connections_store)
        
        # Add columns
        columns = ["Process", "Local Address", "Local Port", "Remote Address", "Status"]
        for i, title in enumerate(columns):
            renderer = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn(title, renderer, text=i)
            column.set_resizable(True)
            column.set_sort_column_id(i)
            self.connections_view.append_column(column)
        
        scrolled.add(self.connections_view)
        connections_box.pack_start(scrolled, True, True, 0)
        connections_frame.add(connections_box)
        
        # Add all sections to the content box
        content_box.pack_start(interfaces_box, False, False, 0)
        content_box.pack_start(Gtk.Separator(), False, False, 5)
        content_box.pack_start(stats_box, False, False, 0)
        content_box.pack_start(Gtk.Separator(), False, False, 5)
        content_box.pack_start(connections_frame, True, True, 0)
        
        self.pack_start(content_box, True, True, 0)
        
        # Connect interface selection change event
        self.interface_combo.connect("changed", self.on_interface_changed)
    
    def populate_interfaces(self):
        """Populate network interfaces dropdown"""
        self.interface_combo.remove_all()
        
        # Get network interfaces
        interfaces = psutil.net_if_addrs().keys()
        
        # Add to dropdown
        for interface in interfaces:
            if interface != 'lo':  # Skip loopback
                self.interface_combo.append_text(interface)
        
        # Select first interface
        if self.interface_combo.get_model().iter_n_children() > 0:
            self.interface_combo.set_active(0)
    
    def update(self):
        """Update widget with current network data"""
        # Run network checks in a separate thread to avoid blocking UI
        threading.Thread(target=self.check_network, daemon=True).start()
    
    def check_network(self):
        """Check network status and update UI"""
        # Get selected interface
        interface = self.interface_combo.get_active_text()
        if not interface:
            return
        
        try:
            # Get interface info
            addresses = psutil.net_if_addrs().get(interface, [])
            stats = psutil.net_if_stats().get(interface)
            
            # Get IP and MAC addresses
            ip_address = "Not available"
            mac_address = "Not available"
            
            for addr in addresses:
                if addr.family == socket.AF_INET:
                    ip_address = addr.address
                elif addr.family == psutil.AF_LINK:
                    mac_address = addr.address
            
            # Get interface status
            if stats:
                status = "Up" if stats.isup else "Down"
                speed = f"{stats.speed} Mbps" if stats.speed > 0 else "Unknown"
                status_text = f"{status} - {speed}"
            else:
                status_text = "Unknown"
            
            # Get current network counters
            counters = psutil.net_io_counters(pernic=True).get(interface)
            current_time = time.time()
            
            if counters:
                # Calculate transfer rates
                time_diff = current_time - self.last_check_time
                
                if self.last_bytes_sent > 0 and self.last_bytes_recv > 0:
                    bytes_sent_rate = (counters.bytes_sent - self.last_bytes_sent) / time_diff
                    bytes_recv_rate = (counters.bytes_recv - self.last_bytes_recv) / time_diff
                else:
                    bytes_sent_rate = 0
                    bytes_recv_rate = 0
                
                # Store for next check
                self.last_bytes_sent = counters.bytes_sent
                self.last_bytes_recv = counters.bytes_recv
                self.last_check_time = current_time
                
                # Store in history
                self.network_history["timestamps"].append(datetime.now())
                self.network_history["bytes_sent"].append(bytes_sent_rate)
                self.network_history["bytes_recv"].append(bytes_recv_rate)
                
                # Keep only last 60 data points
                if len(self.network_history["timestamps"]) > 60:
                    self.network_history["timestamps"].pop(0)
                    self.network_history["bytes_sent"].pop(0)
                    self.network_history["bytes_recv"].pop(0)
                
                # Format rates for display
                upload_text = self.format_transfer_rate(bytes_sent_rate)
                download_text = self.format_transfer_rate(bytes_recv_rate)
                
                # Calculate total transferred
                total_bytes = counters.bytes_sent + counters.bytes_recv
                total_text = self.format_bytes(total_bytes)
                
                # Update UI with rates
                GLib.idle_add(
                    self.upload_value.set_markup,
                    f"<span size='large' weight='bold'>{upload_text}</span>"
                )
                
                GLib.idle_add(
                    self.download_value.set_markup,
                    f"<span size='large' weight='bold'>{download_text}</span>"
                )
                
                GLib.idle_add(
                    self.total_value.set_markup,
                    f"<span size='large' weight='bold'>{total_text}</span>"
                )
            
            # Update interface info in UI
            GLib.idle_add(self.ip_value.set_text, ip_address)
            GLib.idle_add(self.mac_value.set_text, mac_address)
            GLib.idle_add(self.status_value.set_text, status_text)
            
            # Update connections list
            self.update_connections()
            
        except Exception as e:
            print(f"Error checking network: {e}")
    
    def update_connections(self):
        """Update the list of active network connections"""
        # Get all connections
        connections = psutil.net_connections(kind='inet')
        
        # Clear existing list
        GLib.idle_add(self.connections_store.clear)
        
        # Filter and add connections to list
        for conn in connections:
            try:
                # Only show established, listening, or close_wait connections
                if conn.status in ['ESTABLISHED', 'LISTEN', 'CLOSE_WAIT']:
                    # Get process name
                    process_name = ""
                    if conn.pid:
                        try:
                            process = psutil.Process(conn.pid)
                            process_name = process.name()
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            process_name = "Unknown"
                    
                    # Get local address and port
                    local_addr = conn.laddr.ip if conn.laddr else "0.0.0.0"
                    local_port = str(conn.laddr.port) if conn.laddr else ""
                    
                    # Get remote address and port
                    remote_addr = ""
                    if conn.raddr:
                        remote_addr = f"{conn.raddr.ip}:{conn.raddr.port}"
                    
                    # Add to list
                    GLib.idle_add(
                        self.connections_store.append,
                        [process_name, local_addr, local_port, remote_addr, conn.status]
                    )
            except Exception as e:
                print(f"Error processing connection: {e}")
    
    def format_transfer_rate(self, bytes_per_sec):
        """Format a transfer rate for display"""
        if bytes_per_sec < 1024:
            return f"{bytes_per_sec:.1f} B/s"
        elif bytes_per_sec < 1024 * 1024:
            return f"{bytes_per_sec / 1024:.1f} KB/s"
        elif bytes_per_sec < 1024 * 1024 * 1024:
            return f"{bytes_per_sec / (1024 * 1024):.1f} MB/s"
        else:
            return f"{bytes_per_sec / (1024 * 1024 * 1024):.1f} GB/s"
    
    def format_bytes(self, bytes_value):
        """Format bytes for display"""
        if bytes_value < 1024:
            return f"{bytes_value} B"
        elif bytes_value < 1024 * 1024:
            return f"{bytes_value / 1024:.1f} KB"
        elif bytes_value < 1024 * 1024 * 1024:
            return f"{bytes_value / (1024 * 1024):.1f} MB"
        elif bytes_value < 1024 * 1024 * 1024 * 1024:
            return f"{bytes_value / (1024 * 1024 * 1024):.1f} GB"
        else:
            return f"{bytes_value / (1024 * 1024 * 1024 * 1024):.1f} TB"
    
    def on_refresh_clicked(self, button):
        """Handle refresh button click"""
        threading.Thread(target=self.update, daemon=True).start()
    
    def on_interface_changed(self, combo):
        """Handle interface selection change"""
        # Reset counters
        self.last_bytes_sent = 0
        self.last_bytes_recv = 0
        
        # Update with new interface
        threading.Thread(target=self.update, daemon=True).start()
    
    def on_network_details(self, menuitem):
        """Show detailed network information"""
        interface = self.interface_combo.get_active_text()
        if not interface:
            return
        
        # Create dialog
        dialog = Gtk.Dialog(
            title=f"Network Details - {interface}",
            transient_for=self.get_toplevel(),
            flags=0,
            buttons=(Gtk.STOCK_CLOSE, Gtk.ResponseType.CLOSE)
        )
        dialog.set_default_size(500, 400)
        
        # Create content area
        content_area = dialog.get_content_area()
        content_area.set_property("margin", 15)
        
        # Create notebook for tabs
        notebook = Gtk.Notebook()
        content_area.pack_start(notebook, True, True, 0)
        
        # Interface Details Tab
        interface_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        interface_box.set_property("margin", 10)
        
        # Get interface details
        interface_info = self.get_interface_details(interface)
        interface_info_label = Gtk.Label(xalign=0)
        interface_info_label.set_markup(interface_info)
        interface_box.pack_start(interface_info_label, False, False, 0)
        
        notebook.append_page(interface_box, Gtk.Label(label="Interface Details"))
        
        # Routing Table Tab
        routing_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        routing_box.set_property("margin", 10)
        
        # Create scrolled window for routing table
        routing_scroll = Gtk.ScrolledWindow()
        routing_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        
        # Get routing table
        routing_info = self.get_routing_table()
        routing_info_label = Gtk.Label(xalign=0)
        routing_info_label.set_markup(routing_info)
        
        routing_scroll.add(routing_info_label)
        routing_box.pack_start(routing_scroll, True, True, 0)
        
        notebook.append_page(routing_box, Gtk.Label(label="Routing Table"))
        
        # DNS Settings Tab
        dns_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        dns_box.set_property("margin", 10)
        
        # Get DNS settings
        dns_info = self.get_dns_settings()
        dns_info_label = Gtk.Label(xalign=0)
        dns_info_label.set_markup(dns_info)
        dns_box.pack_start(dns_info_label, False, False, 0)
        
        notebook.append_page(dns_box, Gtk.Label(label="DNS Settings"))
        
        # Open Ports Tab
        ports_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        ports_box.set_property("margin", 10)
        
        # Create scrolled window for open ports
        ports_scroll = Gtk.ScrolledWindow()
        ports_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        ports_scroll.set_min_content_height(200)
        
        # Create listbox for open ports
        ports_store = Gtk.ListStore(str, str, str, str)
        ports_view = Gtk.TreeView(model=ports_store)
        
        # Add columns
        columns = ["Port", "Protocol", "State", "Service"]
        for i, title in enumerate(columns):
            renderer = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn(title, renderer, text=i)
            column.set_resizable(True)
            column.set_sort_column_id(i)
            ports_view.append_column(column)
        
        # Get open ports data
        self.populate_open_ports(ports_store)
        
        ports_scroll.add(ports_view)
        ports_box.pack_start(ports_scroll, True, True, 0)
        
        notebook.append_page(ports_box, Gtk.Label(label="Open Ports"))
        
        # Show dialog
        dialog.show_all()
        dialog.run()
        dialog.destroy()
    
    def get_interface_details(self, interface):
        """Get detailed information about a network interface"""
        try:
            details = []
            details.append(f"<b>Interface:</b> {interface}")
            
            # Get addresses
            addresses = psutil.net_if_addrs().get(interface, [])
            stats = psutil.net_if_stats().get(interface)
            
            # Add interface statistics
            if stats:
                details.append(f"<b>Status:</b> {'Up' if stats.isup else 'Down'}")
                details.append(f"<b>Speed:</b> {stats.speed} Mbps")
                details.append(f"<b>MTU:</b> {stats.mtu}")
                details.append(f"<b>Duplex:</b> {stats.duplex}")
            
            # Add IP address info
            details.append("\n<b>Addresses:</b>")
            for addr in addresses:
                if addr.family == socket.AF_INET:
                    details.append(f"  <b>IPv4 Address:</b> {addr.address}")
                    details.append(f"  <b>Netmask:</b> {addr.netmask}")
                    details.append(f"  <b>Broadcast:</b> {addr.broadcast}")
                elif addr.family == socket.AF_INET6:
                    details.append(f"  <b>IPv6 Address:</b> {addr.address}")
                    details.append(f"  <b>Netmask:</b> {addr.netmask}")
                elif addr.family == psutil.AF_LINK:
                    details.append(f"  <b>MAC Address:</b> {addr.address}")
            
            # Get network counters
            counters = psutil.net_io_counters(pernic=True).get(interface)
            if counters:
                details.append("\n<b>Traffic Statistics:</b>")
                details.append(f"  <b>Bytes sent:</b> {self.format_bytes(counters.bytes_sent)}")
                details.append(f"  <b>Bytes received:</b> {self.format_bytes(counters.bytes_recv)}")
                details.append(f"  <b>Packets sent:</b> {counters.packets_sent}")
                details.append(f"  <b>Packets received:</b> {counters.packets_recv}")
                details.append(f"  <b>Errors on receive:</b> {counters.errin}")
                details.append(f"  <b>Errors on send:</b> {counters.errout}")
                details.append(f"  <b>Dropped packets (receive):</b> {counters.dropin}")
                details.append(f"  <b>Dropped packets (send):</b> {counters.dropout}")
            
            return "\n".join(details)
            
        except Exception as e:
            return f"<span foreground='red'>Error getting interface details: {e}</span>"
    
    def get_routing_table(self):
        """Get the system routing table"""
        try:
            # Run route command to get routing table
            result = subprocess.run(
                ["route", "-n"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            if result.returncode == 0:
                # Format the routing table
                lines = result.stdout.split('\n')
                formatted_table = []
                
                for line in lines:
                    formatted_table.append(f"<tt>{line}</tt>")
                
                return "\n".join(formatted_table)
            else:
                return "<span foreground='red'>Failed to get routing table</span>"
                
        except Exception as e:
            return f"<span foreground='red'>Error getting routing table: {e}</span>"
    
    def get_dns_settings(self):
        """Get DNS settings"""
        try:
            dns_info = []
            
            # Check /etc/resolv.conf for nameservers
            if os.path.exists("/etc/resolv.conf"):
                dns_info.append("<b>DNS Servers:</b>")
                
                with open("/etc/resolv.conf", "r") as f:
                    for line in f:
                        if line.startswith("nameserver"):
                            parts = line.strip().split()
                            if len(parts) >= 2:
                                dns_info.append(f"  {parts[1]}")
            
            # Check for search domains
            if os.path.exists("/etc/resolv.conf"):
                with open("/etc/resolv.conf", "r") as f:
                    for line in f:
                        if line.startswith("search"):
                            parts = line.strip().split()
                            if len(parts) >= 2:
                                dns_info.append("\n<b>Search Domains:</b>")
                                for domain in parts[1:]:
                                    dns_info.append(f"  {domain}")
            
            # If no DNS info found
            if len(dns_info) == 0:
                dns_info.append("<span foreground='red'>No DNS settings found</span>")
            
            return "\n".join(dns_info)
                
        except Exception as e:
            return f"<span foreground='red'>Error getting DNS settings: {e}</span>"
    
    def populate_open_ports(self, store):
        """Populate the open ports list"""
        try:
            # Clear the store
            store.clear()
            
            # Run netstat to get listening ports
            # Using ss command instead of netstat as it's more modern
            result = subprocess.run(
                ["ss", "-tuln"],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                lines = result.stdout.split('\n')
                
                # Skip header
                for line in lines[1:]:
                    if not line.strip():
                        continue
                    
                    # Parse the line
                    parts = line.split()
                    if len(parts) >= 5:
                        protocol = parts[0]
                        state = parts[1]
                        
                        # Extract local address and port
                        local_addr = parts[4]
                        port = local_addr.split(":")[-1] if ":" in local_addr else ""
                        
                        # Try to get service name for this port
                        service = "Unknown"
                        try:
                            if port.isdigit():
                                service_info = socket.getservbyport(int(port))
                                if service_info:
                                    service = service_info
                        except (socket.error, OSError):
                            pass
                        
                        # Add to store
                        store.append([port, protocol, state, service])
            
        except Exception as e:
            print(f"Error getting open ports: {e}")
            # Add an error entry
            store.append(["Error", "", "", f"Could not get open ports: {e}"])
