#!/usr/bin/env python3

"""
Security Status Widget
Displays system security status and potential vulnerabilities
"""

import os
import subprocess
import threading
import time
import json
import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib

class SecurityStatusWidget(Gtk.Box):
    """Widget for monitoring system security status"""
    
    def __init__(self):
        Gtk.Box.__init__(self, orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.set_size_request(300, 300)
        self.get_style_context().add_class("widget")
        
        # Security status states
        self.security_statuses = {
            "good": {
                "label": "Protected",
                "icon": "security-high-symbolic",
                "color": "#4CAF50"
            },
            "warning": {
                "label": "Issues Detected",
                "icon": "security-medium-symbolic",
                "color": "#FFC107"
            },
            "critical": {
                "label": "At Risk",
                "icon": "security-low-symbolic",
                "color": "#F44336"
            }
        }
        
        # Security checks
        self.security_checks = {
            "firewall": {
                "status": "unknown",
                "last_check": 0
            },
            "updates": {
                "status": "unknown",
                "last_check": 0
            },
            "antivirus": {
                "status": "unknown",
                "last_check": 0
            },
            "rootkit": {
                "status": "unknown",
                "last_check": 0
            },
            "permissions": {
                "status": "unknown",
                "last_check": 0
            }
        }
        
        # Create widget header
        self.create_header()
        
        # Create widget content
        self.create_content()
        
        # Initialize the widget with data
        self.update()
    
    def create_header(self):
        """Create the widget header"""
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        header_box.get_style_context().add_class("widget-header")
        
        # Widget title
        title_icon = Gtk.Image.new_from_icon_name("security-high-symbolic", Gtk.IconSize.MENU)
        title_label = Gtk.Label()
        title_label.set_markup("<b>Security Status</b>")
        
        # Widget controls
        scan_button = Gtk.Button.new_from_icon_name("system-run-symbolic", Gtk.IconSize.MENU)
        scan_button.set_tooltip_text("Run Security Scan")
        scan_button.connect("clicked", self.on_scan_clicked)
        
        options_button = Gtk.MenuButton()
        options_button.set_image(Gtk.Image.new_from_icon_name("emblem-system-symbolic", Gtk.IconSize.MENU))
        options_button.set_tooltip_text("Options")
        
        # Create options menu
        menu = Gtk.Menu()
        
        detail_item = Gtk.MenuItem(label="Security Details")
        detail_item.connect("activate", self.on_security_details)
        menu.append(detail_item)
        
        report_item = Gtk.MenuItem(label="Security Report")
        menu.append(report_item)
        
        settings_item = Gtk.MenuItem(label="Security Settings")
        menu.append(settings_item)
        
        menu.show_all()
        options_button.set_popup(menu)
        
        # Add elements to header
        header_box.pack_start(title_icon, False, False, 0)
        header_box.pack_start(title_label, False, False, 0)
        header_box.pack_end(options_button, False, False, 0)
        header_box.pack_end(scan_button, False, False, 0)
        
        self.pack_start(header_box, False, False, 0)
    
    def create_content(self):
        """Create the widget content"""
        content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        content_box.set_property("margin", 10)
        
        # Overall security status
        status_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        
        # Status icon
        self.status_icon = Gtk.Image.new_from_icon_name("security-high-symbolic", Gtk.IconSize.DIALOG)
        
        # Status details
        status_details = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        
        self.status_label = Gtk.Label(xalign=0)
        self.status_label.set_markup("<span size='large' weight='bold'>Protected</span>")
        
        self.status_description = Gtk.Label(xalign=0)
        self.status_description.set_markup("Your system is currently protected and up to date.")
        self.status_description.set_line_wrap(True)
        
        status_details.pack_start(self.status_label, False, False, 0)
        status_details.pack_start(self.status_description, False, False, 0)
        
        status_box.pack_start(self.status_icon, False, False, 0)
        status_box.pack_start(status_details, True, True, 0)
        
        # Create security checks list
        checks_frame = Gtk.Frame()
        checks_frame.set_shadow_type(Gtk.ShadowType.NONE)
        
        self.checks_list = Gtk.ListBox()
        self.checks_list.set_selection_mode(Gtk.SelectionMode.NONE)
        
        # Firewall check
        self.firewall_row = self.create_check_row("Firewall", "Checking...", "dialog-information-symbolic")
        self.checks_list.add(self.firewall_row)
        
        # Updates check
        self.updates_row = self.create_check_row("System Updates", "Checking...", "dialog-information-symbolic")
        self.checks_list.add(self.updates_row)
        
        # Antivirus check
        self.antivirus_row = self.create_check_row("Antivirus", "Checking...", "dialog-information-symbolic")
        self.checks_list.add(self.antivirus_row)
        
        # Permissions check
        self.permissions_row = self.create_check_row("File Permissions", "Checking...", "dialog-information-symbolic")
        self.checks_list.add(self.permissions_row)
        
        # Rootkit check
        self.rootkit_row = self.create_check_row("Rootkit Detection", "Checking...", "dialog-information-symbolic")
        self.checks_list.add(self.rootkit_row)
        
        checks_frame.add(self.checks_list)
        
        # Last scan time
        self.last_scan_label = Gtk.Label(xalign=0)
        self.last_scan_label.set_markup("<i>Last scan: Never</i>")
        
        # Add all elements to content box
        content_box.pack_start(status_box, False, False, 0)
        content_box.pack_start(Gtk.Separator(), False, False, 5)
        content_box.pack_start(checks_frame, True, True, 0)
        content_box.pack_start(self.last_scan_label, False, False, 5)
        
        self.pack_start(content_box, True, True, 0)
    
    def create_check_row(self, title, status, icon_name):
        """Create a row for a security check"""
        row = Gtk.ListBoxRow()
        
        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        hbox.set_property("margin", 5)
        
        # Status icon
        icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.MENU)
        
        # Check details
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        
        title_label = Gtk.Label(label=title, xalign=0)
        title_label.set_markup(f"<b>{title}</b>")
        
        status_label = Gtk.Label(label=status, xalign=0)
        
        vbox.pack_start(title_label, False, False, 0)
        vbox.pack_start(status_label, False, False, 0)
        
        hbox.pack_start(icon, False, False, 0)
        hbox.pack_start(vbox, True, True, 0)
        
        row.add(hbox)
        
        # Store references to icon and status label for updating
        row.icon = icon
        row.status_label = status_label
        
        return row
    
    def update(self):
        """Update widget with current security data"""
        # Run security checks in a separate thread to avoid blocking UI
        threading.Thread(target=self.run_security_checks, daemon=True).start()
    
    def run_security_checks(self):
        """Run security checks and update UI"""
        # Run individual security checks
        self.check_firewall()
        self.check_updates()
        self.check_antivirus()
        self.check_permissions()
        self.check_rootkit()
        
        # Update overall security status
        self.calculate_overall_status()
        
        # Update last scan time
        current_time = time.strftime("%Y-%m-%d %H:%M:%S")
        GLib.idle_add(
            self.last_scan_label.set_markup,
            f"<i>Last scan: {current_time}</i>"
        )
    
    def check_firewall(self):
        """Check firewall status"""
        try:
            # Run ufw status command
            result = subprocess.run(
                ["ufw", "status"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            if "Status: active" in result.stdout:
                status = "good"
                message = "Firewall is active and configured"
                icon = "security-high-symbolic"
            else:
                status = "critical"
                message = "Firewall is not active"
                icon = "security-low-symbolic"
            
            self.security_checks["firewall"]["status"] = status
            self.security_checks["firewall"]["last_check"] = time.time()
            
            # Update UI
            GLib.idle_add(self.update_check_row, 
                          self.firewall_row, 
                          message, 
                          icon)
            
        except Exception as e:
            print(f"Error checking firewall: {e}")
            self.security_checks["firewall"]["status"] = "warning"
            GLib.idle_add(self.update_check_row, 
                          self.firewall_row, 
                          "Could not determine firewall status", 
                          "dialog-warning-symbolic")
    
    def check_updates(self):
        """Check for system updates"""
        try:
            # Check for available updates (simulated for speed)
            # In a real implementation, we would use apt-check or similar
            
            # Simulate finding some updates
            update_count = 5
            security_count = 2
            
            if security_count > 0:
                status = "critical"
                message = f"{update_count} updates available ({security_count} security updates)"
                icon = "security-low-symbolic"
            elif update_count > 0:
                status = "warning"
                message = f"{update_count} updates available"
                icon = "security-medium-symbolic"
            else:
                status = "good"
                message = "System is up to date"
                icon = "security-high-symbolic"
            
            self.security_checks["updates"]["status"] = status
            self.security_checks["updates"]["last_check"] = time.time()
            
            # Update UI
            GLib.idle_add(self.update_check_row, 
                          self.updates_row, 
                          message, 
                          icon)
            
        except Exception as e:
            print(f"Error checking updates: {e}")
            self.security_checks["updates"]["status"] = "warning"
            GLib.idle_add(self.update_check_row, 
                          self.updates_row, 
                          "Could not check for updates", 
                          "dialog-warning-symbolic")
    
    def check_antivirus(self):
        """Check antivirus status"""
        try:
            # Check if ClamAV is installed and running
            result = subprocess.run(
                ["systemctl", "status", "clamav-freshclam"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            if "Active: active" in result.stdout:
                status = "good"
                message = "Antivirus is active and up to date"
                icon = "security-high-symbolic"
            else:
                status = "warning"
                message = "Antivirus service is not running"
                icon = "security-medium-symbolic"
            
            self.security_checks["antivirus"]["status"] = status
            self.security_checks["antivirus"]["last_check"] = time.time()
            
            # Update UI
            GLib.idle_add(self.update_check_row, 
                          self.antivirus_row, 
                          message, 
                          icon)
            
        except Exception as e:
            print(f"Error checking antivirus: {e}")
            self.security_checks["antivirus"]["status"] = "warning"
            GLib.idle_add(self.update_check_row, 
                          self.antivirus_row, 
                          "Could not determine antivirus status", 
                          "dialog-warning-symbolic")
    
    def check_permissions(self):
        """Check system file permissions"""
        try:
            # Check for world-writable files in sensitive directories
            # This is a simplified check; a real implementation would be more comprehensive
            
            # Check /etc for world-writable files
            result = subprocess.run(
                ["find", "/etc", "-type", "f", "-perm", "-o=w", "-ls"],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.stdout.strip():
                status = "critical"
                message = "Insecure file permissions detected"
                icon = "security-low-symbolic"
            else:
                status = "good"
                message = "File permissions appear secure"
                icon = "security-high-symbolic"
            
            self.security_checks["permissions"]["status"] = status
            self.security_checks["permissions"]["last_check"] = time.time()
            
            # Update UI
            GLib.idle_add(self.update_check_row, 
                          self.permissions_row, 
                          message, 
                          icon)
            
        except Exception as e:
            print(f"Error checking permissions: {e}")
            self.security_checks["permissions"]["status"] = "warning"
            GLib.idle_add(self.update_check_row, 
                          self.permissions_row, 
                          "Could not check file permissions", 
                          "dialog-warning-symbolic")
    
    def check_rootkit(self):
        """Check for rootkits"""
        try:
            # Check if rkhunter is installed and run a basic check
            # This is simulated; a real implementation would run actual checks
            
            # Simulate results
            if os.path.exists("/usr/bin/rkhunter"):
                status = "good"
                message = "No rootkits detected"
                icon = "security-high-symbolic"
            else:
                status = "warning"
                message = "Rootkit scanner not installed"
                icon = "security-medium-symbolic"
            
            self.security_checks["rootkit"]["status"] = status
            self.security_checks["rootkit"]["last_check"] = time.time()
            
            # Update UI
            GLib.idle_add(self.update_check_row, 
                          self.rootkit_row, 
                          message, 
                          icon)
            
        except Exception as e:
            print(f"Error checking for rootkits: {e}")
            self.security_checks["rootkit"]["status"] = "warning"
            GLib.idle_add(self.update_check_row, 
                          self.rootkit_row, 
                          "Could not perform rootkit check", 
                          "dialog-warning-symbolic")
    
    def calculate_overall_status(self):
        """Calculate overall security status based on individual checks"""
        # Count issues by severity
        critical_count = 0
        warning_count = 0
        
        for check in self.security_checks.values():
            if check["status"] == "critical":
                critical_count += 1
            elif check["status"] == "warning":
                warning_count += 1
        
        # Determine overall status
        if critical_count > 0:
            overall_status = "critical"
            description = f"Your system has {critical_count} critical security issues that need attention."
        elif warning_count > 0:
            overall_status = "warning"
            description = f"Your system has {warning_count} security warnings that should be addressed."
        else:
            overall_status = "good"
            description = "Your system is currently protected and up to date."
        
        # Update UI with overall status
        status_info = self.security_statuses[overall_status]
        
        GLib.idle_add(
            self.status_icon.set_from_icon_name, 
            status_info["icon"], 
            Gtk.IconSize.DIALOG
        )
        
        GLib.idle_add(
            self.status_label.set_markup,
            f"<span size='large' weight='bold' foreground='{status_info['color']}'>{status_info['label']}</span>"
        )
        
        GLib.idle_add(
            self.status_description.set_text,
            description
        )
    
    def update_check_row(self, row, message, icon_name):
        """Update a security check row with new information"""
        row.status_label.set_text(message)
        row.icon.set_from_icon_name(icon_name, Gtk.IconSize.MENU)
        return False  # To prevent being called again
    
    def on_scan_clicked(self, button):
        """Handle scan button click"""
        # Show scanning message
        self.status_description.set_text("Scanning system security...")
        
        # Reset check rows to "checking" state
        for row in [self.firewall_row, self.updates_row, self.antivirus_row, 
                   self.permissions_row, self.rootkit_row]:
            self.update_check_row(row, "Checking...", "dialog-information-symbolic")
        
        # Run security checks in a separate thread
        threading.Thread(target=self.run_security_checks, daemon=True).start()
    
    def on_security_details(self, menuitem):
        """Show detailed security information"""
        # Create dialog
        dialog = Gtk.Dialog(
            title="Security Details",
            transient_for=self.get_toplevel(),
            flags=0,
            buttons=(Gtk.STOCK_CLOSE, Gtk.ResponseType.CLOSE)
        )
        dialog.set_default_size(500, 400)
        
        # Create content area
        content_area = dialog.get_content_area()
        content_area.set_property("margin", 15)
        
        # Create a notebook for tabs
        notebook = Gtk.Notebook()
        content_area.pack_start(notebook, True, True, 0)
        
        # Firewall Tab
        firewall_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        firewall_box.set_property("margin", 10)
        
        # Get firewall info
        firewall_info = self.get_firewall_info()
        firewall_info_label = Gtk.Label(xalign=0)
        firewall_info_label.set_markup(firewall_info)
        firewall_box.pack_start(firewall_info_label, False, False, 0)
        
        notebook.append_page(firewall_box, Gtk.Label(label="Firewall"))
        
        # Updates Tab
        updates_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        updates_box.set_property("margin", 10)
        
        # Get updates info
        updates_info = self.get_updates_info()
        updates_info_label = Gtk.Label(xalign=0)
        updates_info_label.set_markup(updates_info)
        updates_box.pack_start(updates_info_label, False, False, 0)
        
        notebook.append_page(updates_box, Gtk.Label(label="Updates"))
        
        # Antivirus Tab
        antivirus_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        antivirus_box.set_property("margin", 10)
        
        # Get antivirus info
        antivirus_info = self.get_antivirus_info()
        antivirus_info_label = Gtk.Label(xalign=0)
        antivirus_info_label.set_markup(antivirus_info)
        antivirus_box.pack_start(antivirus_info_label, False, False, 0)
        
        notebook.append_page(antivirus_box, Gtk.Label(label="Antivirus"))
        
        # System Security Tab
        system_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        system_box.set_property("margin", 10)
        
        # Get system security info
        system_info = self.get_system_security_info()
        system_info_label = Gtk.Label(xalign=0)
        system_info_label.set_markup(system_info)
        system_box.pack_start(system_info_label, False, False, 0)
        
        notebook.append_page(system_box, Gtk.Label(label="System Security"))
        
        # Show dialog
        dialog.show_all()
        dialog.run()
        dialog.destroy()
    
    def get_firewall_info(self):
        """Get detailed firewall information"""
        try:
            # Get UFW status
            result = subprocess.run(
                ["ufw", "status", "verbose"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            firewall_info = []
            firewall_info.append("<b>Firewall Status:</b>")
            
            if "Status: active" in result.stdout:
                firewall_info.append("UFW is active")
            else:
                firewall_info.append("<span foreground='red'>UFW is not active</span>")
            
            firewall_info.append("\n<b>Firewall Rules:</b>")
            
            # Extract and format firewall rules
            rules_section = False
            for line in result.stdout.split('\n'):
                if "To" in line and "Action" in line and "From" in line:
                    rules_section = True
                    continue
                
                if rules_section and line.strip():
                    firewall_info.append(line)
            
            return "\n".join(firewall_info)
        except Exception as e:
            return f"<span foreground='red'>Error getting firewall information: {e}</span>"
    
    def get_updates_info(self):
        """Get detailed system updates information"""
        try:
            # This would typically use apt-check or similar
            # Here we'll simulate the results
            
            updates_info = []
            updates_info.append("<b>System Updates Status:</b>")
            updates_info.append("Last check: 2023-07-15 14:30:22")
            updates_info.append("Available updates: 5")
            updates_info.append("Security updates: 2")
            
            updates_info.append("\n<b>Available Security Updates:</b>")
            updates_info.append("libssl1.1 (CVE-2023-1234)")
            updates_info.append("linux-image-generic (CVE-2023-5678)")
            
            updates_info.append("\n<b>Other Updates:</b>")
            updates_info.append("firefox (108.0 -> 109.0)")
            updates_info.append("gimp (2.10.30 -> 2.10.32)")
            updates_info.append("python3 (3.10.6 -> 3.10.7)")
            
            return "\n".join(updates_info)
        except Exception as e:
            return f"<span foreground='red'>Error getting updates information: {e}</span>"
    
    def get_antivirus_info(self):
        """Get detailed antivirus information"""
        try:
            # Get ClamAV status
            service_result = subprocess.run(
                ["systemctl", "status", "clamav-freshclam"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            # Get ClamAV version
            version_result = subprocess.run(
                ["clamscan", "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            antivirus_info = []
            antivirus_info.append("<b>Antivirus Status:</b>")
            
            if "Active: active" in service_result.stdout:
                antivirus_info.append("ClamAV service is running")
            else:
                antivirus_info.append("<span foreground='red'>ClamAV service is not running</span>")
            
            if version_result.stdout:
                antivirus_info.append(f"\n<b>Version Information:</b>")
                antivirus_info.append(version_result.stdout.strip())
            
            antivirus_info.append("\n<b>Database Information:</b>")
            antivirus_info.append("Last update: 2023-07-14")
            antivirus_info.append("Virus signatures: 8,742,531")
            
            antivirus_info.append("\n<b>Scan Schedule:</b>")
            antivirus_info.append("Daily scan: Enabled (02:00 AM)")
            antivirus_info.append("On-access scanning: Disabled")
            
            return "\n".join(antivirus_info)
        except Exception as e:
            return f"<span foreground='red'>Error getting antivirus information: {e}</span>"
    
    def get_system_security_info(self):
        """Get detailed system security information"""
        try:
            system_info = []
            system_info.append("<b>System Security Configuration:</b>")
            
            # Check AppArmor status
            apparmor_result = subprocess.run(
                ["aa-status"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            if "apparmor module is loaded" in apparmor_result.stdout:
                system_info.append("AppArmor: Enabled")
                
                # Extract profile information
                enforced_count = 0
                complain_count = 0
                
                for line in apparmor_result.stdout.split('\n'):
                    if "profiles are in enforce mode" in line:
                        enforced_count = line.split()[0]
                    elif "profiles are in complain mode" in line:
                        complain_count = line.split()[0]
                
                system_info.append(f"  Enforced profiles: {enforced_count}")
                system_info.append(f"  Complain profiles: {complain_count}")
            else:
                system_info.append("<span foreground='red'>AppArmor: Disabled</span>")
            
            # Check for ASLR (Address Space Layout Randomization)
            aslr_result = subprocess.run(
                ["cat", "/proc/sys/kernel/randomize_va_space"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            aslr_value = aslr_result.stdout.strip()
            if aslr_value == "2":
                system_info.append("ASLR: Fully enabled")
            elif aslr_value == "1":
                system_info.append("ASLR: Partially enabled")
            else:
                system_info.append("<span foreground='red'>ASLR: Disabled</span>")
            
            # Check for core dumps
            coredump_result = subprocess.run(
                ["cat", "/proc/sys/kernel/core_pattern"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            if "|" in coredump_result.stdout or coredump_result.stdout.strip() == "core":
                system_info.append("Core dumps: Enabled")
            else:
                system_info.append("Core dumps: Disabled")
            
            # Add SSH configuration status
            system_info.append("\n<b>SSH Configuration:</b>")
            
            # Check if SSH is running
            ssh_result = subprocess.run(
                ["systemctl", "status", "ssh"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            if "Active: active" in ssh_result.stdout:
                system_info.append("SSH Server: Running")
                
                # Check key SSH settings
                try:
                    sshd_config = []
                    with open("/etc/ssh/sshd_config", "r") as f:
                        sshd_config = f.readlines()
                    
                    root_login = "Permitted"
                    password_auth = "Enabled"
                    
                    for line in sshd_config:
                        if "PermitRootLogin" in line and not line.strip().startswith("#"):
                            if "no" in line:
                                root_login = "Disabled"
                        if "PasswordAuthentication" in line and not line.strip().startswith("#"):
                            if "no" in line:
                                password_auth = "Disabled"
                    
                    system_info.append(f"  Root login: {root_login}")
                    system_info.append(f"  Password authentication: {password_auth}")
                    
                except Exception:
                    system_info.append("  Could not read SSH configuration")
            else:
                system_info.append("SSH Server: Not running")
            
            # Add password policy information
            system_info.append("\n<b>Password Policy:</b>")
            
            try:
                if os.path.exists("/etc/security/pwquality.conf"):
                    with open("/etc/security/pwquality.conf", "r") as f:
                        pwquality = f.read()
                    
                    min_length = "8"  # Default
                    for line in pwquality.split("\n"):
                        if line.startswith("minlen ="):
                            min_length = line.split("=")[1].strip()
                    
                    system_info.append(f"Minimum password length: {min_length}")
                else:
                    system_info.append("Password quality checking not configured")
            except Exception:
                system_info.append("Could not read password policy configuration")
            
            return "\n".join(system_info)
        except Exception as e:
            return f"<span foreground='red'>Error getting system security information: {e}</span>"
