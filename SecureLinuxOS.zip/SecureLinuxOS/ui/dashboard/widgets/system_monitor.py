#!/usr/bin/env python3

"""
System Monitor Widget
Displays system resource usage and performance metrics
"""

import os
import psutil
import gi
import threading
import time
import json

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk

class SystemMonitorWidget(Gtk.Box):
    """Widget for monitoring system resources and performance"""
    
    def __init__(self):
        Gtk.Box.__init__(self, orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.set_size_request(300, 300)
        self.get_style_context().add_class("widget")
        
        # Create widget header
        self.create_header()
        
        # Create widget content
        self.create_content()
        
        # Initialize the widget with data
        self.update()
    
    def create_header(self):
        """Create the widget header"""
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        header_box.get_style_context().add_class("widget-header")
        
        # Widget title
        title_icon = Gtk.Image.new_from_icon_name("utilities-system-monitor-symbolic", Gtk.IconSize.MENU)
        title_label = Gtk.Label(label="System Monitor")
        title_label.set_markup("<b>System Monitor</b>")
        
        # Widget controls
        refresh_button = Gtk.Button.new_from_icon_name("view-refresh-symbolic", Gtk.IconSize.MENU)
        refresh_button.set_tooltip_text("Refresh")
        refresh_button.connect("clicked", self.on_refresh_clicked)
        
        options_button = Gtk.MenuButton()
        options_button.set_image(Gtk.Image.new_from_icon_name("emblem-system-symbolic", Gtk.IconSize.MENU))
        options_button.set_tooltip_text("Options")
        
        # Create options menu
        menu = Gtk.Menu()
        
        detail_item = Gtk.MenuItem(label="Show Details")
        detail_item.connect("activate", self.on_show_details)
        menu.append(detail_item)
        
        export_item = Gtk.MenuItem(label="Export Data")
        menu.append(export_item)
        
        menu.show_all()
        options_button.set_popup(menu)
        
        # Add elements to header
        header_box.pack_start(title_icon, False, False, 0)
        header_box.pack_start(title_label, False, False, 0)
        header_box.pack_end(options_button, False, False, 0)
        header_box.pack_end(refresh_button, False, False, 0)
        
        self.pack_start(header_box, False, False, 0)
    
    def create_content(self):
        """Create the widget content"""
        content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        content_box.set_property("margin", 10)
        
        # System info section
        system_info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        
        # Create hostname display
        hostname_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        hostname_label = Gtk.Label(label="Hostname:", xalign=0)
        self.hostname_value = Gtk.Label(xalign=0)
        hostname_box.pack_start(hostname_label, False, False, 0)
        hostname_box.pack_start(self.hostname_value, True, True, 0)
        
        # Create uptime display
        uptime_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        uptime_label = Gtk.Label(label="Uptime:", xalign=0)
        self.uptime_value = Gtk.Label(xalign=0)
        uptime_box.pack_start(uptime_label, False, False, 0)
        uptime_box.pack_start(self.uptime_value, True, True, 0)
        
        # Add system info to its container
        system_info_box.pack_start(hostname_box, False, False, 0)
        system_info_box.pack_start(uptime_box, False, False, 0)
        
        # Create CPU usage display
        cpu_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        cpu_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        cpu_label = Gtk.Label(label="CPU Usage:", xalign=0)
        self.cpu_value = Gtk.Label(xalign=0)
        cpu_header.pack_start(cpu_label, False, False, 0)
        cpu_header.pack_start(self.cpu_value, True, True, 0)
        
        # CPU usage progress bar
        self.cpu_progress = Gtk.ProgressBar()
        self.cpu_progress.set_size_request(-1, 10)
        
        cpu_box.pack_start(cpu_header, False, False, 0)
        cpu_box.pack_start(self.cpu_progress, False, False, 0)
        
        # Create memory usage display
        memory_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        memory_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        memory_label = Gtk.Label(label="Memory Usage:", xalign=0)
        self.memory_value = Gtk.Label(xalign=0)
        memory_header.pack_start(memory_label, False, False, 0)
        memory_header.pack_start(self.memory_value, True, True, 0)
        
        # Memory usage progress bar
        self.memory_progress = Gtk.ProgressBar()
        self.memory_progress.set_size_request(-1, 10)
        
        memory_box.pack_start(memory_header, False, False, 0)
        memory_box.pack_start(self.memory_progress, False, False, 0)
        
        # Create disk usage display
        disk_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        disk_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        disk_label = Gtk.Label(label="Disk Usage:", xalign=0)
        self.disk_value = Gtk.Label(xalign=0)
        disk_header.pack_start(disk_label, False, False, 0)
        disk_header.pack_start(self.disk_value, True, True, 0)
        
        # Disk usage progress bar
        self.disk_progress = Gtk.ProgressBar()
        self.disk_progress.set_size_request(-1, 10)
        
        disk_box.pack_start(disk_header, False, False, 0)
        disk_box.pack_start(self.disk_progress, False, False, 0)
        
        # Create processes display
        processes_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        processes_label = Gtk.Label(label="Processes:", xalign=0)
        self.processes_value = Gtk.Label(xalign=0)
        processes_box.pack_start(processes_label, False, False, 0)
        processes_box.pack_start(self.processes_value, True, True, 0)
        
        # Add resource usage to content box
        content_box.pack_start(system_info_box, False, False, 0)
        content_box.pack_start(Gtk.Separator(), False, False, 0)
        content_box.pack_start(cpu_box, False, False, 0)
        content_box.pack_start(memory_box, False, False, 0)
        content_box.pack_start(disk_box, False, False, 0)
        content_box.pack_start(Gtk.Separator(), False, False, 0)
        content_box.pack_start(processes_box, False, False, 0)
        
        self.pack_start(content_box, True, True, 0)
    
    def update(self):
        """Update widget with current system data"""
        try:
            # Get system info
            hostname = os.uname().nodename
            uptime = self.get_uptime()
            
            # Get CPU usage
            cpu_percent = psutil.cpu_percent()
            
            # Get memory usage
            memory = psutil.virtual_memory()
            memory_used = memory.used / (1024 * 1024 * 1024)  # Convert to GB
            memory_total = memory.total / (1024 * 1024 * 1024)  # Convert to GB
            memory_percent = memory.percent
            
            # Get disk usage
            disk = psutil.disk_usage('/')
            disk_used = disk.used / (1024 * 1024 * 1024)  # Convert to GB
            disk_total = disk.total / (1024 * 1024 * 1024)  # Convert to GB
            disk_percent = disk.percent
            
            # Get process count
            process_count = len(psutil.pids())
            
            # Update UI with new values
            GLib.idle_add(self.update_ui, {
                'hostname': hostname,
                'uptime': uptime,
                'cpu_percent': cpu_percent,
                'memory_used': memory_used,
                'memory_total': memory_total,
                'memory_percent': memory_percent,
                'disk_used': disk_used,
                'disk_total': disk_total,
                'disk_percent': disk_percent,
                'process_count': process_count
            })
            
        except Exception as e:
            print(f"Error updating system monitor: {e}")
    
    def update_ui(self, data):
        """Update UI elements with system data"""
        # Update system info
        self.hostname_value.set_text(data['hostname'])
        self.uptime_value.set_text(data['uptime'])
        
        # Update CPU usage
        cpu_text = f"{data['cpu_percent']:.1f}%"
        self.cpu_value.set_text(cpu_text)
        self.cpu_progress.set_fraction(data['cpu_percent'] / 100.0)
        self.set_progress_color(self.cpu_progress, data['cpu_percent'])
        
        # Update memory usage
        memory_text = f"{data['memory_used']:.1f} GB / {data['memory_total']:.1f} GB ({data['memory_percent']:.1f}%)"
        self.memory_value.set_text(memory_text)
        self.memory_progress.set_fraction(data['memory_percent'] / 100.0)
        self.set_progress_color(self.memory_progress, data['memory_percent'])
        
        # Update disk usage
        disk_text = f"{data['disk_used']:.1f} GB / {data['disk_total']:.1f} GB ({data['disk_percent']:.1f}%)"
        self.disk_value.set_text(disk_text)
        self.disk_progress.set_fraction(data['disk_percent'] / 100.0)
        self.set_progress_color(self.disk_progress, data['disk_percent'])
        
        # Update processes
        self.processes_value.set_text(str(data['process_count']))
        
        return False  # To prevent being called again
    
    def get_uptime(self):
        """Get system uptime in a readable format"""
        try:
            # Get uptime in seconds
            uptime_seconds = int(time.time() - psutil.boot_time())
            
            # Convert to days, hours, minutes, seconds
            days, remainder = divmod(uptime_seconds, 86400)
            hours, remainder = divmod(remainder, 3600)
            minutes, seconds = divmod(remainder, 60)
            
            # Format uptime string
            if days > 0:
                return f"{days}d {hours}h {minutes}m"
            elif hours > 0:
                return f"{hours}h {minutes}m"
            else:
                return f"{minutes}m {seconds}s"
                
        except Exception as e:
            print(f"Error getting uptime: {e}")
            return "Unknown"
    
    def set_progress_color(self, progress_bar, value):
        """Set progress bar color based on value"""
        context = progress_bar.get_style_context()
        
        # Remove existing classes
        context.remove_class("low-usage")
        context.remove_class("medium-usage")
        context.remove_class("high-usage")
        
        # Apply appropriate class
        if value < 60:
            css = b"""
            .low-usage progress {
                background-color: #4CAF50;
            }
            """
            context.add_class("low-usage")
        elif value < 85:
            css = b"""
            .medium-usage progress {
                background-color: #FFC107;
            }
            """
            context.add_class("medium-usage")
        else:
            css = b"""
            .high-usage progress {
                background-color: #F44336;
            }
            """
            context.add_class("high-usage")
        
        # Apply CSS
        css_provider = Gtk.CssProvider()
        css_provider.load_from_data(css)
        context.add_provider(css_provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    
    def on_refresh_clicked(self, button):
        """Handle refresh button click"""
        threading.Thread(target=self.update, daemon=True).start()
    
    def on_show_details(self, menuitem):
        """Show detailed system information"""
        # Create dialog
        dialog = Gtk.Dialog(
            title="System Details",
            transient_for=self.get_toplevel(),
            flags=0,
            buttons=(Gtk.STOCK_CLOSE, Gtk.ResponseType.CLOSE)
        )
        dialog.set_default_size(500, 400)
        
        # Create content area
        content_area = dialog.get_content_area()
        content_area.set_property("margin", 15)
        
        # Create a notebook for tabs
        notebook = Gtk.Notebook()
        content_area.pack_start(notebook, True, True, 0)
        
        # CPU Tab
        cpu_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        cpu_box.set_property("margin", 10)
        
        # CPU info
        cpu_info = self.get_cpu_info()
        cpu_info_label = Gtk.Label(xalign=0)
        cpu_info_label.set_markup(cpu_info)
        cpu_box.pack_start(cpu_info_label, False, False, 0)
        
        notebook.append_page(cpu_box, Gtk.Label(label="CPU"))
        
        # Memory Tab
        memory_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        memory_box.set_property("margin", 10)
        
        # Memory info
        memory_info = self.get_memory_info()
        memory_info_label = Gtk.Label(xalign=0)
        memory_info_label.set_markup(memory_info)
        memory_box.pack_start(memory_info_label, False, False, 0)
        
        notebook.append_page(memory_box, Gtk.Label(label="Memory"))
        
        # Disk Tab
        disk_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        disk_box.set_property("margin", 10)
        
        # Disk info
        disk_info = self.get_disk_info()
        disk_info_label = Gtk.Label(xalign=0)
        disk_info_label.set_markup(disk_info)
        disk_box.pack_start(disk_info_label, False, False, 0)
        
        notebook.append_page(disk_box, Gtk.Label(label="Disk"))
        
        # Process Tab
        process_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        process_box.set_property("margin", 10)
        
        # Create scrolled window for process list
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        
        # Process list
        process_store = Gtk.ListStore(str, str, str, str)
        process_view = Gtk.TreeView(model=process_store)
        
        # Add columns
        for i, title in enumerate(["PID", "Name", "CPU %", "Memory %"]):
            renderer = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn(title, renderer, text=i)
            column.set_sort_column_id(i)
            process_view.append_column(column)
        
        # Add process data
        self.populate_process_list(process_store)
        
        scrolled.add(process_view)
        process_box.pack_start(scrolled, True, True, 0)
        
        notebook.append_page(process_box, Gtk.Label(label="Processes"))
        
        # Show dialog
        dialog.show_all()
        dialog.run()
        dialog.destroy()
    
    def get_cpu_info(self):
        """Get detailed CPU information"""
        # Get CPU information
        cpu_info = []
        cpu_info.append(f"<b>Physical cores:</b> {psutil.cpu_count(logical=False)}")
        cpu_info.append(f"<b>Logical cores:</b> {psutil.cpu_count(logical=True)}")
        
        try:
            # Try to get CPU frequency
            freq = psutil.cpu_freq()
            if freq:
                cpu_info.append(f"<b>Current frequency:</b> {freq.current:.2f} MHz")
                cpu_info.append(f"<b>Max frequency:</b> {freq.max:.2f} MHz")
        except:
            pass
        
        # Get CPU usage per core
        cpu_info.append("<b>CPU Usage Per Core:</b>")
        for i, percentage in enumerate(psutil.cpu_percent(percpu=True, interval=0.1)):
            cpu_info.append(f"  Core {i}: {percentage:.1f}%")
        
        return "\n".join(cpu_info)
    
    def get_memory_info(self):
        """Get detailed memory information"""
        # Get memory information
        memory = psutil.virtual_memory()
        swap = psutil.swap_memory()
        
        memory_info = []
        memory_info.append(f"<b>Total memory:</b> {memory.total / (1024**3):.2f} GB")
        memory_info.append(f"<b>Available memory:</b> {memory.available / (1024**3):.2f} GB")
        memory_info.append(f"<b>Used memory:</b> {memory.used / (1024**3):.2f} GB ({memory.percent}%)")
        memory_info.append(f"<b>Free memory:</b> {memory.free / (1024**3):.2f} GB")
        
        memory_info.append(f"\n<b>Total swap:</b> {swap.total / (1024**3):.2f} GB")
        memory_info.append(f"<b>Used swap:</b> {swap.used / (1024**3):.2f} GB ({swap.percent}%)")
        memory_info.append(f"<b>Free swap:</b> {swap.free / (1024**3):.2f} GB")
        
        return "\n".join(memory_info)
    
    def get_disk_info(self):
        """Get detailed disk information"""
        # Get disk information
        disk_info = []
        
        # Iterate through all disk partitions
        for partition in psutil.disk_partitions():
            if os.name == 'nt' and 'cdrom' in partition.opts:
                # Skip CD-ROM drives on Windows
                continue
            
            try:
                usage = psutil.disk_usage(partition.mountpoint)
                disk_info.append(f"<b>Device:</b> {partition.device}")
                disk_info.append(f"<b>Mountpoint:</b> {partition.mountpoint}")
                disk_info.append(f"<b>Filesystem type:</b> {partition.fstype}")
                disk_info.append(f"<b>Total size:</b> {usage.total / (1024**3):.2f} GB")
                disk_info.append(f"<b>Used:</b> {usage.used / (1024**3):.2f} GB ({usage.percent}%)")
                disk_info.append(f"<b>Free:</b> {usage.free / (1024**3):.2f} GB")
                disk_info.append("") # Empty line between partitions
            except Exception:
                # Some drives may not be ready or accessible
                continue
        
        return "\n".join(disk_info)
    
    def populate_process_list(self, store):
        """Populate the process list with current processes"""
        # Clear existing data
        store.clear()
        
        # Get process information
        for proc in sorted(
            psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']), 
            key=lambda p: p.info['cpu_percent'], 
            reverse=True
        )[:50]:  # Show top 50 CPU consumers
            try:
                store.append([
                    str(proc.info['pid']),
                    proc.info['name'],
                    f"{proc.info['cpu_percent']:.1f}",
                    f"{proc.info['memory_percent']:.1f}"
                ])
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass
