#!/usr/bin/env python3

"""
ÆOS Dashboard - Console Version
A text-based dashboard for system monitoring and security management
"""

import os
import sys
import time
import datetime
import platform
import psutil
import socket
import signal

# ANSI Color codes
class Colors:
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"
    BLACK = "\033[30m"
    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_YELLOW = "\033[43m"
    BG_BLUE = "\033[44m"
    BG_MAGENTA = "\033[45m"
    BG_CYAN = "\033[46m"
    BG_WHITE = "\033[47m"
    BG_BLACK = "\033[40m"
    BOLD = "\033[1m"
    UNDERLINE = "\033[4m"
    RESET = "\033[0m"

def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

def get_terminal_size():
    """Get the terminal size"""
    try:
        return os.get_terminal_size()
    except OSError:
        return 80, 24  # Default fallback

def create_box(title, content, width):
    """Create a box with a title and content"""
    # Prepare the box
    horizontal_line = "+" + "-" * (width - 2) + "+"
    title_line = "| " + title.center(width - 4) + " |"
    content_lines = []
    
    # Split content into lines and add padding
    for line in content.split('\n'):
        if len(line) > width - 4:
            # Truncate line if it's too long
            content_lines.append("| " + line[:width - 7] + "... |")
        else:
            content_lines.append("| " + line.ljust(width - 4) + " |")
    
    # Combine the box parts
    box = [horizontal_line, title_line, horizontal_line]
    box.extend(content_lines)
    box.append(horizontal_line)
    
    return '\n'.join(box)

def get_system_info():
    """Get system information"""
    hostname = platform.node()
    os_info = f"{platform.system()} {platform.release()}"
    
    # Get uptime
    boot_time = psutil.boot_time()
    uptime_seconds = int(time.time() - boot_time)
    days, remainder = divmod(uptime_seconds, 86400)
    hours, remainder = divmod(remainder, 3600)
    minutes, seconds = divmod(remainder, 60)
    
    if days > 0:
        uptime = f"{days}d {hours}h {minutes}m"
    elif hours > 0:
        uptime = f"{hours}h {minutes}m"
    else:
        uptime = f"{minutes}m {seconds}s"
    
    # Format the output
    info = f"Hostname: {hostname}\n"
    info += f"OS: {os_info}\n"
    info += f"Uptime: {uptime}\n"
    info += f"User: {os.environ.get('USER', 'unknown')}"
    
    return info

def get_resource_usage():
    """Get system resource usage"""
    # CPU usage
    cpu_percent = psutil.cpu_percent(interval=1)
    cpu_count = psutil.cpu_count()
    
    # Memory usage
    memory = psutil.virtual_memory()
    mem_total = memory.total / (1024 * 1024 * 1024)  # GB
    mem_used = memory.used / (1024 * 1024 * 1024)    # GB
    mem_percent = memory.percent
    
    # Disk usage
    disk = psutil.disk_usage('/')
    disk_total = disk.total / (1024 * 1024 * 1024)   # GB
    disk_used = disk.used / (1024 * 1024 * 1024)     # GB
    disk_percent = disk.percent
    
    # Progress bars (width 20)
    def create_progress_bar(percent, width=20):
        filled = int(width * percent / 100)
        bar = "[" + "█" * filled + "░" * (width - filled) + "]"
        
        # Add color based on value
        if percent < 60:
            return f"{Colors.GREEN}{bar}{Colors.RESET}"
        elif percent < 85:
            return f"{Colors.YELLOW}{bar}{Colors.RESET}"
        else:
            return f"{Colors.RED}{bar}{Colors.RESET}"
    
    # Format the output
    info = f"CPU Usage: {cpu_percent:.1f}% ({cpu_count} cores)\n"
    info += f"{create_progress_bar(cpu_percent)}\n\n"
    
    info += f"Memory: {mem_used:.1f}GB / {mem_total:.1f}GB ({mem_percent:.1f}%)\n"
    info += f"{create_progress_bar(mem_percent)}\n\n"
    
    info += f"Disk: {disk_used:.1f}GB / {disk_total:.1f}GB ({disk_percent:.1f}%)\n"
    info += f"{create_progress_bar(disk_percent)}"
    
    return info

def get_network_info():
    """Get network information"""
    # Get network interfaces
    interfaces = psutil.net_if_addrs()
    stats = psutil.net_if_stats()
    io_counters = psutil.net_io_counters(pernic=True)
    
    # Format the output
    info = ""
    
    for iface, addrs in interfaces.items():
        if iface == 'lo':  # Skip loopback
            continue
            
        # Interface status
        status = "Up" if stats[iface].isup else "Down"
        speed = f"{stats[iface].speed} Mbps" if stats[iface].speed > 0 else "Unknown"
        
        # IP and MAC addresses
        ip_addr = "Not available"
        mac_addr = "Not available"
        
        for addr in addrs:
            if addr.family == socket.AF_INET:
                ip_addr = addr.address
            elif addr.family == 17:  # AF_LINK (not always available in psutil)
                mac_addr = addr.address
        
        # Traffic data
        if iface in io_counters:
            sent = io_counters[iface].bytes_sent
            recv = io_counters[iface].bytes_recv
            
            # Format bytes
            def format_bytes(bytes_val):
                if bytes_val < 1024:
                    return f"{bytes_val:.1f} B"
                elif bytes_val < 1024 * 1024:
                    return f"{bytes_val / 1024:.1f} KB"
                elif bytes_val < 1024 * 1024 * 1024:
                    return f"{bytes_val / (1024 * 1024):.1f} MB"
                else:
                    return f"{bytes_val / (1024 * 1024 * 1024):.1f} GB"
            
            sent_str = format_bytes(sent)
            recv_str = format_bytes(recv)
        else:
            sent_str = "N/A"
            recv_str = "N/A"
        
        info += f"{iface} ({status}, {speed}):\n"
        info += f"  IP: {ip_addr}\n"
        info += f"  MAC: {mac_addr}\n"
        info += f"  Sent: {sent_str}, Received: {recv_str}\n\n"
    
    # Remove last newlines
    if info:
        info = info.rstrip('\n')
    else:
        info = "No network interfaces available"
        
    return info

def get_security_status():
    """Get system security status (simulated)"""
    # Simulated security checks
    firewall_status = "Active"
    updates_status = "5 updates available (2 security updates)"
    antivirus_status = "Not detected"
    permissions_status = "No issues detected"
    rootkit_status = "Scanner not installed"
    
    # Determine overall status
    if "not" in antivirus_status.lower() or "not" in rootkit_status.lower():
        overall_status = f"{Colors.YELLOW}Issues Detected{Colors.RESET}"
        recommendations = [
            "Install antivirus protection",
            "Install rootkit scanner",
            "Install available updates"
        ]
    else:
        overall_status = f"{Colors.GREEN}Protected{Colors.RESET}"
        recommendations = ["System is secure"]
    
    # Format the output
    info = f"Overall Status: {overall_status}\n\n"
    info += f"Firewall: {Colors.GREEN}{firewall_status}{Colors.RESET}\n"
    info += f"Updates: {Colors.YELLOW}{updates_status}{Colors.RESET}\n"
    info += f"Antivirus: {Colors.YELLOW}{antivirus_status}{Colors.RESET}\n"
    info += f"Permissions: {Colors.GREEN}{permissions_status}{Colors.RESET}\n"
    info += f"Rootkit: {Colors.YELLOW}{rootkit_status}{Colors.RESET}\n\n"
    
    info += "Recommendations:\n"
    for i, rec in enumerate(recommendations, 1):
        info += f"  {i}. {rec}\n"
    
    return info

def get_process_info():
    """Get process information"""
    # Get process information
    processes = []
    for proc in psutil.process_iter(['pid', 'name', 'username', 'cpu_percent', 'memory_percent']):
        try:
            pinfo = proc.info
            processes.append(pinfo)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    
    # Sort by CPU usage
    processes.sort(key=lambda p: p['cpu_percent'], reverse=True)
    
    # Take top 10
    processes = processes[:10]
    
    # Format the output
    info = f"{'PID':<7} {'CPU%':<8} {'MEM%':<8} {'USER':<15} {'NAME'}\n"
    info += "-" * 60 + "\n"
    
    for proc in processes:
        pid = proc['pid']
        cpu = proc['cpu_percent']
        mem = proc['memory_percent']
        user = proc['username'][:14] if proc['username'] else "N/A"
        name = proc['name']
        
        # Add color based on CPU usage
        if cpu > 20:
            cpu_str = f"{Colors.RED}{cpu:6.1f}%{Colors.RESET}"
        elif cpu > 5:
            cpu_str = f"{Colors.YELLOW}{cpu:6.1f}%{Colors.RESET}"
        else:
            cpu_str = f"{cpu:6.1f}%"
        
        # Add color based on memory usage
        if mem > 20:
            mem_str = f"{Colors.RED}{mem:6.1f}%{Colors.RESET}"
        elif mem > 5:
            mem_str = f"{Colors.YELLOW}{mem:6.1f}%{Colors.RESET}"
        else:
            mem_str = f"{mem:6.1f}%"
        
        info += f"{pid:<7} {cpu_str:<8} {mem_str:<8} {user:<15} {name}\n"
    
    return info

def display_dashboard():
    """Display the main dashboard"""
    # Get terminal size
    terminal_width, terminal_height = get_terminal_size()
    
    # Calculate box width based on terminal width
    box_width = min(terminal_width - 2, 80)
    
    # Create title
    title = f"{Colors.BOLD}{Colors.RED}Æ{Colors.WHITE}OS Dashboard{Colors.RESET}"
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Create header
    header = f"{title.center(box_width)}\n"
    header += f"{timestamp.center(box_width)}\n"
    header += "=" * box_width
    
    # Get dashboard data
    sys_info = get_system_info()
    resource_usage = get_resource_usage()
    network_info = get_network_info()
    security_status = get_security_status()
    process_info = get_process_info()
    
    # Create boxes
    sys_info_box = create_box(f"{Colors.CYAN}System Information{Colors.RESET}", sys_info, box_width)
    resource_box = create_box(f"{Colors.MAGENTA}Resource Usage{Colors.RESET}", resource_usage, box_width)
    network_box = create_box(f"{Colors.BLUE}Network Status{Colors.RESET}", network_info, box_width)
    security_box = create_box(f"{Colors.RED}Security Status{Colors.RESET}", security_status, box_width)
    process_box = create_box(f"{Colors.GREEN}Top Processes{Colors.RESET}", process_info, box_width)
    
    # Build the dashboard
    dashboard = f"{header}\n\n"
    dashboard += f"{sys_info_box}\n\n"
    dashboard += f"{resource_box}\n\n"
    dashboard += f"{network_box}\n\n"
    dashboard += f"{security_box}\n\n"
    dashboard += f"{process_box}\n\n"
    
    # Add footer
    footer = f"{Colors.BOLD}Press Ctrl+C to exit{Colors.RESET}"
    dashboard += footer.center(box_width)
    
    return dashboard

def main():
    """Main application entry point"""
    # Enable Ctrl+C to quit
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    
    try:
        while True:
            # Clear screen and display dashboard
            clear_screen()
            dashboard = display_dashboard()
            print(dashboard)
            
            # Wait 5 seconds before refreshing
            time.sleep(5)
    except KeyboardInterrupt:
        print("\nExiting ÆOS Dashboard...")
        sys.exit(0)

if __name__ == "__main__":
    main()