#!/usr/bin/env python3

"""
ÆOS Dashboard
A modern, customizable dashboard for system monitoring and security management
PyQt5 implementation
"""

import os
import sys
import json
import time
import datetime
import signal
import psutil
import platform
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                           QLabel, QPushButton, QFrame, QProgressBar, QSplitter, 
                           QTabWidget, QScrollArea, QGridLayout, QComboBox, QTreeWidget, 
                           QTreeWidgetItem, QMenu, QAction, QStatusBar, QMessageBox)
from PyQt5.QtGui import QIcon, QColor, QPalette, QFont, QPixmap
from PyQt5.QtCore import Qt, QTimer, QSize, QThread, pyqtSignal, QProcess

# Global styles
DARK_BLUE = "#1A1A2E"
MEDIUM_BLUE = "#16213E"
LIGHT_BLUE = "#0F3460"
ACCENT_RED = "#E94560"
TEXT_WHITE = "#F5F5F5"
TEXT_GRAY = "#AAAAAA"
GOOD_GREEN = "#4CAF50" 
WARNING_YELLOW = "#FFC107"
ERROR_RED = "#F44336"

class SystemMonitorWidget(QWidget):
    """Widget for monitoring system resources and performance"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(300, 300)
        self.setObjectName("widget")
        self.setStyleSheet("#widget { background-color: %s; border-radius: 8px; }" % MEDIUM_BLUE)
        
        # Main layout
        self.layout = QVBoxLayout(self)
        
        # Create widget header
        self.create_header()
        
        # Create widget content
        self.create_content()
        
        # Initialize the widget with data
        self.update_data()
        
        # Set up refresh timer
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_data)
        self.timer.start(5000)  # Update every 5 seconds
    
    def create_header(self):
        """Create the widget header"""
        header_frame = QFrame(self)
        header_frame.setStyleSheet("border-bottom: 1px solid %s; margin-bottom: 10px;" % LIGHT_BLUE)
        header_layout = QHBoxLayout(header_frame)
        
        # Widget title
        title_label = QLabel("System Monitor")
        title_label.setStyleSheet("font-weight: bold; color: %s;" % TEXT_WHITE)
        
        # Widget controls
        refresh_button = QPushButton("Refresh")
        refresh_button.setStyleSheet("""
            QPushButton {
                background-color: %s;
                color: %s;
                border: none;
                border-radius: 4px;
                padding: 4px 8px;
            }
            QPushButton:hover {
                background-color: %s;
            }
        """ % (LIGHT_BLUE, TEXT_WHITE, ACCENT_RED))
        refresh_button.clicked.connect(self.update_data)
        
        # Add elements to header
        header_layout.addWidget(title_label)
        header_layout.addStretch()
        header_layout.addWidget(refresh_button)
        
        self.layout.addWidget(header_frame)
    
    def create_content(self):
        """Create the widget content"""
        content_widget = QWidget(self)
        content_layout = QVBoxLayout(content_widget)
        
        # System info section
        system_info_frame = QFrame()
        system_info_layout = QVBoxLayout(system_info_frame)
        
        # Hostname
        hostname_layout = QHBoxLayout()
        hostname_label = QLabel("Hostname:")
        hostname_label.setStyleSheet("color: %s;" % TEXT_GRAY)
        self.hostname_value = QLabel()
        self.hostname_value.setStyleSheet("color: %s;" % TEXT_WHITE)
        hostname_layout.addWidget(hostname_label)
        hostname_layout.addWidget(self.hostname_value)
        hostname_layout.addStretch()
        
        # OS version
        os_layout = QHBoxLayout()
        os_label = QLabel("OS:")
        os_label.setStyleSheet("color: %s;" % TEXT_GRAY)
        self.os_value = QLabel()
        self.os_value.setStyleSheet("color: %s;" % TEXT_WHITE)
        os_layout.addWidget(os_label)
        os_layout.addWidget(self.os_value)
        os_layout.addStretch()
        
        # Uptime
        uptime_layout = QHBoxLayout()
        uptime_label = QLabel("Uptime:")
        uptime_label.setStyleSheet("color: %s;" % TEXT_GRAY)
        self.uptime_value = QLabel()
        self.uptime_value.setStyleSheet("color: %s;" % TEXT_WHITE)
        uptime_layout.addWidget(uptime_label)
        uptime_layout.addWidget(self.uptime_value)
        uptime_layout.addStretch()
        
        system_info_layout.addLayout(hostname_layout)
        system_info_layout.addLayout(os_layout)
        system_info_layout.addLayout(uptime_layout)
        
        # CPU usage
        cpu_frame = QFrame()
        cpu_layout = QVBoxLayout(cpu_frame)
        
        cpu_header = QHBoxLayout()
        cpu_label = QLabel("CPU Usage:")
        cpu_label.setStyleSheet("color: %s;" % TEXT_GRAY)
        self.cpu_value = QLabel()
        self.cpu_value.setStyleSheet("color: %s; font-weight: bold;" % TEXT_WHITE)
        cpu_header.addWidget(cpu_label)
        cpu_header.addWidget(self.cpu_value)
        cpu_header.addStretch()
        
        self.cpu_progress = QProgressBar()
        self.cpu_progress.setRange(0, 100)
        self.cpu_progress.setTextVisible(False)
        self.cpu_progress.setStyleSheet("""
            QProgressBar {
                background-color: %s;
                border-radius: 3px;
                height: 10px;
            }
            QProgressBar::chunk {
                background-color: %s;
                border-radius: 3px;
            }
        """ % (DARK_BLUE, GOOD_GREEN))
        
        cpu_layout.addLayout(cpu_header)
        cpu_layout.addWidget(self.cpu_progress)
        
        # Memory usage
        memory_frame = QFrame()
        memory_layout = QVBoxLayout(memory_frame)
        
        memory_header = QHBoxLayout()
        memory_label = QLabel("Memory Usage:")
        memory_label.setStyleSheet("color: %s;" % TEXT_GRAY)
        self.memory_value = QLabel()
        self.memory_value.setStyleSheet("color: %s; font-weight: bold;" % TEXT_WHITE)
        memory_header.addWidget(memory_label)
        memory_header.addWidget(self.memory_value)
        memory_header.addStretch()
        
        self.memory_progress = QProgressBar()
        self.memory_progress.setRange(0, 100)
        self.memory_progress.setTextVisible(False)
        self.memory_progress.setStyleSheet("""
            QProgressBar {
                background-color: %s;
                border-radius: 3px;
                height: 10px;
            }
            QProgressBar::chunk {
                background-color: %s;
                border-radius: 3px;
            }
        """ % (DARK_BLUE, GOOD_GREEN))
        
        memory_layout.addLayout(memory_header)
        memory_layout.addWidget(self.memory_progress)
        
        # Disk usage
        disk_frame = QFrame()
        disk_layout = QVBoxLayout(disk_frame)
        
        disk_header = QHBoxLayout()
        disk_label = QLabel("Disk Usage:")
        disk_label.setStyleSheet("color: %s;" % TEXT_GRAY)
        self.disk_value = QLabel()
        self.disk_value.setStyleSheet("color: %s; font-weight: bold;" % TEXT_WHITE)
        disk_header.addWidget(disk_label)
        disk_header.addWidget(self.disk_value)
        disk_header.addStretch()
        
        self.disk_progress = QProgressBar()
        self.disk_progress.setRange(0, 100)
        self.disk_progress.setTextVisible(False)
        self.disk_progress.setStyleSheet("""
            QProgressBar {
                background-color: %s;
                border-radius: 3px;
                height: 10px;
            }
            QProgressBar::chunk {
                background-color: %s;
                border-radius: 3px;
            }
        """ % (DARK_BLUE, GOOD_GREEN))
        
        disk_layout.addLayout(disk_header)
        disk_layout.addWidget(self.disk_progress)
        
        # Processes
        processes_layout = QHBoxLayout()
        processes_label = QLabel("Processes:")
        processes_label.setStyleSheet("color: %s;" % TEXT_GRAY)
        self.processes_value = QLabel()
        self.processes_value.setStyleSheet("color: %s; font-weight: bold;" % TEXT_WHITE)
        processes_layout.addWidget(processes_label)
        processes_layout.addWidget(self.processes_value)
        processes_layout.addStretch()
        
        # Add all sections to content
        content_layout.addWidget(system_info_frame)
        content_layout.addWidget(create_separator())
        content_layout.addWidget(cpu_frame)
        content_layout.addWidget(memory_frame)
        content_layout.addWidget(disk_frame)
        content_layout.addWidget(create_separator())
        content_layout.addLayout(processes_layout)
        content_layout.addStretch()
        
        self.layout.addWidget(content_widget)
    
    def update_data(self):
        """Update widget with current system data"""
        try:
            # Get system info
            self.hostname_value.setText(platform.node())
            self.os_value.setText(f"{platform.system()} {platform.release()}")
            self.uptime_value.setText(self.get_uptime())
            
            # Get CPU usage
            cpu_percent = psutil.cpu_percent()
            self.cpu_value.setText(f"{cpu_percent:.1f}%")
            self.cpu_progress.setValue(int(cpu_percent))
            self.set_progress_color(self.cpu_progress, cpu_percent)
            
            # Get memory usage
            memory = psutil.virtual_memory()
            memory_used = memory.used / (1024 * 1024 * 1024)  # Convert to GB
            memory_total = memory.total / (1024 * 1024 * 1024)  # Convert to GB
            memory_percent = memory.percent
            
            self.memory_value.setText(f"{memory_used:.1f} GB / {memory_total:.1f} GB ({memory_percent:.1f}%)")
            self.memory_progress.setValue(int(memory_percent))
            self.set_progress_color(self.memory_progress, memory_percent)
            
            # Get disk usage
            disk = psutil.disk_usage('/')
            disk_used = disk.used / (1024 * 1024 * 1024)  # Convert to GB
            disk_total = disk.total / (1024 * 1024 * 1024)  # Convert to GB
            disk_percent = disk.percent
            
            self.disk_value.setText(f"{disk_used:.1f} GB / {disk_total:.1f} GB ({disk_percent:.1f}%)")
            self.disk_progress.setValue(int(disk_percent))
            self.set_progress_color(self.disk_progress, disk_percent)
            
            # Get process count
            process_count = len(psutil.pids())
            self.processes_value.setText(str(process_count))
            
        except Exception as e:
            print(f"Error updating system monitor: {e}")
    
    def get_uptime(self):
        """Get system uptime in a readable format"""
        try:
            # Get uptime in seconds
            uptime_seconds = int(time.time() - psutil.boot_time())
            
            # Convert to days, hours, minutes, seconds
            days, remainder = divmod(uptime_seconds, 86400)
            hours, remainder = divmod(remainder, 3600)
            minutes, seconds = divmod(remainder, 60)
            
            # Format uptime string
            if days > 0:
                return f"{days}d {hours}h {minutes}m"
            elif hours > 0:
                return f"{hours}h {minutes}m"
            else:
                return f"{minutes}m {seconds}s"
                
        except Exception as e:
            print(f"Error getting uptime: {e}")
            return "Unknown"
    
    def set_progress_color(self, progress_bar, value):
        """Set progress bar color based on value"""
        style = """
            QProgressBar {
                background-color: %s;
                border-radius: 3px;
                height: 10px;
            }
            QProgressBar::chunk {
                background-color: %s;
                border-radius: 3px;
            }
        """ % (DARK_BLUE, self.get_color_for_value(value))
        
        progress_bar.setStyleSheet(style)
    
    def get_color_for_value(self, value):
        """Get color based on value threshold"""
        if value < 60:
            return GOOD_GREEN
        elif value < 85:
            return WARNING_YELLOW
        else:
            return ERROR_RED


class SecurityStatusWidget(QWidget):
    """Widget for monitoring system security status"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(300, 300)
        self.setObjectName("widget")
        self.setStyleSheet("#widget { background-color: %s; border-radius: 8px; }" % MEDIUM_BLUE)
        
        # Security status states
        self.security_statuses = {
            "good": {
                "label": "Protected",
                "color": GOOD_GREEN
            },
            "warning": {
                "label": "Issues Detected",
                "color": WARNING_YELLOW
            },
            "critical": {
                "label": "At Risk",
                "color": ERROR_RED
            }
        }
        
        # Security checks
        self.security_checks = {
            "firewall": {"status": "unknown", "last_check": 0},
            "updates": {"status": "unknown", "last_check": 0},
            "antivirus": {"status": "unknown", "last_check": 0},
            "rootkit": {"status": "unknown", "last_check": 0},
            "permissions": {"status": "unknown", "last_check": 0}
        }
        
        # Main layout
        self.layout = QVBoxLayout(self)
        
        # Create widget header
        self.create_header()
        
        # Create widget content
        self.create_content()
        
        # Initialize the widget with data
        self.update_data()
        
        # Set up refresh timer
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_data)
        self.timer.start(10000)  # Update every 10 seconds
    
    def create_header(self):
        """Create the widget header"""
        header_frame = QFrame(self)
        header_frame.setStyleSheet("border-bottom: 1px solid %s; margin-bottom: 10px;" % LIGHT_BLUE)
        header_layout = QHBoxLayout(header_frame)
        
        # Widget title
        title_label = QLabel("Security Status")
        title_label.setStyleSheet("font-weight: bold; color: %s;" % TEXT_WHITE)
        
        # Widget controls
        scan_button = QPushButton("Scan")
        scan_button.setStyleSheet("""
            QPushButton {
                background-color: %s;
                color: %s;
                border: none;
                border-radius: 4px;
                padding: 4px 8px;
            }
            QPushButton:hover {
                background-color: %s;
            }
        """ % (LIGHT_BLUE, TEXT_WHITE, ACCENT_RED))
        scan_button.clicked.connect(self.on_scan_clicked)
        
        # Add elements to header
        header_layout.addWidget(title_label)
        header_layout.addStretch()
        header_layout.addWidget(scan_button)
        
        self.layout.addWidget(header_frame)
    
    def create_content(self):
        """Create the widget content"""
        content_widget = QScrollArea(self)
        content_widget.setWidgetResizable(True)
        content_widget.setFrameShape(QFrame.NoFrame)
        
        content_inner = QWidget()
        content_layout = QVBoxLayout(content_inner)
        
        # Overall security status
        status_frame = QFrame()
        status_layout = QHBoxLayout(status_frame)
        
        # Status icon and details
        self.status_icon = QLabel()
        self.status_icon.setMinimumSize(48, 48)
        self.status_icon.setAlignment(Qt.AlignCenter)
        
        status_details = QFrame()
        status_details_layout = QVBoxLayout(status_details)
        
        self.status_label = QLabel("Protected")
        self.status_label.setStyleSheet("font-size: 16px; font-weight: bold; color: %s;" % TEXT_WHITE)
        
        self.status_description = QLabel("Your system is currently protected and up to date.")
        self.status_description.setStyleSheet("color: %s;" % TEXT_GRAY)
        self.status_description.setWordWrap(True)
        
        status_details_layout.addWidget(self.status_label)
        status_details_layout.addWidget(self.status_description)
        
        status_layout.addWidget(self.status_icon)
        status_layout.addWidget(status_details)
        
        # Create security checks list
        checks_frame = QFrame()
        checks_layout = QVBoxLayout(checks_frame)
        
        # Firewall check
        self.firewall_row = self.create_check_row("Firewall", "Checking...")
        
        # Updates check
        self.updates_row = self.create_check_row("System Updates", "Checking...")
        
        # Antivirus check
        self.antivirus_row = self.create_check_row("Antivirus", "Checking...")
        
        # Permissions check
        self.permissions_row = self.create_check_row("File Permissions", "Checking...")
        
        # Rootkit check
        self.rootkit_row = self.create_check_row("Rootkit Detection", "Checking...")
        
        checks_layout.addWidget(self.firewall_row)
        checks_layout.addWidget(self.updates_row)
        checks_layout.addWidget(self.antivirus_row)
        checks_layout.addWidget(self.permissions_row)
        checks_layout.addWidget(self.rootkit_row)
        
        # Last scan time
        self.last_scan_label = QLabel("Last scan: Never")
        self.last_scan_label.setStyleSheet("color: %s; font-style: italic;" % TEXT_GRAY)
        
        # Add all elements to content layout
        content_layout.addWidget(status_frame)
        content_layout.addWidget(create_separator())
        content_layout.addWidget(checks_frame)
        content_layout.addWidget(self.last_scan_label)
        content_layout.addStretch()
        
        content_widget.setWidget(content_inner)
        self.layout.addWidget(content_widget)
    
    def create_check_row(self, title, status):
        """Create a row for a security check"""
        row = QFrame()
        row_layout = QHBoxLayout(row)
        
        # Status icon
        icon = QLabel()
        icon.setMinimumSize(20, 20)
        icon.setAlignment(Qt.AlignCenter)
        
        # Check details
        details = QFrame()
        details_layout = QVBoxLayout(details)
        details_layout.setContentsMargins(0, 5, 0, 5)
        
        title_label = QLabel(title)
        title_label.setStyleSheet("font-weight: bold; color: %s;" % TEXT_WHITE)
        
        status_label = QLabel(status)
        status_label.setStyleSheet("color: %s;" % TEXT_GRAY)
        
        details_layout.addWidget(title_label)
        details_layout.addWidget(status_label)
        
        row_layout.addWidget(icon)
        row_layout.addWidget(details, 1)
        
        # Store references for updating
        row.icon = icon
        row.status_label = status_label
        
        return row
    
    def update_data(self):
        """Update widget with current security data"""
        # Simulate security checks (in a real environment, these would be actual checks)
        self.simulate_security_checks()
        
        # Update overall security status
        self.calculate_overall_status()
        
        # Update last scan time
        current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.last_scan_label.setText(f"Last scan: {current_time}")
    
    def simulate_security_checks(self):
        """Simulate security checks for demo purposes"""
        # Firewall check
        firewall_status = "good"
        firewall_message = "Firewall is active and configured"
        self.security_checks["firewall"]["status"] = firewall_status
        self.update_check_row(self.firewall_row, firewall_message, firewall_status)
        
        # Updates check (random for demo)
        updates_status = "warning"
        updates_message = "5 updates available (2 security updates)"
        self.security_checks["updates"]["status"] = updates_status
        self.update_check_row(self.updates_row, updates_message, updates_status)
        
        # Antivirus check
        antivirus_status = "warning"
        antivirus_message = "Antivirus not detected"
        self.security_checks["antivirus"]["status"] = antivirus_status
        self.update_check_row(self.antivirus_row, antivirus_message, antivirus_status)
        
        # Permissions check
        permissions_status = "good"
        permissions_message = "File permissions appear secure"
        self.security_checks["permissions"]["status"] = permissions_status
        self.update_check_row(self.permissions_row, permissions_message, permissions_status)
        
        # Rootkit check
        rootkit_status = "warning"
        rootkit_message = "Rootkit scanner not installed"
        self.security_checks["rootkit"]["status"] = rootkit_status
        self.update_check_row(self.rootkit_row, rootkit_message, rootkit_status)
    
    def update_check_row(self, row, message, status):
        """Update a security check row with new information"""
        # Update status text
        row.status_label.setText(message)
        
        # Set icon based on status
        if status == "good":
            row.status_label.setStyleSheet("color: %s;" % GOOD_GREEN)
            # In a real app, you would set an actual icon here
        elif status == "warning":
            row.status_label.setStyleSheet("color: %s;" % WARNING_YELLOW)
        elif status == "critical":
            row.status_label.setStyleSheet("color: %s;" % ERROR_RED)
        else:
            row.status_label.setStyleSheet("color: %s;" % TEXT_GRAY)
    
    def calculate_overall_status(self):
        """Calculate overall security status based on individual checks"""
        if any(self.security_checks[check]["status"] == "critical" for check in self.security_checks):
            overall_status = "critical"
            description = "Your system has critical security issues that need to be addressed immediately."
        elif any(self.security_checks[check]["status"] == "warning" for check in self.security_checks):
            overall_status = "warning"
            description = "Your system has security issues that require attention."
        else:
            overall_status = "good"
            description = "Your system is currently protected and up to date."
        
        # Update overall status display
        status_info = self.security_statuses[overall_status]
        self.status_label.setText(status_info["label"])
        self.status_label.setStyleSheet("font-size: 16px; font-weight: bold; color: %s;" % status_info["color"])
        self.status_description.setText(description)
        
        # In a real app, you would set an actual icon here
    
    def on_scan_clicked(self):
        """Handle scan button click"""
        # In a real app, this would initiate a thorough security scan
        self.update_data()
        QMessageBox.information(self, "Security Scan", "Security scan completed.")


class NetworkMonitorWidget(QWidget):
    """Widget for monitoring network connections and traffic"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(600, 300)
        self.setObjectName("widget")
        self.setStyleSheet("#widget { background-color: %s; border-radius: 8px; }" % MEDIUM_BLUE)
        
        # Store network history
        self.network_history = {
            "timestamps": [],
            "bytes_sent": [],
            "bytes_recv": []
        }
        
        # Store historical network usage
        self.last_bytes_sent = 0
        self.last_bytes_recv = 0
        self.last_check_time = time.time()
        
        # Main layout
        self.layout = QVBoxLayout(self)
        
        # Create widget header
        self.create_header()
        
        # Create widget content
        self.create_content()
        
        # Initialize the widget with data
        self.update_data()
        
        # Set up refresh timer
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_data)
        self.timer.start(3000)  # Update every 3 seconds
    
    def create_header(self):
        """Create the widget header"""
        header_frame = QFrame(self)
        header_frame.setStyleSheet("border-bottom: 1px solid %s; margin-bottom: 10px;" % LIGHT_BLUE)
        header_layout = QHBoxLayout(header_frame)
        
        # Widget title
        title_label = QLabel("Network Monitor")
        title_label.setStyleSheet("font-weight: bold; color: %s;" % TEXT_WHITE)
        
        # Widget controls
        refresh_button = QPushButton("Refresh")
        refresh_button.setStyleSheet("""
            QPushButton {
                background-color: %s;
                color: %s;
                border: none;
                border-radius: 4px;
                padding: 4px 8px;
            }
            QPushButton:hover {
                background-color: %s;
            }
        """ % (LIGHT_BLUE, TEXT_WHITE, ACCENT_RED))
        refresh_button.clicked.connect(self.update_data)
        
        # Add elements to header
        header_layout.addWidget(title_label)
        header_layout.addStretch()
        header_layout.addWidget(refresh_button)
        
        self.layout.addWidget(header_frame)
    
    def create_content(self):
        """Create the widget content"""
        content_widget = QScrollArea(self)
        content_widget.setWidgetResizable(True)
        content_widget.setFrameShape(QFrame.NoFrame)
        
        content_inner = QWidget()
        content_layout = QVBoxLayout(content_inner)
        
        # Network interfaces section
        interfaces_frame = QFrame()
        interfaces_layout = QVBoxLayout(interfaces_frame)
        
        # Interface selection
        selection_layout = QHBoxLayout()
        selection_label = QLabel("Interface:")
        selection_label.setStyleSheet("color: %s;" % TEXT_GRAY)
        
        # Create interface dropdown
        self.interface_combo = QComboBox()
        self.interface_combo.setStyleSheet("""
            QComboBox {
                background-color: %s;
                color: %s;
                border: 1px solid %s;
                border-radius: 4px;
                padding: 4px;
            }
            QComboBox::drop-down {
                subcontrol-origin: padding;
                subcontrol-position: top right;
                width: 15px;
                border-left-width: 1px;
                border-left-color: %s;
                border-left-style: solid;
            }
        """ % (DARK_BLUE, TEXT_WHITE, LIGHT_BLUE, LIGHT_BLUE))
        self.populate_interfaces()
        self.interface_combo.currentIndexChanged.connect(self.update_data)
        
        selection_layout.addWidget(selection_label)
        selection_layout.addWidget(self.interface_combo, 1)
        
        # Network status
        status_grid = QGridLayout()
        
        # IP Address
        ip_label = QLabel("IP Address:")
        ip_label.setStyleSheet("color: %s;" % TEXT_GRAY)
        self.ip_value = QLabel()
        self.ip_value.setStyleSheet("color: %s;" % TEXT_WHITE)
        
        # MAC Address
        mac_label = QLabel("MAC Address:")
        mac_label.setStyleSheet("color: %s;" % TEXT_GRAY)
        self.mac_value = QLabel()
        self.mac_value.setStyleSheet("color: %s;" % TEXT_WHITE)
        
        # Status
        status_label = QLabel("Status:")
        status_label.setStyleSheet("color: %s;" % TEXT_GRAY)
        self.status_value = QLabel()
        self.status_value.setStyleSheet("color: %s;" % TEXT_WHITE)
        
        status_grid.addWidget(ip_label, 0, 0)
        status_grid.addWidget(self.ip_value, 0, 1)
        status_grid.addWidget(mac_label, 1, 0)
        status_grid.addWidget(self.mac_value, 1, 1)
        status_grid.addWidget(status_label, 2, 0)
        status_grid.addWidget(self.status_value, 2, 1)
        
        interfaces_layout.addLayout(selection_layout)
        interfaces_layout.addLayout(status_grid)
        
        # Traffic rates
        rates_frame = QFrame()
        rates_layout = QHBoxLayout(rates_frame)
        
        # Upload rate
        upload_frame = QFrame()
        upload_layout = QVBoxLayout(upload_frame)
        upload_label = QLabel("Upload")
        upload_label.setAlignment(Qt.AlignCenter)
        upload_label.setStyleSheet("color: %s;" % TEXT_GRAY)
        self.upload_value = QLabel("0 KB/s")
        self.upload_value.setAlignment(Qt.AlignCenter)
        self.upload_value.setStyleSheet("font-size: 16px; font-weight: bold; color: %s;" % TEXT_WHITE)
        upload_layout.addWidget(upload_label)
        upload_layout.addWidget(self.upload_value)
        
        # Download rate
        download_frame = QFrame()
        download_layout = QVBoxLayout(download_frame)
        download_label = QLabel("Download")
        download_label.setAlignment(Qt.AlignCenter)
        download_label.setStyleSheet("color: %s;" % TEXT_GRAY)
        self.download_value = QLabel("0 KB/s")
        self.download_value.setAlignment(Qt.AlignCenter)
        self.download_value.setStyleSheet("font-size: 16px; font-weight: bold; color: %s;" % TEXT_WHITE)
        download_layout.addWidget(download_label)
        download_layout.addWidget(self.download_value)
        
        # Total transferred
        total_frame = QFrame()
        total_layout = QVBoxLayout(total_frame)
        total_label = QLabel("Total Transferred")
        total_label.setAlignment(Qt.AlignCenter)
        total_label.setStyleSheet("color: %s;" % TEXT_GRAY)
        self.total_value = QLabel("0 MB")
        self.total_value.setAlignment(Qt.AlignCenter)
        self.total_value.setStyleSheet("font-size: 16px; font-weight: bold; color: %s;" % TEXT_WHITE)
        total_layout.addWidget(total_label)
        total_layout.addWidget(self.total_value)
        
        rates_layout.addWidget(upload_frame, 1)
        rates_layout.addWidget(download_frame, 1)
        rates_layout.addWidget(total_frame, 1)
        
        # Active connections
        connections_frame = QFrame()
        connections_layout = QVBoxLayout(connections_frame)
        
        connections_label = QLabel("Active Connections")
        connections_label.setStyleSheet("font-weight: bold; color: %s;" % TEXT_WHITE)
        
        self.connections_tree = QTreeWidget()
        self.connections_tree.setStyleSheet("""
            QTreeWidget {
                background-color: %s;
                color: %s;
                border: 1px solid %s;
                border-radius: 4px;
            }
            QHeaderView::section {
                background-color: %s;
                color: %s;
                padding: 4px;
                border: none;
            }
        """ % (DARK_BLUE, TEXT_WHITE, LIGHT_BLUE, LIGHT_BLUE, TEXT_WHITE))
        self.connections_tree.setHeaderLabels(["Process", "Local Address", "Local Port", "Remote Address", "Status"])
        self.connections_tree.setAlternatingRowColors(True)
        self.connections_tree.setSortingEnabled(True)
        
        connections_layout.addWidget(connections_label)
        connections_layout.addWidget(self.connections_tree)
        
        # Add all sections to content layout
        content_layout.addWidget(interfaces_frame)
        content_layout.addWidget(create_separator())
        content_layout.addWidget(rates_frame)
        content_layout.addWidget(create_separator())
        content_layout.addWidget(connections_frame)
        
        content_widget.setWidget(content_inner)
        self.layout.addWidget(content_widget)
    
    def populate_interfaces(self):
        """Populate network interfaces dropdown"""
        self.interface_combo.clear()
        
        # Get network interfaces
        try:
            interfaces = psutil.net_if_addrs().keys()
            
            # Add to dropdown
            for interface in interfaces:
                if interface != 'lo':  # Skip loopback
                    self.interface_combo.addItem(interface)
            
            # Select first interface
            if self.interface_combo.count() > 0:
                self.interface_combo.setCurrentIndex(0)
        except Exception as e:
            print(f"Error populating network interfaces: {e}")
    
    def update_data(self):
        """Update widget with current network data"""
        interface = self.interface_combo.currentText()
        if not interface:
            return
        
        try:
            # Get interface info
            addresses = psutil.net_if_addrs().get(interface, [])
            stats = psutil.net_if_stats().get(interface)
            
            # Get IP and MAC addresses
            ip_address = "Not available"
            mac_address = "Not available"
            
            for addr in addresses:
                if addr.family == psutil.AF_INET:
                    ip_address = addr.address
                elif addr.family == psutil.AF_LINK:
                    mac_address = addr.address
            
            # Get interface status
            if stats:
                status = "Up" if stats.isup else "Down"
                speed = f"{stats.speed} Mbps" if stats.speed > 0 else "Unknown"
                status_text = f"{status} - {speed}"
            else:
                status_text = "Unknown"
            
            # Update interface info in UI
            self.ip_value.setText(ip_address)
            self.mac_value.setText(mac_address)
            self.status_value.setText(status_text)
            
            # Get current network counters
            counters = psutil.net_io_counters(pernic=True).get(interface)
            current_time = time.time()
            
            if counters:
                # Calculate transfer rates
                time_diff = current_time - self.last_check_time
                
                if self.last_bytes_sent > 0 and self.last_bytes_recv > 0:
                    bytes_sent_rate = (counters.bytes_sent - self.last_bytes_sent) / time_diff
                    bytes_recv_rate = (counters.bytes_recv - self.last_bytes_recv) / time_diff
                else:
                    bytes_sent_rate = 0
                    bytes_recv_rate = 0
                
                # Store for next check
                self.last_bytes_sent = counters.bytes_sent
                self.last_bytes_recv = counters.bytes_recv
                self.last_check_time = current_time
                
                # Store in history
                self.network_history["timestamps"].append(datetime.datetime.now())
                self.network_history["bytes_sent"].append(bytes_sent_rate)
                self.network_history["bytes_recv"].append(bytes_recv_rate)
                
                # Keep only last 60 data points
                if len(self.network_history["timestamps"]) > 60:
                    self.network_history["timestamps"].pop(0)
                    self.network_history["bytes_sent"].pop(0)
                    self.network_history["bytes_recv"].pop(0)
                
                # Format rates for display
                upload_text = self.format_transfer_rate(bytes_sent_rate)
                download_text = self.format_transfer_rate(bytes_recv_rate)
                
                # Calculate total transferred
                total_bytes = counters.bytes_sent + counters.bytes_recv
                total_text = self.format_bytes(total_bytes)
                
                # Update UI with rates
                self.upload_value.setText(upload_text)
                self.download_value.setText(download_text)
                self.total_value.setText(total_text)
            
            # Update connections list
            self.update_connections()
            
        except Exception as e:
            print(f"Error updating network data: {e}")
    
    def update_connections(self):
        """Update the list of active network connections"""
        self.connections_tree.clear()
        
        try:
            # Get all connections
            connections = psutil.net_connections(kind='inet')
            
            # Filter and add connections to list
            for conn in connections:
                try:
                    # Only show established, listening, or close_wait connections
                    if conn.status in ['ESTABLISHED', 'LISTEN', 'CLOSE_WAIT']:
                        # Get process name
                        process_name = ""
                        if conn.pid:
                            try:
                                process = psutil.Process(conn.pid)
                                process_name = process.name()
                            except (psutil.NoSuchProcess, psutil.AccessDenied):
                                process_name = "Unknown"
                        
                        # Get local address and port
                        local_addr = conn.laddr.ip if conn.laddr else "0.0.0.0"
                        local_port = str(conn.laddr.port) if conn.laddr else ""
                        
                        # Get remote address and port
                        remote_addr = ""
                        if conn.raddr:
                            remote_addr = f"{conn.raddr.ip}:{conn.raddr.port}"
                        
                        # Add to tree
                        item = QTreeWidgetItem(self.connections_tree)
                        item.setText(0, process_name)
                        item.setText(1, local_addr)
                        item.setText(2, local_port)
                        item.setText(3, remote_addr)
                        item.setText(4, conn.status)
                except Exception as e:
                    print(f"Error processing connection: {e}")
        except Exception as e:
            print(f"Error updating connections: {e}")
    
    def format_transfer_rate(self, bytes_per_sec):
        """Format a transfer rate for display"""
        if bytes_per_sec < 1024:
            return f"{bytes_per_sec:.1f} B/s"
        elif bytes_per_sec < 1024 * 1024:
            return f"{bytes_per_sec / 1024:.1f} KB/s"
        elif bytes_per_sec < 1024 * 1024 * 1024:
            return f"{bytes_per_sec / (1024 * 1024):.1f} MB/s"
        else:
            return f"{bytes_per_sec / (1024 * 1024 * 1024):.1f} GB/s"
    
    def format_bytes(self, bytes_value):
        """Format bytes for display"""
        if bytes_value < 1024:
            return f"{bytes_value:.1f} B"
        elif bytes_value < 1024 * 1024:
            return f"{bytes_value / 1024:.1f} KB"
        elif bytes_value < 1024 * 1024 * 1024:
            return f"{bytes_value / (1024 * 1024):.1f} MB"
        elif bytes_value < 1024 * 1024 * 1024 * 1024:
            return f"{bytes_value / (1024 * 1024 * 1024):.1f} GB"
        else:
            return f"{bytes_value / (1024 * 1024 * 1024 * 1024):.1f} TB"


class AeosDashboard(QMainWindow):
    """Main dashboard window for ÆOS"""
    
    def __init__(self):
        super().__init__()
        
        # Set window properties
        self.setWindowTitle("ÆOS Dashboard")
        self.setMinimumSize(1200, 800)
        self.setStyleSheet(f"background-color: {DARK_BLUE}; color: {TEXT_WHITE};")
        
        # Set up the central widget
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        
        # Main layout
        self.main_layout = QVBoxLayout(self.central_widget)
        self.main_layout.setContentsMargins(10, 10, 10, 10)
        self.main_layout.setSpacing(10)
        
        # Create header
        self.create_header()
        
        # Create main content area
        self.content_layout = QHBoxLayout()
        self.main_layout.addLayout(self.content_layout)
        
        # Create sidebar
        self.create_sidebar()
        
        # Create dashboard content
        self.create_dashboard_content()
        
        # Create status bar
        self.create_status_bar()
        
        # Initialize timer for updates
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_widgets)
        self.timer.start(15000)  # Refresh every 15 seconds
    
    def create_header(self):
        """Create the dashboard header"""
        header = QFrame()
        header.setStyleSheet(f"background-color: {MEDIUM_BLUE}; border-radius: 8px;")
        header.setFixedHeight(60)
        
        header_layout = QHBoxLayout(header)
        
        # Logo and title
        logo_label = QLabel("Æ")
        logo_label.setStyleSheet(f"color: {ACCENT_RED}; font-size: 24px; font-weight: bold;")
        
        title_label = QLabel("OS Dashboard")
        title_label.setStyleSheet(f"color: {TEXT_WHITE}; font-size: 24px;")
        
        # System info
        info_layout = QHBoxLayout()
        info_layout.setSpacing(20)
        
        # Add user info
        user_label = QLabel(f"User: {os.environ.get('USER', 'unknown')}")
        user_label.setStyleSheet(f"color: {TEXT_GRAY};")
        
        # Add time
        self.time_label = QLabel()
        self.time_label.setStyleSheet(f"color: {TEXT_GRAY};")
        self.update_time()
        
        # Add buttons
        settings_button = QPushButton("Settings")
        settings_button.setStyleSheet(f"""
            QPushButton {{
                background-color: {LIGHT_BLUE};
                color: {TEXT_WHITE};
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
            }}
            QPushButton:hover {{
                background-color: {ACCENT_RED};
            }}
        """)
        
        logout_button = QPushButton("Logout")
        logout_button.setStyleSheet(f"""
            QPushButton {{
                background-color: {ACCENT_RED};
                color: {TEXT_WHITE};
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
            }}
            QPushButton:hover {{
                background-color: #d03b53;
            }}
        """)
        logout_button.clicked.connect(self.on_logout_clicked)
        
        # Pack everything into the header
        header_layout.addWidget(logo_label)
        header_layout.addWidget(title_label)
        header_layout.addStretch()
        
        info_layout.addWidget(user_label)
        info_layout.addWidget(self.time_label)
        info_layout.addWidget(settings_button)
        info_layout.addWidget(logout_button)
        
        header_layout.addLayout(info_layout)
        
        self.main_layout.addWidget(header)
    
    def update_time(self):
        """Update the time display in the header"""
        now = datetime.datetime.now()
        self.time_label.setText(now.strftime("%H:%M:%S"))
        return True
    
    def create_sidebar(self):
        """Create the dashboard sidebar"""
        sidebar = QFrame()
        sidebar.setStyleSheet(f"background-color: {MEDIUM_BLUE}; border-radius: 8px;")
        sidebar.setFixedWidth(200)
        
        sidebar_layout = QVBoxLayout(sidebar)
        
        # Create sidebar buttons
        dashboard_button = self.create_sidebar_button("Dashboard", True)
        security_button = self.create_sidebar_button("Security")
        tools_button = self.create_sidebar_button("Tools")
        network_button = self.create_sidebar_button("Network")
        dev_button = self.create_sidebar_button("Development")
        
        # Add separator
        separator = create_separator()
        
        # Settings button
        settings_button = self.create_sidebar_button("Settings")
        
        # Add buttons to sidebar
        sidebar_layout.addWidget(dashboard_button)
        sidebar_layout.addWidget(security_button)
        sidebar_layout.addWidget(tools_button)
        sidebar_layout.addWidget(network_button)
        sidebar_layout.addWidget(dev_button)
        sidebar_layout.addWidget(separator)
        sidebar_layout.addWidget(settings_button)
        sidebar_layout.addStretch()
        
        # Add sidebar to content layout
        self.content_layout.addWidget(sidebar)
    
    def create_sidebar_button(self, text, active=False):
        """Create a styled sidebar button"""
        button = QPushButton(text)
        button.setCheckable(True)
        button.setChecked(active)
        
        # Style based on active state
        if active:
            button.setStyleSheet(f"""
                QPushButton {{
                    background-color: {ACCENT_RED};
                    color: {TEXT_WHITE};
                    border: none;
                    border-radius: 4px;
                    padding: 10px;
                    text-align: left;
                    font-weight: bold;
                }}
                QPushButton:hover {{
                    background-color: #d03b53;
                }}
            """)
        else:
            button.setStyleSheet(f"""
                QPushButton {{
                    background-color: transparent;
                    color: {TEXT_WHITE};
                    border: none;
                    border-radius: 4px;
                    padding: 10px;
                    text-align: left;
                }}
                QPushButton:hover {{
                    background-color: {LIGHT_BLUE};
                }}
            """)
        
        button.clicked.connect(lambda: self.on_sidebar_button_clicked(button))
        return button
    
    def create_dashboard_content(self):
        """Create the main dashboard content area"""
        # Create a scrollable area for dashboard widgets
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.NoFrame)
        scroll_area.setStyleSheet(f"background-color: {DARK_BLUE};")
        
        # Create a widget to hold all dashboard widgets
        scroll_content = QWidget()
        self.widgets_layout = QVBoxLayout(scroll_content)
        
        # Create row layouts
        row1_layout = QHBoxLayout()
        row2_layout = QHBoxLayout()
        
        # Create and add widgets
        self.system_monitor = SystemMonitorWidget()
        self.security_status = SecurityStatusWidget()
        self.network_monitor = NetworkMonitorWidget()
        
        # Add widgets to rows
        row1_layout.addWidget(self.system_monitor)
        row1_layout.addWidget(self.security_status)
        
        row2_layout.addWidget(self.network_monitor)
        
        # Add rows to widgets layout
        self.widgets_layout.addLayout(row1_layout)
        self.widgets_layout.addLayout(row2_layout)
        self.widgets_layout.addStretch()
        
        # Set the widget for the scroll area
        scroll_area.setWidget(scroll_content)
        
        # Add the scroll area to the content layout
        self.content_layout.addWidget(scroll_area, 1)
    
    def create_status_bar(self):
        """Create the status bar at the bottom of the dashboard"""
        status_bar = QStatusBar()
        status_bar.setStyleSheet(f"background-color: {MEDIUM_BLUE}; color: {TEXT_GRAY};")
        
        # System status
        status_label = QLabel("System Status: Normal")
        status_bar.addWidget(status_label)
        
        # Add permanent widgets
        status_bar.addPermanentWidget(QLabel("Security: Active"))
        status_bar.addPermanentWidget(QLabel("Network: Connected"))
        status_bar.addPermanentWidget(QLabel("ÆOS v0.1.0"))
        
        self.setStatusBar(status_bar)
    
    def refresh_widgets(self):
        """Refresh all dashboard widgets"""
        self.update_time()
        # Widget updates are handled by their internal timers
    
    def on_sidebar_button_clicked(self, button):
        """Handle sidebar button clicks"""
        # Uncheck all buttons
        for widget in self.findChildren(QPushButton):
            if widget != button and widget.isCheckable():
                widget.setChecked(False)
                widget.setStyleSheet(f"""
                    QPushButton {{
                        background-color: transparent;
                        color: {TEXT_WHITE};
                        border: none;
                        border-radius: 4px;
                        padding: 10px;
                        text-align: left;
                    }}
                    QPushButton:hover {{
                        background-color: {LIGHT_BLUE};
                    }}
                """)
        
        # Check current button
        button.setChecked(True)
        button.setStyleSheet(f"""
            QPushButton {{
                background-color: {ACCENT_RED};
                color: {TEXT_WHITE};
                border: none;
                border-radius: 4px;
                padding: 10px;
                text-align: left;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: #d03b53;
            }}
        """)
    
    def on_logout_clicked(self):
        """Handle logout button click"""
        reply = QMessageBox.question(
            self, 'Logout Confirmation',
            'Are you sure you want to logout?',
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            self.close()


def create_separator():
    """Create a horizontal separator line"""
    separator = QFrame()
    separator.setFrameShape(QFrame.HLine)
    separator.setFrameShadow(QFrame.Sunken)
    separator.setStyleSheet(f"background-color: {LIGHT_BLUE}; max-height: 1px;")
    return separator


def main():
    """Main application entry point"""
    # Enable Ctrl+C to quit
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    
    # Create the application
    app = QApplication(sys.argv)
    
    # Set application-wide dark theme
    app.setStyle("Fusion")
    
    # Create dark palette
    palette = QPalette()
    palette.setColor(QPalette.Window, QColor(DARK_BLUE))
    palette.setColor(QPalette.WindowText, QColor(TEXT_WHITE))
    palette.setColor(QPalette.Base, QColor(MEDIUM_BLUE))
    palette.setColor(QPalette.AlternateBase, QColor(LIGHT_BLUE))
    palette.setColor(QPalette.ToolTipBase, QColor(TEXT_WHITE))
    palette.setColor(QPalette.ToolTipText, QColor(TEXT_WHITE))
    palette.setColor(QPalette.Text, QColor(TEXT_WHITE))
    palette.setColor(QPalette.Button, QColor(MEDIUM_BLUE))
    palette.setColor(QPalette.ButtonText, QColor(TEXT_WHITE))
    palette.setColor(QPalette.Link, QColor(ACCENT_RED))
    palette.setColor(QPalette.Highlight, QColor(ACCENT_RED))
    palette.setColor(QPalette.HighlightedText, QColor(TEXT_WHITE))
    
    # Set the dark theme
    app.setPalette(palette)
    
    # Create and show the dashboard
    dashboard = AeosDashboard()
    dashboard.show()
    
    # Start the application event loop
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()