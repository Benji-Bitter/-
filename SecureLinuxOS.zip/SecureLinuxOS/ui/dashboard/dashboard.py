#!/usr/bin/env python3

"""
CyberOS Dashboard
A modern, customizable dashboard for system monitoring and security management
"""

import os
import sys
import json
import signal
import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib, Pango

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from dashboard.widgets.system_monitor import SystemMonitorWidget
from dashboard.widgets.security_status import SecurityStatusWidget
from dashboard.widgets.network_monitor import NetworkMonitorWidget

class CyberOSDashboard(Gtk.Window):
    """Main dashboard window for CyberOS"""
    
    def __init__(self):
        Gtk.Window.__init__(self, title="CyberOS Dashboard")
        
        # Set up the window
        self.set_default_size(1200, 800)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.connect("destroy", Gtk.main_quit)
        
        # Load configuration
        self.config = self.load_config()
        
        # Apply CSS styling
        self.apply_css()
        
        # Create main container
        self.main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.add(self.main_box)
        
        # Create header bar
        self.create_header()
        
        # Create main content area
        self.content_box = Gtk.Box(spacing=10)
        self.main_box.pack_start(self.content_box, True, True, 0)
        
        # Create sidebar
        self.create_sidebar()
        
        # Create dashboard content
        self.create_dashboard_content()
        
        # Create status bar
        self.create_status_bar()
        
        # Initialize refresh timer
        GLib.timeout_add_seconds(5, self.refresh_widgets)
        
    def load_config(self):
        """Load dashboard configuration"""
        config_path = "/opt/cyberos/config/os-config.json"
        
        try:
            with open(config_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading configuration: {e}")
            return {
                "ui_configuration": {
                    "color_scheme": {
                        "primary": "#1A1A2E",
                        "secondary": "#16213E",
                        "accent": "#0F3460",
                        "highlight": "#E94560"
                    }
                },
                "dashboard_widgets": [
                    "system_monitor",
                    "security_status",
                    "network_monitor"
                ]
            }
    
    def apply_css(self):
        """Apply CSS styling to the dashboard"""
        css_provider = Gtk.CssProvider()
        css_path = "/opt/cyberos/ui/theme/dark-theme.css"
        
        try:
            css_provider.load_from_path(css_path)
            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(),
                css_provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )
        except Exception as e:
            print(f"Error loading CSS: {e}")
            # Fallback inline CSS if file not found
            css = b"""
            .dashboard-header {
                background-color: #1A1A2E;
                color: white;
                padding: 10px;
            }
            .sidebar {
                background-color: #16213E;
                color: white;
            }
            .sidebar-button {
                padding: 10px;
                border: none;
                background-color: transparent;
                color: white;
                border-radius: 0;
            }
            .sidebar-button:hover {
                background-color: #0F3460;
            }
            .sidebar-button.active {
                background-color: #E94560;
            }
            .widget {
                background-color: #16213E;
                border-radius: 5px;
                padding: 10px;
            }
            .widget-header {
                border-bottom: 1px solid #333;
                padding-bottom: 5px;
                margin-bottom: 10px;
            }
            """
            css_provider.load_from_data(css)
            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(),
                css_provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )
    
    def create_header(self):
        """Create the dashboard header"""
        header_box = Gtk.Box(spacing=10)
        header_box.get_style_context().add_class("dashboard-header")
        
        # Logo and title
        logo_label = Gtk.Label()
        logo_label.set_markup("<b>Cyber</b>OS")
        logo_label.set_property("margin", 10)
        
        # Add title
        title_label = Gtk.Label()
        title_label.set_markup("<span size='large'>Dashboard</span>")
        
        # Add system info
        info_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        info_box.set_halign(Gtk.Align.END)
        info_box.set_hexpand(True)
        
        # Add time
        self.time_label = Gtk.Label()
        GLib.timeout_add_seconds(1, self.update_time)
        self.update_time()
        
        # Add user info
        user_label = Gtk.Label()
        user_label.set_text(f"User: {os.environ.get('USER', 'unknown')}")
        
        # Add buttons
        settings_button = Gtk.Button.new_from_icon_name("preferences-system-symbolic", Gtk.IconSize.BUTTON)
        settings_button.set_tooltip_text("Settings")
        
        logout_button = Gtk.Button.new_from_icon_name("system-log-out-symbolic", Gtk.IconSize.BUTTON)
        logout_button.set_tooltip_text("Logout")
        logout_button.connect("clicked", self.on_logout_clicked)
        
        # Pack everything into the header
        header_box.pack_start(logo_label, False, False, 0)
        header_box.pack_start(title_label, False, False, 0)
        
        info_box.pack_start(user_label, False, False, 0)
        info_box.pack_start(self.time_label, False, False, 0)
        info_box.pack_start(settings_button, False, False, 0)
        info_box.pack_start(logout_button, False, False, 0)
        
        header_box.pack_end(info_box, False, False, 10)
        
        self.main_box.pack_start(header_box, False, False, 0)
    
    def update_time(self):
        """Update the time display in the header"""
        import datetime
        now = datetime.datetime.now()
        self.time_label.set_text(now.strftime("%H:%M:%S"))
        return True
    
    def create_sidebar(self):
        """Create the dashboard sidebar"""
        sidebar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        sidebar.set_size_request(200, -1)
        sidebar.get_style_context().add_class("sidebar")
        
        # Add sidebar items
        dashboard_button = self.create_sidebar_button("Dashboard", "view-grid-symbolic", True)
        security_button = self.create_sidebar_button("Security", "security-high-symbolic")
        tools_button = self.create_sidebar_button("Tools", "applications-utilities-symbolic")
        network_button = self.create_sidebar_button("Network", "network-wireless-symbolic")
        dev_button = self.create_sidebar_button("Development", "applications-engineering-symbolic")
        settings_button = self.create_sidebar_button("Settings", "preferences-system-symbolic")
        
        sidebar.pack_start(dashboard_button, False, False, 0)
        sidebar.pack_start(security_button, False, False, 0)
        sidebar.pack_start(tools_button, False, False, 0)
        sidebar.pack_start(network_button, False, False, 0)
        sidebar.pack_start(dev_button, False, False, 0)
        sidebar.pack_start(Gtk.Separator(), False, False, 10)
        sidebar.pack_start(settings_button, False, False, 0)
        
        # Add sidebar to content box
        self.content_box.pack_start(sidebar, False, False, 0)
    
    def create_sidebar_button(self, label_text, icon_name, active=False):
        """Create a styled sidebar button"""
        button = Gtk.Button()
        button.get_style_context().add_class("sidebar-button")
        if active:
            button.get_style_context().add_class("active")
        
        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        
        icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.BUTTON)
        label = Gtk.Label(label=label_text, xalign=0)
        
        hbox.pack_start(icon, False, False, 10)
        hbox.pack_start(label, True, True, 0)
        
        button.add(hbox)
        button.connect("clicked", self.on_sidebar_button_clicked)
        
        return button
    
    def create_dashboard_content(self):
        """Create the main dashboard content area"""
        # Create a container for dashboard widgets with scrolling
        self.dashboard_scrolled = Gtk.ScrolledWindow()
        self.dashboard_scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        # Create a box to hold all widgets
        self.widgets_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        self.widgets_box.set_property("margin", 15)
        
        # Create a container for widget rows
        self.row1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        self.row2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        
        # Create and add widgets
        self.system_monitor = SystemMonitorWidget()
        self.security_status = SecurityStatusWidget()
        self.network_monitor = NetworkMonitorWidget()
        
        # Add widgets to rows
        self.row1.pack_start(self.system_monitor, True, True, 0)
        self.row1.pack_start(self.security_status, True, True, 0)
        self.row2.pack_start(self.network_monitor, True, True, 0)
        
        # Add rows to widgets box
        self.widgets_box.pack_start(self.row1, False, True, 0)
        self.widgets_box.pack_start(self.row2, False, True, 0)
        
        # Add widgets box to scrolled window
        self.dashboard_scrolled.add(self.widgets_box)
        
        # Add scrolled window to content area
        self.content_box.pack_start(self.dashboard_scrolled, True, True, 0)
    
    def create_status_bar(self):
        """Create the status bar at the bottom of the dashboard"""
        status_bar = Gtk.Box(spacing=10)
        status_bar.set_property("margin", 5)
        
        # System status indicator
        status_icon = Gtk.Image.new_from_icon_name("emblem-default", Gtk.IconSize.MENU)
        status_label = Gtk.Label(label="System Status: Normal")
        
        # Security status
        security_icon = Gtk.Image.new_from_icon_name("security-high-symbolic", Gtk.IconSize.MENU)
        security_label = Gtk.Label(label="Security: Active")
        
        # Network status
        network_icon = Gtk.Image.new_from_icon_name("network-transmit-receive-symbolic", Gtk.IconSize.MENU)
        network_label = Gtk.Label(label="Network: Connected")
        
        # Version info
        version_label = Gtk.Label()
        version_label.set_markup("<span size='small'>CyberOS v0.1.0</span>")
        version_label.set_halign(Gtk.Align.END)
        version_label.set_hexpand(True)
        
        # Add all elements to status bar
        status_bar.pack_start(status_icon, False, False, 0)
        status_bar.pack_start(status_label, False, False, 0)
        status_bar.pack_start(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL), False, False, 10)
        status_bar.pack_start(security_icon, False, False, 0)
        status_bar.pack_start(security_label, False, False, 0)
        status_bar.pack_start(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL), False, False, 10)
        status_bar.pack_start(network_icon, False, False, 0)
        status_bar.pack_start(network_label, False, False, 0)
        status_bar.pack_end(version_label, False, False, 0)
        
        self.main_box.pack_end(status_bar, False, False, 0)
    
    def refresh_widgets(self):
        """Refresh all dashboard widgets"""
        self.system_monitor.update()
        self.security_status.update()
        self.network_monitor.update()
        return True  # Continue the timer
    
    def on_sidebar_button_clicked(self, button):
        """Handle sidebar button clicks"""
        # Remove active class from all buttons
        parent = button.get_parent()
        for child in parent.get_children():
            if isinstance(child, Gtk.Button):
                child.get_style_context().remove_class("active")
        
        # Add active class to clicked button
        button.get_style_context().add_class("active")
    
    def on_logout_clicked(self, button):
        """Handle logout button click"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text="Are you sure you want to logout?"
        )
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            Gtk.main_quit()

def main():
    """Main application entry point"""
    # Register signal handlers
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    
    # Create and show the dashboard
    dashboard = CyberOSDashboard()
    dashboard.show_all()
    
    # Start the GTK main loop
    Gtk.main()

if __name__ == "__main__":
    main()
